#include <iostream>
using namespace std;

int main()
{
	unsigned a;
	a = 0xfff80000;
	//10
	cout.setf(ios::showbase);
	cout<<"dec:"<<a<<endl;
	cout.unsetf(ios::dec);
	
	//16
	cout.setf(ios::hex);
	cout<<"hex:"<<a<<endl;
	cout.unsetf(ios::hex);

	//8
	cout.setf(ios::oct);
	cout<<"oct:"<<a<<endl;
	cout.unsetf(ios::oct);

	int t=0;
 	double size=1.2;
	double len=0.3;
	t =size/len;
	cout<<"t="<<t<<endl;

        double x=0.4;
	int y=200;
	double z=0;
	z=x/y;
	printf("z=%lf\n",z);
	return 0;
}
