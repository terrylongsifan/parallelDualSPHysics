//HEAD_DSPH
/*
 <DUALSPHYSICS>  Copyright (c) 2019 by Dr Jose M. Dominguez et al. (see http://dual.sphysics.org/index.php/developers/). 

 EPHYSLAB Environmental Physics Laboratory, Universidade de Vigo, Ourense, Spain.
 School of Mechanical, Aerospace and Civil Engineering, University of Manchester, Manchester, U.K.

 This file is part of DualSPHysics. 

 DualSPHysics is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License 
 as published by the Free Software Foundation; either version 2.1 of the License, or (at your option) any later version.
 
 DualSPHysics is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more details. 

 You should have received a copy of the GNU Lesser General Public License along with DualSPHysics. If not, see <http://www.gnu.org/licenses/>. 
*/

/// \file JSphCpu.cpp \brief Implements the class \ref JSphCpu.

#include "JSphCpu.h"
#include "JCellDivCpu.h"
#include "JPartFloatBi4.h"
#include "Functions.h"
#include "FunctionsMath.h"
#include "JSphMotion.h"
#include "JArraysCpu.h"
#include "JSphDtFixed.h"
#include "JWaveGen.h"
#include "JMLPistons.h"     //<vs_mlapiston>
#include "JRelaxZones.h"    //<vs_rzone>
#include "JChronoObjects.h" //<vs_chroono>
#include "JDamping.h"
#include "JXml.h"
#include "JSaveDt.h"
#include "JTimeOut.h"
#include "JSphAccInput.h"
#include "JGaugeSystem.h"
#include "JSphBoundCorr.h"  //<vs_innlet>
#include "JShifting.h"
#include <climits>
#include <vector>
#include <mpi.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

using namespace std;

//==============================================================================
/// Constructor.
//==============================================================================
JSphCpu::JSphCpu(bool withmpi):JSph(true,false,withmpi){
  ClassName="JSphCpu";
  CellDiv=NULL;
  ArraysCpu=new JArraysCpu;
  InitVars();
  TmcCreation(Timers,false);
}

//==============================================================================
/// Destructor.
//==============================================================================
JSphCpu::~JSphCpu(){
  DestructorActive=true;
  FreeCpuMemoryParticles();
  FreeCpuMemoryFixed();
  delete ArraysCpu;
  TmcDestruction(Timers);
}

//==============================================================================
/// Initialisation of variables.
//==============================================================================
void JSphCpu::InitVars(){
  RunMode="";
  OmpThreads=1;

  Np=Npb=NpbOk=0;
  NpbPer=NpfPer=0;

  Idpc=NULL; Codec=NULL; Dcellc=NULL; Posc=NULL; Velrhopc=NULL;
  VelrhopM1c=NULL;                //-Verlet
  PosPrec=NULL; VelrhopPrec=NULL; //-Symplectic
  SpsTauc=NULL; SpsGradvelc=NULL; //-Laminar+SPS. 
  Arc=NULL; Acec=NULL; Deltac=NULL;
  ShiftPosfsc=NULL;               //-Shifting.
  Pressc=NULL;
  RidpMove=NULL; 
  FtRidp=NULL;
  FtoForces=NULL;
  FtoForcesRes=NULL;
  FreeCpuMemoryParticles();
  FreeCpuMemoryFixed();
}

//==============================================================================
/// Deallocate fixed memory on CPU for moving and floating bodies.
/// Libera memoria fija en cpu para moving y floating.
//==============================================================================
void JSphCpu::FreeCpuMemoryFixed(){
  MemCpuFixed=0;
  delete[] RidpMove;     RidpMove=NULL;
  delete[] FtRidp;       FtRidp=NULL;
  delete[] FtoForces;    FtoForces=NULL;
  delete[] FtoForcesRes; FtoForcesRes=NULL;
}

//==============================================================================
/// Allocates memory for arrays with fixed size (motion and floating bodies).
//==============================================================================
void JSphCpu::AllocCpuMemoryFixed(){
  MemCpuFixed=0;
  try{
    //-Allocates memory for moving objects.
    if(CaseNmoving){
      RidpMove=new unsigned[CaseNmoving];  MemCpuFixed+=(sizeof(unsigned)*CaseNmoving);
    }
    //-Allocates memory for floating bodies.
    if(CaseNfloat){
      FtRidp      =new unsigned[CaseNfloat];     MemCpuFixed+=(sizeof(unsigned)*CaseNfloat);
      FtoForces   =new StFtoForces[FtCount];     MemCpuFixed+=(sizeof(StFtoForces)*FtCount);
      FtoForcesRes=new StFtoForcesRes[FtCount];  MemCpuFixed+=(sizeof(StFtoForcesRes)*FtCount);
    }
  }
  catch(const std::bad_alloc){
    Run_Exceptioon("Could not allocate the requested memory.");
  }
}

//==============================================================================
/// Deallocate memory in CPU for particles.
/// Libera memoria en cpu para particulas.
//==============================================================================
void JSphCpu::FreeCpuMemoryParticles(){
  CpuParticlesSize=0;
  MemCpuParticles=0;
  ArraysCpu->Reset();
}

//==============================================================================
/// Allocte memory on CPU for the particles. 
/// Reserva memoria en Cpu para las particulas. 
//==============================================================================
void JSphCpu::AllocCpuMemoryParticles(unsigned np,float over){
  FreeCpuMemoryParticles();
  //-Calculate number of partices with reserved memory | Calcula numero de particulas para las que se reserva memoria.
  const unsigned np2=(over>0? unsigned(over*np): np);
  CpuParticlesSize=np2+PARTICLES_OVERMEMORY_MIN;
  //-Define number or arrays to use. | Establece numero de arrays a usar.
  ArraysCpu->SetArraySize(CpuParticlesSize);
  #ifdef CODE_SIZE4
    ArraysCpu->AddArrayCount(JArraysCpu::SIZE_4B,2);  //-code,code2
  #else
    ArraysCpu->AddArrayCount(JArraysCpu::SIZE_2B,2);  //-code,code2
  #endif
  ArraysCpu->AddArrayCount(JArraysCpu::SIZE_4B,5);  //-idp,ar,viscdt,dcell,prrhop
  if(DDTArray)ArraysCpu->AddArrayCount(JArraysCpu::SIZE_4B,1);  //-delta
  ArraysCpu->AddArrayCount(JArraysCpu::SIZE_12B,1); //-ace
  ArraysCpu->AddArrayCount(JArraysCpu::SIZE_16B,2); //-velrhop,poscell
  ArraysCpu->AddArrayCount(JArraysCpu::SIZE_24B,2); //-pos
  if(TStep==STEP_Verlet){
    ArraysCpu->AddArrayCount(JArraysCpu::SIZE_16B,1); //-velrhopm1
  }
  else if(TStep==STEP_Symplectic){
    ArraysCpu->AddArrayCount(JArraysCpu::SIZE_24B,1); //-pospre
    ArraysCpu->AddArrayCount(JArraysCpu::SIZE_16B,1); //-velrhoppre
  }
  if(TVisco==VISCO_LaminarSPS){     
    ArraysCpu->AddArrayCount(JArraysCpu::SIZE_24B,1); //-SpsTau,SpsGradvel
  }
  if(Shifting){
    ArraysCpu->AddArrayCount(JArraysCpu::SIZE_16B,1); //-shiftposfs
  }
  if(InOut){  //<vs_innlet_ini>
    //ArraysCpu->AddArrayCount(JArraysCpu::SIZE_4B,1);  //-InOutPart
    ArraysCpu->AddArrayCount(JArraysCpu::SIZE_1B,1);  //-newizone
  }  //<vs_innlet_end>
  //-Shows the allocated memory.
  MemCpuParticles=ArraysCpu->GetAllocMemoryCpu();
  PrintSizeNp(CpuParticlesSize,MemCpuParticles,0);
}

//==============================================================================
/// Resizes space in CPU memory for particles.
//==============================================================================
void JSphCpu::ResizeCpuMemoryParticles(unsigned npnew){
  npnew=npnew+PARTICLES_OVERMEMORY_MIN;
  //-Saves current data from CPU.
  unsigned    *idp        =SaveArrayCpu(Np,Idpc);
  typecode    *code       =SaveArrayCpu(Np,Codec);
  unsigned    *dcell      =SaveArrayCpu(Np,Dcellc);
  tdouble3    *pos        =SaveArrayCpu(Np,Posc);
  tfloat4     *velrhop    =SaveArrayCpu(Np,Velrhopc);
  tfloat4     *velrhopm1  =SaveArrayCpu(Np,VelrhopM1c);
  tdouble3    *pospre     =SaveArrayCpu(Np,PosPrec);
  tfloat4     *velrhoppre =SaveArrayCpu(Np,VelrhopPrec);
  tsymatrix3f *spstau     =SaveArrayCpu(Np,SpsTauc);
  //-Frees pointers.
  ArraysCpu->Free(Idpc);
  ArraysCpu->Free(Codec);
  ArraysCpu->Free(Dcellc);
  ArraysCpu->Free(Posc);
  ArraysCpu->Free(Velrhopc);
  ArraysCpu->Free(VelrhopM1c);
  ArraysCpu->Free(PosPrec);
  ArraysCpu->Free(VelrhopPrec);
  ArraysCpu->Free(SpsTauc);
  //-Resizes CPU memory allocation.
  const double mbparticle=(double(MemCpuParticles)/(1024*1024))/CpuParticlesSize; //-MB por particula.
  Log->Printf("**JSphCpu: Requesting cpu memory for %u particles: %.1f MB.",npnew,mbparticle*npnew);
  ArraysCpu->SetArraySize(npnew);
  //-Reserve pointers.
  Idpc    =ArraysCpu->ReserveUint();
  Codec   =ArraysCpu->ReserveTypeCode();
  Dcellc  =ArraysCpu->ReserveUint();
  Posc    =ArraysCpu->ReserveDouble3();
  Velrhopc=ArraysCpu->ReserveFloat4();
  if(velrhopm1)  VelrhopM1c  =ArraysCpu->ReserveFloat4();
  if(pospre)     PosPrec     =ArraysCpu->ReserveDouble3();
  if(velrhoppre) VelrhopPrec =ArraysCpu->ReserveFloat4();
  if(spstau)     SpsTauc     =ArraysCpu->ReserveSymatrix3f();
  //-Restore data in CPU memory.
  RestoreArrayCpu(Np,idp,Idpc);
  RestoreArrayCpu(Np,code,Codec);
  RestoreArrayCpu(Np,dcell,Dcellc);
  RestoreArrayCpu(Np,pos,Posc);
  RestoreArrayCpu(Np,velrhop,Velrhopc);
  RestoreArrayCpu(Np,velrhopm1,VelrhopM1c);
  RestoreArrayCpu(Np,pospre,PosPrec);
  RestoreArrayCpu(Np,velrhoppre,VelrhopPrec);
  RestoreArrayCpu(Np,spstau,SpsTauc);
  //-Updates values.
  CpuParticlesSize=npnew;
  MemCpuParticles=ArraysCpu->GetAllocMemoryCpu();
}

//==============================================================================
/// Saves a CPU array in CPU memory. 
//==============================================================================
template<class T> T* JSphCpu::TSaveArrayCpu(unsigned np,const T *datasrc)const{
  T *data=NULL;
  if(datasrc){
    try{
      data=new T[np];
    }
    catch(const std::bad_alloc){
      Run_Exceptioon("Could not allocate the requested memory.");
    }
    memcpy(data,datasrc,sizeof(T)*np);
  }
  return(data);
}

//==============================================================================
/// Restores an array (generic) from CPU memory. 
//==============================================================================
template<class T> void JSphCpu::TRestoreArrayCpu(unsigned np,T *data,T *datanew)const{
  if(data&&datanew)memcpy(datanew,data,sizeof(T)*np);
  delete[] data;
}

//==============================================================================
/// Arrays for basic particle data. 
/// Arrays para datos basicos de las particulas. 
//==============================================================================
void JSphCpu::ReserveBasicArraysCpu(){
  Idpc=ArraysCpu->ReserveUint();
  Codec=ArraysCpu->ReserveTypeCode();
  Dcellc=ArraysCpu->ReserveUint();
  Posc=ArraysCpu->ReserveDouble3();
  Velrhopc=ArraysCpu->ReserveFloat4();
  if(TStep==STEP_Verlet)VelrhopM1c=ArraysCpu->ReserveFloat4();
  if(TVisco==VISCO_LaminarSPS)SpsTauc=ArraysCpu->ReserveSymatrix3f();
}

//==============================================================================
/// Return memory reserved on CPU.
/// Devuelve la memoria reservada en cpu.
//==============================================================================
llong JSphCpu::GetAllocMemoryCpu()const{  
  llong s=JSph::GetAllocMemoryCpu();
  //-Reserved in AllocCpuMemoryParticles().
  s+=MemCpuParticles;
  //-Reserved in AllocCpuMemoryFixed().
  s+=MemCpuFixed;
  //-Reserved in other objects.
  if(MLPistons)s+=MLPistons->GetAllocMemoryCpu();  //<vs_mlapiston>
  return(s);
}

//==============================================================================
/// Visualize the reserved memory.
/// Visualiza la memoria reservada.
//==============================================================================
void JSphCpu::PrintAllocMemory(llong mcpu)const{
  Log->Printf("Allocated memory in CPU: %lld (%.2f MB)",mcpu,double(mcpu)/(1024*1024));
}

//==============================================================================
/// Collect data from a range of particles and return the number of particles that 
/// will be less than n and eliminate the periodic ones
/// - onlynormal: Only keep the normal ones and eliminate the periodic particles.
///
/// Recupera datos de un rango de particulas y devuelve el numero de particulas que
/// sera menor que n si se eliminaron las periodicas.
/// - onlynormal: Solo se queda con las normales, elimina las particulas periodicas.
//==============================================================================
unsigned JSphCpu::GetParticlesData(unsigned n,unsigned pini,bool onlynormal
  ,unsigned *idp,tdouble3 *pos,tfloat3 *vel,float *rhop,typecode *code)
{
  unsigned num=n;
  //-Copy selected values.
  if(code)memcpy(code,Codec+pini,sizeof(typecode)*n);
  if(idp) memcpy(idp ,Idpc +pini,sizeof(unsigned)*n);
  if(pos) memcpy(pos ,Posc +pini,sizeof(tdouble3)*n);
  if(vel && rhop){
    for(unsigned p=0;p<n;p++){
      tfloat4 vr=Velrhopc[p+pini];
      vel[p]=TFloat3(vr.x,vr.y,vr.z);
      rhop[p]=vr.w;
    }
  }
  else{
    if(vel) for(unsigned p=0;p<n;p++){ tfloat4 vr=Velrhopc[p+pini]; vel[p]=TFloat3(vr.x,vr.y,vr.z); }
    if(rhop)for(unsigned p=0;p<n;p++)rhop[p]=Velrhopc[p+pini].w;
  }
  //-Eliminate non-normal particles (periodic & others). | Elimina particulas no normales (periodicas y otras).
  if(onlynormal){
    if(!idp || !pos || !vel || !rhop)Run_Exceptioon("Pointers without data.");
    typecode *code2=code;
    if(!code2){
      code2=ArraysCpu->ReserveTypeCode();
      memcpy(code2,Codec+pini,sizeof(typecode)*n);
    }
    unsigned ndel=0;
    for(unsigned p=0;p<n;p++){
      bool normal=CODE_IsNormal(code2[p]);
      if(ndel && normal){
        const unsigned pdel=p-ndel;
        idp[pdel]  =idp[p];
        pos[pdel]  =pos[p];
        vel[pdel]  =vel[p];
        rhop[pdel] =rhop[p];
        code2[pdel]=code2[p];
      }
      if(!normal)ndel++;
    }
    num-=ndel;
    if(!code)ArraysCpu->Free(code2);
  }
  return(num);
}

//==============================================================================
/// Load the execution configuration with OpenMP.
/// Carga la configuracion de ejecucion con OpenMP.
//==============================================================================
void JSphCpu::ConfigOmp(const JCfgRun *cfg){
#ifdef OMP_USE
  //-Determine number of threads for host with OpenMP. | Determina numero de threads por host con OpenMP.
  if(Cpu && cfg->OmpThreads!=1){
    OmpThreads=cfg->OmpThreads;
    if(OmpThreads<=0)OmpThreads=max(omp_get_num_procs(),1);
    if(OmpThreads>OMP_MAXTHREADS)OmpThreads=OMP_MAXTHREADS;
    omp_set_num_threads(OmpThreads);
    Log->Printf("Threads by host for parallel execution: %d",omp_get_max_threads());
  }
  else{
    OmpThreads=1;
    omp_set_num_threads(OmpThreads);
  }
#else
  OmpThreads=1;
#endif
}

//==============================================================================
/// Configures execution mode in CPU.
/// Configura modo de ejecucion en CPU.
//==============================================================================
void JSphCpu::ConfigRunMode(const JCfgRun *cfg,std::string preinfo){
  //#ifndef WIN32  //-Error compilation when gcc5 is used.
  //  const int len=128; char hname[len];
  //  gethostname(hname,len);
  //  if(!preinfo.empty())preinfo=preinfo+", ";
  //  preinfo=preinfo+"HostName:"+hname;
  //#endif
  Hardware="Cpu";
  if(OmpThreads==1)RunMode="Single core";
  else RunMode=string("OpenMP(Threads:")+fun::IntStr(OmpThreads)+")";
  if(!preinfo.empty())RunMode=preinfo+" - "+RunMode;
  if(Stable)RunMode=string("Stable - ")+RunMode;
  RunMode=string("Pos-Double - ")+RunMode;
  Log->Print(" ");
  Log->Print(fun::VarStr("RunMode",RunMode));
  Log->Print(" ");
}

//==============================================================================
/// Initialisation of arrays and variables for execution.
/// Inicializa vectores y variables para la ejecucion.
//==============================================================================
void JSphCpu::InitRunCpu(){
  InitRun(Np,Idpc,Posc);//initial

  if(TStep==STEP_Verlet)memcpy(VelrhopM1c,Velrhopc,sizeof(tfloat4)*Np);
  if(TVisco==VISCO_LaminarSPS)memset(SpsTauc,0,sizeof(tsymatrix3f)*Np);//memset is init function
  if(CaseNfloat)InitFloating();
}

//==============================================================================
/// Prepare variables for interaction functions.
/// Prepara variables para interaccion.
//==============================================================================
void JSphCpu::PreInteractionVars_Forces(unsigned np,unsigned npb){
  //-Initialise arrays.
  const unsigned npf=np-npb;
  memset(Arc,0,sizeof(float)*np);                                    //Arc[]=0
  if(Deltac)memset(Deltac,0,sizeof(float)*np);                       //Deltac[]=0
  memset(Acec,0,sizeof(tfloat3)*np);                                 //Acec[]=(0,0,0)
  if(SpsGradvelc)memset(SpsGradvelc+npb,0,sizeof(tsymatrix3f)*npf);  //SpsGradvelc[]=(0,0,0,0,0,0).

  //-Select particles for shifting.
  if(ShiftPosfsc)Shifting->InitCpu(npf,npb,Posc,ShiftPosfsc);

  //-Adds variable acceleration from input configuration.
  if(AccInput)AccInput->RunCpu(TimeStep,Gravity,npf,npb,Codec,Posc,Velrhopc,Acec);

  //-Prepare press values for interaction.
  const int n=int(np);
  #ifdef OMP_USE
    #pragma omp parallel for schedule (static) if(n>OMP_LIMIT_COMPUTELIGHT)
  #endif
  for(int p=0;p<n;p++){
    const float rhop=Velrhopc[p].w,rhop_r0=rhop/RhopZero;
    Pressc[p]=CteB*(pow(rhop_r0,Gamma)-1.0f);
  }
}

//==============================================================================
/// Prepare variables for interaction functions.
/// Prepara variables para interaccion.
//==============================================================================
void JSphCpu::PreInteraction_Forces(){
  TmcStart(Timers,TMC_CfPreForces);
  //-Assign memory.
  Arc=ArraysCpu->ReserveFloat();
  Acec=ArraysCpu->ReserveFloat3();
  if(DDTArray)Deltac=ArraysCpu->ReserveFloat();
  if(Shifting)ShiftPosfsc=ArraysCpu->ReserveFloat4();
  Pressc=ArraysCpu->ReserveFloat();
  if(TVisco==VISCO_LaminarSPS)SpsGradvelc=ArraysCpu->ReserveSymatrix3f();

  //-assignment memory.
  //-Initialise arrays.
  PreInteractionVars_Forces(Np,Npb);

  //-Calculate VelMax: Floating object particles are included and do not affect use of periodic condition.
  //-Calcula VelMax: Se incluyen las particulas floatings y no afecta el uso de condiciones periodicas.
  const unsigned pini=(DtAllParticles? 0: Npb);//bound particles and fluid particles
  VelMax=CalcVelMaxOmp(Np-pini,Velrhopc+pini);
  ViscDtMax=0;
  TmcStop(Timers,TMC_CfPreForces);
}

//==============================================================================
/// Returns maximum velocity from an array tfloat4.
/// Devuelve la velociad maxima de un array tfloat4.
//==============================================================================
float JSphCpu::CalcVelMaxSeq(unsigned np,const tfloat4* velrhop)const{
  float velmax=0;
  for(unsigned p=0;p<np;p++){
    const tfloat4 v=velrhop[p];
    const float v2=v.x*v.x+v.y*v.y+v.z*v.z;
    velmax=max(velmax,v2);
  }
  return(sqrt(velmax));
}

//==============================================================================
/// Returns maximum velocity from an array tfloat4 using OpenMP.
/// Devuelve la velociad maxima de un array tfloat4 usando OpenMP.
//==============================================================================
float JSphCpu::CalcVelMaxOmp(unsigned np,const tfloat4* velrhop)const{
  float velmax=0;
  #ifdef OMP_USE
    if(np>OMP_LIMIT_COMPUTELIGHT){
      const int n=int(np);
      if(n<0)Run_Exceptioon("Number of values is too big.");
      float vmax=0;
      #pragma omp parallel 
      {
        float vmax2=0;
        #pragma omp for nowait
        for(int c=0;c<n;++c){
          const tfloat4 v=velrhop[c];
          const float v2=v.x*v.x+v.y*v.y+v.z*v.z;
          if(vmax2<v2)vmax2=v2;
        }
        #pragma omp critical 
        {
          if(vmax<vmax2)vmax=vmax2;
        }
      }
      //-Saves result.
      velmax=sqrt(vmax);
    }
    else if(np)velmax=CalcVelMaxSeq(np,velrhop);
  #else
    if(np)velmax=CalcVelMaxSeq(np,velrhop);
  #endif
  return(velmax);
}

//==============================================================================
/// Free memory assigned to ArraysCpu.
/// Libera memoria asignada de ArraysCpu.
//==============================================================================
void JSphCpu::PosInteraction_Forces(){
  //-Free memory assigned in PreInteraction_Forces(). | Libera memoria asignada en PreInteraction_Forces().
  ArraysCpu->Free(Arc);          Arc=NULL;
  ArraysCpu->Free(Acec);         Acec=NULL;
  ArraysCpu->Free(Deltac);       Deltac=NULL;
  ArraysCpu->Free(ShiftPosfsc);  ShiftPosfsc=NULL;
  ArraysCpu->Free(Pressc);       Pressc=NULL;
  ArraysCpu->Free(SpsGradvelc);  SpsGradvelc=NULL;
}

//==============================================================================
/// Returns values of kernel Wendland, gradients: frx, fry and frz.
/// Devuelve valores de kernel Wendland, gradients: frx, fry y frz.
//==============================================================================
void JSphCpu::GetKernelWendland(float rr2,float drx,float dry,float drz
  ,float &frx,float &fry,float &frz)const
{
  const float rad=sqrt(rr2);
  const float qq=rad/H;
  //-Wendland kernel.
  const float wqq1=1.f-0.5f*qq;
  const float fac=Bwen*qq*wqq1*wqq1*wqq1/rad; //-Kernel derivative (divided by rad).
  frx=fac*drx; fry=fac*dry; frz=fac*drz;
}

//<vs_innlet_ini>
//============================================================================== 
/// Returns values of kernel Wendland, gradients: frx, fry, frz and wab.
/// Devuelve valores de kernel Wendland, gradients: frx, fry, frz y wab.
//==============================================================================
void JSphCpu::GetKernelWendland(float rr2,float drx,float dry,float drz
  ,float &frx,float &fry,float &frz,float &wab)const
{
  const float rad=sqrt(rr2);
  const float qq=rad/H;
  //-Wendland kernel.
  const float wqq1=1.f-0.5f*qq;
  const float wqq2=wqq1*wqq1;
  const float fac=Bwen*qq*wqq2*wqq1/rad; //-Kernel derivative (divided by rad).
  frx=fac*drx; fry=fac*dry; frz=fac*drz;
  const float wqq=2.f*qq+1.f;
  wab=Awen*wqq*wqq2*wqq2; //-Kernel.
}  //<vs_innlet_end>

//==============================================================================
/// Returns values of kernel Gaussian, gradients: frx, fry and frz.
/// Devuelve valores de kernel Gaussian, gradients: frx, fry y frz.
//==============================================================================
void JSphCpu::GetKernelGaussian(float rr2,float drx,float dry,float drz
  ,float &frx,float &fry,float &frz)const
{
  const float rad=sqrt(rr2);
  const float qq=rad/H;
  //-Gaussian kernel.
  const float qqexp=-4.0f*qq*qq;
  //const float wab=Agau*expf(qqexp); //-Kernel.
  const float fac=Bgau*qq*expf(qqexp)/rad; //-Kernel derivative (divided by rad).
  frx=fac*drx; fry=fac*dry; frz=fac*drz;
}

//<vs_innlet_ini>
//==============================================================================
/// Returns values of kernel Gaussian, gradients: frx, fry, frz and wab.
/// Devuelve valores de kernel Gaussian, gradients: frx, fry, frz y wab.
//==============================================================================
void JSphCpu::GetKernelGaussian(float rr2,float drx,float dry,float drz
  ,float &frx,float &fry,float &frz,float &wab)const
{
  const float rad=sqrt(rr2);
  const float qq=rad/H;
  //-Gaussian kernel.
  const float qqexp=-4.0f*qq*qq;
  const float eqqexp=expf(qqexp);
  wab=Agau*eqqexp; //-Kernel.
  const float fac=Bgau*qq*eqqexp/rad; //-Kernel derivative (divided by rad).
  frx=fac*drx; fry=fac*dry; frz=fac*drz;
}  //<vs_innlet_end>

//==============================================================================
/// Return values of kernel Cubic without tensil correction, gradients: frx, fry and frz.
/// Devuelve valores de kernel Cubic sin correccion tensil, gradients: frx, fry y frz.
//==============================================================================
void JSphCpu::GetKernelCubic(float rr2,float drx,float dry,float drz
  ,float &frx,float &fry,float &frz)const
{
  const float rad=sqrt(rr2);
  const float qq=rad/H;
  //-Cubic Spline kernel.
  float fac;
  if(rad>H){
    float wqq1=2.0f-qq;
    float wqq2=wqq1*wqq1;
    fac=CubicCte.c2*wqq2/rad; //-Kernel derivative (divided by rad).
  }
  else{
    float wqq2=qq*qq;
    fac=(CubicCte.c1*qq+CubicCte.d1*wqq2)/rad; //-Kernel derivative (divided by rad).
  }
  //-Gradients.
  frx=fac*drx; fry=fac*dry; frz=fac*drz;
}

//<vs_innlet_ini>
//==============================================================================
/// Return values of kernel Cubic without tensil correction, gradients: frx, fry, frz and wab.
/// Devuelve valores de kernel Cubic sin correccion tensil, gradients: frx, fry,frz y wab.
//==============================================================================
void JSphCpu::GetKernelCubic(float rr2,float drx,float dry,float drz
  ,float &frx,float &fry,float &frz,float &wab)const
{
  const float rad=sqrt(rr2);
  const float qq=rad/H;
  //-Cubic Spline kernel.
  float fac;
  if(rad>H){
    float wqq1=2.0f-qq;
    float wqq2=wqq1*wqq1;
    fac=CubicCte.c2*wqq2/rad; //-Kernel derivative (divided by rad).
    wab=CubicCte.a24*(wqq2*wqq1); //-Kernel.
  }
  else{
    float wqq2=qq*qq;
    fac=(CubicCte.c1*qq+CubicCte.d1*wqq2)/rad; //-Kernel derivative (divided by rad).
    wab=CubicCte.a2*(1.0f+(0.75f*qq-1.5f)*wqq2); //-Kernel.
  }
  //-Gradients.
  frx=fac*drx; fry=fac*dry; frz=fac*drz;
}  //<vs_innlet_end>

//==============================================================================
/// Return tensil correction for kernel Cubic.
/// Devuelve correccion tensil para kernel Cubic.
//==============================================================================
float JSphCpu::GetKernelCubicTensil(float rr2,float rhopp1,float pressp1,float rhopp2,float pressp2)const{
  const float rad=sqrt(rr2);
  const float qq=rad/H;
  //-Cubic Spline kernel.
  float wab;
  if(rad>H){
    float wqq1=2.0f-qq;
    float wqq2=wqq1*wqq1;
    wab=CubicCte.a24*(wqq2*wqq1); //-Kernel.
  }
  else{
    float wqq2=qq*qq;
    float wqq3=wqq2*qq;
    wab=CubicCte.a2*(1.0f-1.5f*wqq2+0.75f*wqq3); //-Kernel.
  }
  //-Tensile correction.
  float fab=wab*CubicCte.od_wdeltap;
  fab*=fab; fab*=fab; //fab=fab^4
  const float tensilp1=(pressp1/(rhopp1*rhopp1))*(pressp1>0? 0.01f: -0.2f);
  const float tensilp2=(pressp2/(rhopp2*rhopp2))*(pressp2>0? 0.01f: -0.2f);
  return(fab*(tensilp1+tensilp2));
}

//==============================================================================
/// Return cell limits for interaction starting from cell coordinates.
/// Devuelve limites de celdas para interaccion a partir de coordenadas de celda.
//==============================================================================
void JSphCpu::GetInteractionCells(unsigned rcell
  ,int hdiv,const tint4 &nc,const tint3 &cellzero
  ,int &cxini,int &cxfin,int &yini,int &yfin,int &zini,int &zfin)const
{
  //-Get interaction limits. | Obtiene limites de interaccion.
  const int cx=PC__Cellx(DomCellCode,rcell)-cellzero.x;
  const int cy=PC__Celly(DomCellCode,rcell)-cellzero.y;
  const int cz=PC__Cellz(DomCellCode,rcell)-cellzero.z;
  //-Code for hdiv 1 or 2 but not zero. | Codigo para hdiv 1 o 2 pero no cero.
  cxini=cx-min(cx,hdiv);
  cxfin=cx+min(nc.x-cx-1,hdiv)+1;
  yini=cy-min(cy,hdiv);
  yfin=cy+min(nc.y-cy-1,hdiv)+1;
  zini=cz-min(cz,hdiv);
  zfin=cz+min(nc.z-cz-1,hdiv)+1;
}

//============================================================================== //<vs_innlet_ini>
/// Return cell limits for interaction starting from position.
/// Devuelve limites de celdas para interaccion a partir de posicion.
//==============================================================================
void JSphCpu::GetInteractionCells(const tdouble3 &pos
  ,int hdiv,const tint4 &nc,const tint3 &cellzero
  ,int &cxini,int &cxfin,int &yini,int &yfin,int &zini,int &zfin)const
{
  //-Get cell coordinates of position pos.
  const int cx=int((pos.x-DomPosMin.x)/Scell)-cellzero.x;
  const int cy=int((pos.y-DomPosMin.y)/Scell)-cellzero.y;
  const int cz=int((pos.z-DomPosMin.z)/Scell)-cellzero.z;
  //-code for hdiv 1 or 2 but not zero. | Codigo para hdiv 1 o 2 pero no cero.
  cxini=cx-min(cx,hdiv);
  cxfin=cx+min(nc.x-cx-1,hdiv)+1;
  yini=cy-min(cy,hdiv);
  yfin=cy+min(nc.y-cy-1,hdiv)+1;
  zini=cz-min(cz,hdiv);
  zfin=cz+min(nc.z-cz-1,hdiv)+1;
} //<vs_innlet_end>

//for force and EDM
//==============================================================================
/// Perform interaction between particles. Bound-Fluid/Float
/// Realiza interaccion entre particulas. Bound-Fluid/Float
//==============================================================================
template<TpKernel tker,TpFtMode ftmode> void JSphCpu::InteractionForcesBound
  (unsigned nbf,unsigned npb,unsigned n,unsigned pinit,tint4 nc,int hdiv,unsigned cellinitial
  ,const unsigned *beginendcell,tint3 cellzero,const unsigned *dcell
  ,const tdouble3 *pos,const tfloat4 *velrhop,const typecode *code,const unsigned *idp
  ,float &viscdt,float *ar)const
{
  //-Initialize viscth to calculate max viscdt with OpenMP. | Inicializa viscth para calcular visdt maximo con OpenMP.
  float viscth[OMP_MAXTHREADS*OMP_STRIDE];
  for(int th=0;th<OmpThreads;th++)viscth[th*OMP_STRIDE]=0;
  //-Starts execution using OpenMP.
  const int pfin=int(pinit+n);

  #ifdef OMP_USE
    #pragma omp parallel for schedule (guided)
  #endif
  for(int p1=int(pinit);p1<pfin;p1++){
    float visc=0,arp1=0;

    //-Load data of particle p1. | Carga datos de particula p1.
    const tdouble3 posp1=pos[p1];
    const bool rsymp1=(Symmetry && posp1.y<=Dosh); //<vs_syymmetry>
    const tfloat3 velp1=TFloat3(velrhop[p1].x,velrhop[p1].y,velrhop[p1].z);

    //-Obtain limits of interaction. | Obtiene limites de interaccion.
    int cxini,cxfin,yini,yfin,zini,zfin;
    GetInteractionCells(dcell[p1],hdiv,nc,cellzero,cxini,cxfin,yini,yfin,zini,zfin);

    //-Search for neighbours in adjacent cells. | Busqueda de vecinos en celdas adyacentes.
    for(int z=zini;z<zfin;z++){
      const int zmod=(nc.w)*z+cellinitial; //-Sum from start of fluid cells. | Le suma donde empiezan las celdas de fluido.
      for(int y=yini;y<yfin;y++){
        int ymod=zmod+nc.x*y;
        const unsigned pini=beginendcell[cxini+ymod];
        const unsigned pfin=beginendcell[cxfin+ymod];

        //-Interaction of boundary with type Fluid/Float | Interaccion de Bound con varias Fluid/Float.
        //---------------------------------------------------------------------------------------------
        bool rsym=false; //<vs_syymmetry>
        for(unsigned p2=pini;p2<pfin;p2++){
          const float drx=float(posp1.x-pos[p2].x);
                float dry=float(posp1.y-pos[p2].y);
          if(rsym)    dry=float(posp1.y+pos[p2].y); //<vs_syymmetry>
          const float drz=float(posp1.z-pos[p2].z);
          const float rr2=drx*drx+dry*dry+drz*drz;
          if(rr2<=Fourh2 && rr2>=ALMOSTZERO){
            //-Cubic Spline, Wendland or Gaussian kernel.
            float frx,fry,frz;
            if(tker==KERNEL_Wendland)GetKernelWendland(rr2,drx,dry,drz,frx,fry,frz);
            else if(tker==KERNEL_Gaussian)GetKernelGaussian(rr2,drx,dry,drz,frx,fry,frz);
            else if(tker==KERNEL_Cubic)GetKernelCubic(rr2,drx,dry,drz,frx,fry,frz);

            //===== Get mass of particle p2 ===== 
            float massp2=MassFluid; //-Contains particle mass of incorrect fluid. | Contiene masa de particula por defecto fluid.
            bool compute=true;      //-Deactivate when using DEM and/or bound-float. | Se desactiva cuando se usa DEM y es bound-float.
            if(USE_FLOATING){
              bool ftp2=CODE_IsFloating(code[p2]);
              if(ftp2)massp2=FtObjs[CODE_GetTypeValue(code[p2])].massp;
              compute=!(USE_FTEXTERNAL && ftp2); //-Deactivate when using DEM/Chrono and/or bound-float. | Se desactiva cuando se usa DEM/Chrono y es bound-float.
            }

            if(compute){
              //-Density derivative.
              //const float dvx=velp1.x-velrhop[p2].x, dvy=velp1.y-velrhop[p2].y, dvz=velp1.z-velrhop[p2].z;
              tfloat4 velrhop2=velrhop[p2];
              if(rsym)velrhop2.y=-velrhop2.y; //<vs_syymmetry>
              const float dvx=velp1.x-velrhop2.x, dvy=velp1.y-velrhop2.y, dvz=velp1.z-velrhop2.z;
              if(compute)arp1+=massp2*(dvx*frx+dvy*fry+dvz*frz);

              {//-Viscosity.
                const float dot=drx*dvx + dry*dvy + drz*dvz;
                const float dot_rr2=dot/(rr2+Eta2);
                visc=max(dot_rr2,visc);
              }
            }
            rsym=(rsymp1 && !rsym && float(posp1.y-dry)<=Dosh); //<vs_syymmetry>
            if(rsym)p2--;                                       //<vs_syymmetry>
          }
          else rsym=false;                                      //<vs_syymmetry>
        }
      }
    }
    //-Sum results together. | Almacena resultados.
    if(arp1||visc){
      ar[p1]+=arp1;
      const int th=omp_get_thread_num();
      if(visc>viscth[th*OMP_STRIDE])viscth[th*OMP_STRIDE]=visc;
    }
  }
  //-Keep max value in viscdt. | Guarda en viscdt el valor maximo.
  for(int th=0;th<OmpThreads;th++)if(viscdt<viscth[th*OMP_STRIDE])viscdt=viscth[th*OMP_STRIDE];
}

//================================get minmum for linked list divide============
//--------------reconstruct the ghost list divide (x/z)------------------------
//=============================================================================
//=================================get minimum for pos_x/y/z===================
//get grid background
//=============================================================================
void JSphCpu::getPosMinMax(unsigned pinit, unsigned pfin,const tdouble3* pos,tdouble3 &posmin, tdouble3 &posmax)const{
  double tmp_xmin,tmp_xmax;
  double tmp_ymin,tmp_ymax;
  double tmp_zmin,tmp_zmax;

  posmin.x=pos[pinit].x;
  posmin.y=pos[pinit].y;
  posmin.z=pos[pinit].z;

  posmax.x=pos[pinit].x;
  posmax.y=pos[pinit].y;
  posmax.z=pos[pinit].z;
//  printf("---getpos minmax pinit=%d-------pfin=%d\n",pinit,pfin);

  #ifdef OMP_USE
    #pragma omp parallel for schedule (guided)
  #endif
  for(unsigned p=pinit;p<pfin;p++){
	//get  minimum
	if(posmin.x>pos[p].x){
		posmin.x = pos[p].x;
	}
	if(posmin.y>pos[p].y){
                posmin.y = pos[p].y;
        }
	if(posmin.z>pos[p].z){
                posmin.z = pos[p].z;
        }
	//get maxmum
	if(posmax.x<pos[p].x){
                posmax.x = pos[p].x;
        }
	if(posmax.y<pos[p].y){
                posmax.y = pos[p].y;
        }
	if(posmax.z<pos[p].z){
                posmax.z = pos[p].z;
        }

  }
//  printf("==========xmin-xmax(%lf,%lf),ymin-ymax(%lf,%lf),zmin-zmax(%lf,%lf)\n",posmin.x,posmin.x,posmin.y,posmax.y,posmin.z,posmax.z);
	
}

//===========================set grid for NL====================================
//  store the neighbor information
//==============================================================================
void JSphCpu::setGridDivideStore(const tdouble3* pos)const{


}

//MPI----left/right--hole-----interaction fluid-fluid only------------using linked list
//==============================================================================
/// Perform interaction between particles: Fluid/Float-Fluid/Float or Fluid/Float-Bound
/// Realiza interaccion entre particulas: Fluid/Float-Fluid/Float or Fluid/Float-Bound
//==============================================================================
template<TpKernel tker,TpFtMode ftmode,bool lamsps,TpDensity tdensity,bool shift> 
  void JSphCpu::MPI_Hole_LinkedList_InteractionForcesFluidFluidOnly
  (unsigned n,unsigned pinit,tint4 nc,int hdiv,unsigned cellinitial,float visco
  ,const unsigned *beginendcell,tint3 cellzero,const unsigned *dcell
  ,const tsymatrix3f* tau,tsymatrix3f* gradvel
  ,const tdouble3 *pos,const tfloat4 *velrhop,const typecode *code,const unsigned *idp
  ,const float *press 
  ,float &viscdt,float *ar,tfloat3 *ace,float *delta
  ,TpShifting shiftmode,tfloat4 *shiftposfs,double procMinlimit,double procMaxlimit,const std::vector<unsigned>* partParticles,const unsigned num_ghost
  ,const double* ghostPosx,const double* ghostPosy,const double* ghostPosz,const float* ghostPress
  ,const float* ghostVelx,const float* ghostVely,const float* ghostVelz,const float* ghostVelw, const bool direction )const
{//partparticles include ghost particles(left/right) and not ghost particles
//n  is number of fuild particles idp is particles for fuild
  const bool boundp2=(!cellinitial); //-Interaction with type boundary (Bound). | Interaccion con Bound.
  //-Initialize viscth to calculate viscdt maximo con OpenMP. | Inicializa viscth para calcular visdt maximo con OpenMP.
  float viscth[OMP_MAXTHREADS*OMP_STRIDE];
  for(int th=0;th<OmpThreads;th++)viscth[th*OMP_STRIDE]=0;
  //-Initialise execution with OpenMP. | Inicia ejecucion con OpenMP.
  const int pfin=int(pinit+n);
  //------------------divide the ghost paritcles using linked list algorithm----------------//
  int rank_id=mpi_rank_id;
  int proc_size=mpi_rank_size;
  MPI_Comm_rank(MPI_COMM_WORLD,&rank_id);
  MPI_Comm_size(MPI_COMM_WORLD,&proc_size);
  //get the domin for hole particles
  double holeMinx,holeMiny,holeMinz;
  double holeMaxx,holeMaxy,holeMaxz;
/* 
  holeMinx=0;
  holeMiny=0;
  holeMinz=0;
  holeMaxx=0;
  holeMaxy=0;
  holeMaxz=0;
  tdouble3 holeMinTemp =TDouble3(0);//for exchange variable
  //set the original values
//  unsigned t = (*partParticles)[0];
  unsigned t = 0;
  t = (*partParticles)[0];
  tdouble3 pos1=pos[t];
  holeMinx = pos1.x;
  holeMiny = pos1.y;
  holeMinz = pos1.z;

  holeMaxx = pos1.x;
  holeMaxy = pos1.y;
  holeMaxz = pos1.z;
 //printf("@@@@@@@@@@@@@@@hole minix=[%f,]---miniy=[%f,]\n",holeMinx,holeMiny);
//  cout<<t<<endl;
//  printf("xxxxxxxxxhhhhhhhhxxxxxxxxxxxxxxxxxx");
// if(rank_id==0){
//  double tt=99;
//  printf("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxt=%ud\n",t);
// }
//  printf("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");

//  printf("--------%f-------- %f\n",pos1.x,pos1.y);
  double f=13;
  //printf("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx=%f,xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxhao qi guai a xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n",f);
  for(unsigned i=0;i<partParticles->size();i++){
	unsigned ph =(*partParticles)[i];
	//-------get the min of pos
	if(holeMinx>pos[ph].x){
		holeMinx = pos[ph].x;
	}
 	if(holeMiny>pos[ph].y){
		holeMiny = pos[ph].y;
	}
 	if(holeMinz>pos[ph].z){
		holeMinz = pos[ph].z;
	}
 	//.......get the max of pos
	if(holeMaxx<pos[ph].x){
		holeMaxx = pos[ph].x;
	}
 	if(holeMaxy<pos[ph].y){
		holeMaxy = pos[ph].y;
	}
 	if(holeMaxz<pos[ph].z){
		holeMaxz = pos[ph].z;
	}
  }
 
  //get the ghost domain
  double ghostMinx,ghostMiny,ghostMinz;
  double ghostMaxx,ghostMaxy,ghostMaxz;
  ghostMinx=0;
  ghostMiny=0;
  ghostMinz=0;

  ghostMaxx=0;
  ghostMaxy=0;
  ghostMaxz=0;
  //set the original values
  if(num_ghost!=0){//because of boundary processor(eg .rank 0 coming from left, last rank coming from right)
  	ghostMinx = ghostMaxx = ghostPosx[0];
  	ghostMiny = ghostMaxy = ghostPosy[0];
  	ghostMinz = ghostMaxz = ghostPosz[0];
  }
  for(unsigned i=0;i<num_ghost;i++){
	//--------get the min of pos
	if(ghostMinx>ghostPosx[i]){
		ghostMinx = ghostPosx[i];
	}
 	if(ghostMiny>ghostPosy[i]){
		ghostMiny = ghostPosy[i];
	}
 	if(ghostMinz>ghostPosz[i]){
		ghostMinz = ghostPosz[i];
	}
 	//--------get the max of pos
	if(ghostMaxx<ghostPosx[i]){
		ghostMaxx = ghostPosx[i];
	}
 	if(ghostMaxy<ghostPosy[i]){
		ghostMaxy = ghostPosy[i];
	}
 	if(ghostMaxz<ghostPosz[i]){
		ghostMaxz = ghostPosz[i];
	}
  }
  //test
//  printf("@@@@@@@@@@@@@@@hole minix[%lf]---miniy[%lf]---miniz[%lf]******maxx[%lf]****maxy[%lf]*****maxz[%lf]\n",holeMin.x,holeMin.y,holeMin.z,holeMax.x,holeMax.y,holeMax.z);
//  printf("@@@@@@@@@@@@@@@hole minix=[%f,]---miniy=[%f,]\n",holeMinx,holeMiny);

  //test
//  printf("$$$$$$$$$$$$$$$$ghost minix[%lf]---miniy[%lf]---miniz[%lf]******maxx[%lf]****maxy[%lf]*****maxz[%lf]\n",
//  ghostMin.x,ghostMin.y,ghostMin.z,ghostMax.x,ghostMax.y,ghostMax.z);

  //add all hole+ghost
  //get minimum
  tdouble3 cellMinDomain = TDouble3(0);
  cellMinDomain.x = (holeMinx<ghostMinx) ? holeMinx : ghostMinx;
  cellMinDomain.y = (holeMiny<ghostMiny) ? holeMiny : ghostMiny;
  cellMinDomain.z = (holeMinz<ghostMinz) ? holeMinz : ghostMinz;
  //get maximum
  tdouble3 cellMaxDomain = TDouble3(0);
  cellMaxDomain.x = (holeMaxx>ghostMaxx) ? holeMaxx : ghostMaxx;
  cellMaxDomain.y = (holeMaxy>ghostMaxy) ? holeMaxy : ghostMaxy;
  cellMaxDomain.z = (holeMaxz>ghostMaxz) ? holeMaxz : ghostMaxz;

  //test all
  printf("##############cell minix[%lf]---miniy[%lf]---miniz[%lf]******maxx[%lf]****maxy[%lf]*****maxz[%lf]\n",
  cellMinDomain.x,cellMinDomain.y,cellMinDomain.z,cellMaxDomain.x,cellMaxDomain.y,cellMaxDomain.z);
 
  printf("------------------rank_id=%d----(inner)interaction fluid-fluid only p1-->pfini=(%d---%d),,,,Np_max=%d\n",rank_id,pinit,pfin-1,Np_max);
  //---------------------divide the cell grid-----------------------//
  int ncellx=0; //the number of cell for direct x
  int ncelly=0; //the number of cell for direct y
  int ncellz=0; //the number of cell for direct z
  int num_cell=0;//num of the cell (x/z) 

  double edge_size=2*H; 
  ncellx =(cellMaxDomain.x - cellMinDomain.x)/edge_size+1;
  ncellz =(cellMaxDomain.z - cellMinDomain.z)/edge_size+1;
  num_cell = ncellx*ncellz;
  //test
  printf("in ghost divided: ncellx=%d, ncellz=%d,num_cell=%d\n",ncellx,ncellz,num_cell);
//  unsigned *cell_store_info = new unsigned[num_cell]();
  vector<unsigned> ghost_index_cell_store;
  unsigned *num_ghost_every_cell = new unsigned[num_cell]();
  double cell_xmin,cell_xmax;
  double cell_zmin,cell_zmax;
  for(unsigned cell_id=0;cell_id<num_cell;cell_id++){//cell id start from 0 but calculate from 1
	int tem_num=0;
	int raw = (cell_id+1)/ncellx;
	int column = (cell_id+1)%ncellx;
	if(column==0){//located right boundary
		cell_xmin = cellMinDomain.x+(ncellx-1)*edge_size;
		cell_xmax = cell_xmin+edge_size;
 		
		cell_zmin= cellMinDomain.z+(raw-1)*edge_size;
		cell_zmax= cell_zmin+edge_size;
		//ghost id start from 0(temporary position for ghost pariticles)
		for(unsigned ghost_id=0;ghost_id<num_ghost;ghost_id++){
			if(ghostPosx[ghost_id]>=cell_xmin&&ghostPosx[ghost_id]<cell_xmax&&ghostPosz[ghost_id]>=cell_zmin&&ghostPosz[ghost_id]<cell_zmax){
				ghost_index_cell_store.push_back(ghost_id);
				tem_num++;
			}	
		}
	}else{//located not right boundary
		cell_xmin = cellMinDomain.x+(column-1)*edge_size;
		cell_xmax = cell_xmin+edge_size;
		
		cell_zmin = cellMinDomain.z+raw*edge_size;
		cell_zmax = cell_zmin+edge_size;
		for(unsigned ghost_id=0;ghost_id<num_ghost;ghost_id++){
                        if(ghostPosx[ghost_id]>=cell_xmin&&ghostPosx[ghost_id]<cell_xmax&&ghostPosz[ghost_id]>=cell_zmin&&ghostPosz[ghost_id]<cell_zmax){
                                ghost_index_cell_store.push_back(ghost_id);
                                tem_num++;
                        } 
                }

	}
	num_ghost_every_cell[cell_id] = tem_num;
  }
  //test 
  int num_all=0;
  for(int i=0;i<num_cell;i++){
	num_all=num_all+num_ghost_every_cell[i];
	printf("num cell[%d]=%d, ",i,num_ghost_every_cell[i]);
  }

  if(num_all!=ghost_index_cell_store.size()){
	printf("Error--->the cell num particles:(%d) not equal to the ghost number:%d (in ghost divid)\n",num_all,ghost_index_cell_store.size());
	MPI_Abort(MPI_COMM_WORLD,20);
  }else{
	printf("xxxxxx------ghost divid is correct------xxxxx\n");
  }*/
  //delete[] ghost_index_cell_store;ghost_index_cell_store=NULL;
//  delete[] num_ghost_every_cell;num_ghost_every_cell=NULL;
////////////////////////////////////////////////////////////////////////////////////////////////////
// test
/*    unsigned q=0;
    for(q=0;q<num_ghost;q++){
	printf("ghost fluid Pos/pres--vel[%d]=(%lf,%lf,%lf,%lf---,%lf,%lf,%lf,%lf), ",q,ghostPosx[q],ghostPosy[q],ghostPosz[q],ghostPress[q],
	ghostVelx[q],ghostVely[q],ghostVelz[q],ghostVelw[q]);
    }*/
/*
    #ifdef OMP_USE
      #pragma omp parallel for schedule (guided)
    #endif*/
    for(unsigned i=0;i<partParticles->size();i++){//for 1
    unsigned p1 =(*partParticles)[i];//p1 is current index for pos (not idp)
    float visc=0,arp1=0,deltap1=0;
    tfloat3 acep1=TFloat3(0);
    tsymatrix3f gradvelp1={0,0,0,0,0,0};

    //-Variables for Shifting.
    tfloat4 shiftposfsp1;
    if(shift)shiftposfsp1=shiftposfs[p1];

    //-Obtain data of particle p1 in case of floating objects. | Obtiene datos de particula p1 en caso de existir floatings.
    bool ftp1=false;     //-Indicate if it is floating. | Indica si es floating.
    if(USE_FLOATING){
      ftp1=CODE_IsFloating(code[p1]);
      if(ftp1 && tdensity!=DDT_None)deltap1=FLT_MAX; //-DDT is not applied to floating particles.
      if(ftp1 && shift)shiftposfsp1.x=FLT_MAX;  //-For floating objects do not calculate shifting. | Para floatings no se calcula shifting.
    }

    //-Obtain data of particle p1.
    const tdouble3 posp1=pos[p1];
    const tfloat3 velp1=TFloat3(velrhop[p1].x,velrhop[p1].y,velrhop[p1].z);
    const float rhopp1=velrhop[p1].w;
    const float pressp1=press[p1];
    const tsymatrix3f taup1=(lamsps? tau[p1]: gradvelp1);
    const bool rsymp1=(Symmetry && posp1.y<=Dosh); //<vs_syymmetry>


    //-Obtain interaction limits.
    int cxini,cxfin,yini,yfin,zini,zfin;
    GetInteractionCells(dcell[p1],hdiv,nc,cellzero,cxini,cxfin,yini,yfin,zini,zfin);

    //--------------------------------------calculate ghost part localted in the side of processor-----------------------------------------------//
    //-Search for neighbours in adjacent cells.
    for(int z=zini;z<zfin;z++){//for 2
      const int zmod=(nc.w)*z+cellinitial; //-Sum from start of fluid or boundary cells. | Le suma donde empiezan las celdas de fluido o bound.
      for(int y=yini;y<yfin;y++){//for 3
        int ymod=zmod+nc.x*y;
        const unsigned pini=beginendcell[cxini+ymod];
        const unsigned pfin=beginendcell[cxfin+ymod];

        //-Interaction of Fluid with type Fluid or Bound. | Interaccion de Fluid con varias Fluid o Bound.
        //------------------------------------------------------------------------------------------------
        bool rsym=false; //<vs_syymmetry>
//	if(cellinitial!=0){printf("this is fluid-fluid interaction----->pin=%d----pfin=%d\n",pini,pfin);}
        for(unsigned p2=pini;p2<pfin;p2++){//for 4
//        for(unsigned p2=pinit;p2<pfin;p2++){
          const float drx=float(posp1.x-pos[p2].x);
                float dry=float(posp1.y-pos[p2].y);
          if(rsym)    dry=float(posp1.y+pos[p2].y); //<vs_syymmetry>
          const float drz=float(posp1.z-pos[p2].z);
          const float rr2=drx*drx+dry*dry+drz*drz;
//printf("Fourh2=%lf,H=%lf,H*H*4=%lf\n",Fourh2,H,H*H*4);
          if(rr2<=Fourh2 && rr2>=ALMOSTZERO){
            //-Cubic Spline, Wendland or Gaussian kernel.
            float frx,fry,frz;
            if(tker==KERNEL_Wendland)GetKernelWendland(rr2,drx,dry,drz,frx,fry,frz);
            else if(tker==KERNEL_Gaussian)GetKernelGaussian(rr2,drx,dry,drz,frx,fry,frz);
            else if(tker==KERNEL_Cubic)GetKernelCubic(rr2,drx,dry,drz,frx,fry,frz);

            //===== Get mass of particle p2 ===== 
//            float massp2=(boundp2? MassBound: MassFluid); //-Contiene masa de particula segun sea bound o fluid.
	    float massp2=MassFluid;
            bool ftp2=false;    //-Indicate if it is floating | Indica si es floating.
            bool compute=true;  //-Deactivate when using DEM and if it is of type float-float or float-bound | Se desactiva cuando se usa DEM y es float-float o float-bound.
            if(USE_FLOATING){
              ftp2=CODE_IsFloating(code[p2]);///******code2 need
              if(ftp2)massp2=FtObjs[CODE_GetTypeValue(code[p2])].massp;
              #ifdef DELTA_HEAVYFLOATING
                if(ftp2 && tdensity==DDT_DDT && massp2<=(MassFluid*1.2f))deltap1=FLT_MAX;
              #else
                if(ftp2 && tdensity==DDT_DDT)deltap1=FLT_MAX;
              #endif
              if(ftp2 && shift && shiftmode==SHIFT_NoBound)shiftposfsp1.x=FLT_MAX; //-With floating objects do not use shifting. | Con floatings anula shifting.
              compute=!(USE_FTEXTERNAL && ftp1 && (boundp2 || ftp2)); //-Deactivate when using DEM and if it is of type float-float or float-bound.
            }

            tfloat4 velrhop2=velrhop[p2];//******velrhop2 need
            if(rsym)velrhop2.y=-velrhop2.y; //<vs_syymmetry>
            //===== Acceleration ===== 
            if(compute){//************press2
              const float prs=(pressp1+press[p2])/(rhopp1*velrhop2.w) + (tker==KERNEL_Cubic? GetKernelCubicTensil(rr2,rhopp1,pressp1,velrhop2.w,press[p2]): 0);
              const float p_vpm=-prs*massp2;
              acep1.x+=p_vpm*frx; acep1.y+=p_vpm*fry; acep1.z+=p_vpm*frz;
            }

            //-Density derivative.
            const float dvx=velp1.x-velrhop2.x, dvy=velp1.y-velrhop2.y, dvz=velp1.z-velrhop2.z;
            if(compute)arp1+=massp2*(dvx*frx+dvy*fry+dvz*frz);

            const float cbar=(float)Cs0;
            //-Density Diffusion Term (Molteni and Colagrossi 2009).
            if(tdensity==DDT_DDT && deltap1!=FLT_MAX){
              const float rhop1over2=rhopp1/velrhop2.w;
              const float visc_densi=DDT2h*cbar*(rhop1over2-1.f)/(rr2+Eta2);
              const float dot3=(drx*frx+dry*fry+drz*frz);
              const float delta=visc_densi*dot3*massp2;
              //deltap1=(boundp2? FLT_MAX: deltap1+delta);
              deltap1=(boundp2 && TBoundary==BC_DBC? FLT_MAX: deltap1+delta);
            }

            //-Shifting correction.
            if(shift && shiftposfsp1.x!=FLT_MAX){
              const float massrhop=massp2/velrhop2.w;
              const bool noshift=(boundp2 && (shiftmode==SHIFT_NoBound || (shiftmode==SHIFT_NoFixed && CODE_IsFixed(code[p2]))));
              shiftposfsp1.x=(noshift? FLT_MAX: shiftposfsp1.x+massrhop*frx); //-For boundary do not use shifting. | Con boundary anula shifting.
              shiftposfsp1.y+=massrhop*fry;
              shiftposfsp1.z+=massrhop*frz;
              shiftposfsp1.w-=massrhop*(drx*frx+dry*fry+drz*frz);
            }

            //===== Viscosity ===== 
            if(compute){
              const float dot=drx*dvx + dry*dvy + drz*dvz;
              const float dot_rr2=dot/(rr2+Eta2);
              visc=max(dot_rr2,visc);
              if(!lamsps){//-Artificial viscosity.
                if(dot<0){
                  const float amubar=H*dot_rr2;  //amubar=CTE.h*dot/(rr2+CTE.eta2);
                  const float robar=(rhopp1+velrhop2.w)*0.5f;
                  const float pi_visc=(-visco*cbar*amubar/robar)*massp2;
                  acep1.x-=pi_visc*frx; acep1.y-=pi_visc*fry; acep1.z-=pi_visc*frz;
                }
              }
              else{//-Laminar+SPS viscosity. 
                {//-Laminar contribution.
                  const float robar2=(rhopp1+velrhop2.w);
                  const float temp=4.f*visco/((rr2+Eta2)*robar2);  //-Simplification of: temp=2.0f*visco/((rr2+CTE.eta2)*robar); robar=(rhopp1+velrhop2.w)*0.5f;
                  const float vtemp=massp2*temp*(drx*frx+dry*fry+drz*frz);  
                  acep1.x+=vtemp*dvx; acep1.y+=vtemp*dvy; acep1.z+=vtemp*dvz;
                }
                //-SPS turbulence model.
                float tau_xx=taup1.xx,tau_xy=taup1.xy,tau_xz=taup1.xz; //-taup1 is always zero when p1 is not a fluid particle. | taup1 siempre es cero cuando p1 no es fluid.
                float tau_yy=taup1.yy,tau_yz=taup1.yz,tau_zz=taup1.zz;
                if(!boundp2 && !ftp2){//-When p2 is a fluid particle. 
                  tau_xx+=tau[p2].xx; tau_xy+=tau[p2].xy; tau_xz+=tau[p2].xz;
                  tau_yy+=tau[p2].yy; tau_yz+=tau[p2].yz; tau_zz+=tau[p2].zz;
                }
                acep1.x+=massp2*(tau_xx*frx + tau_xy*fry + tau_xz*frz);
                acep1.y+=massp2*(tau_xy*frx + tau_yy*fry + tau_yz*frz);
                acep1.z+=massp2*(tau_xz*frx + tau_yz*fry + tau_zz*frz);
                //-Velocity gradients.
                if(!ftp1){//-When p1 is a fluid particle. 
                  const float volp2=-massp2/velrhop2.w;
                  float dv=dvx*volp2; gradvelp1.xx+=dv*frx; gradvelp1.xy+=dv*fry; gradvelp1.xz+=dv*frz;
                        dv=dvy*volp2; gradvelp1.xy+=dv*frx; gradvelp1.yy+=dv*fry; gradvelp1.yz+=dv*frz;
                        dv=dvz*volp2; gradvelp1.xz+=dv*frx; gradvelp1.yz+=dv*fry; gradvelp1.zz+=dv*frz;
                  //-To compute tau terms we assume that gradvel.xy=gradvel.dudy+gradvel.dvdx, gradvel.xz=gradvel.dudz+gradvel.dwdx, gradvel.yz=gradvel.dvdz+gradvel.dwdy
                  //-so only 6 elements are needed instead of 3x3.
                }
              }
            }
            rsym=(rsymp1 && !rsym && float(posp1.y-dry)<=Dosh); //<vs_syymmetry>
            if(rsym)p2--;                                       //<vs_syymmetry>
          }
          else rsym=false;                                      //<vs_syymmetry>
        }//end of p4
      }//end of p3 for get interaction cell y
    }//end of p2 for get interactoin cell z 
//-----------------------------------MPI---calculate ghost particles coming from left processor-------------------------------------//
/*
    int get_nine_cell_id[9]={0};
    int p1_cell_coordinate_x=0;
    int p1_cell_coordinate_z=0;

    int coordinate_max_x = ncellx-1;
    int coordinate_max_z = ncellz-1;

    p1_cell_coordinate_x = (posp1.x-cellMinDomain.x)/edge_size;
    p1_cell_coordinate_z = (posp1.z-cellMinDomain.z)/edge_size;

    //the four diagonals of ninth grid
    int coordinateX0=0;
    int coordinateZ0=0;
    int coordinateX2=0;
    int coordinateZ2=0;
    int coordinateX6=0;
    int coordinateZ6=0;
    int coordinateX8=0;
    int coordinateZ8=0;
    //for 1
    coordinateX0 = p1_cell_coordinate_x-1;
    coordinateZ0 = p1_cell_coordinate_z-1;
    //for 3
    coordinateX2 = p1_cell_coordinate_x+1;
    coordinateZ2 = p1_cell_coordinate_z-1;
    //for 7
    coordinateX6 = p1_cell_coordinate_x-1;
    coordinateZ6 = p1_cell_coordinate_z+1;
    //for 9
    coordinateX8 = p1_cell_coordinate_x+1;
    coordinateZ8 = p1_cell_coordinate_z+1;

    //comput id for diagonals
    get_nine_cell_id[0] = coordinateZ0*ncellx+coordinateX0+1;
    get_nine_cell_id[2] = coordinateZ2*ncellx+coordinateX2+1;
    get_nine_cell_id[6] = coordinateZ6*ncellx+coordinateX6+1;
    get_nine_cell_id[8] = coordinateZ8*ncellx+coordinateX8+1;

    //check the edge
    //left boundary
    if(p1_cell_coordinate_x==0){
	get_nine_cell_id[0]=0;
	get_nine_cell_id[3]=0;
	get_nine_cell_id[6]=0;
    }else{
	get_nine_cell_id[3]=p1_cell_coordinate_z*ncellx+(p1_cell_coordinate_x-1)+1;
    }
    //down boundary
    if(p1_cell_coordinate_z==0){
	get_nine_cell_id[0]=0;
	get_nine_cell_id[1]=0;
	get_nine_cell_id[2]=0;
    }else{
	get_nine_cell_id[1]=(p1_cell_coordinate_z-1)*ncellx+p1_cell_coordinate_x+1;
    }
    //right boundary
    if(p1_cell_coordinate_x==ncellx-1){
	get_nine_cell_id[2]=0;
	get_nine_cell_id[5]=0;
	get_nine_cell_id[8]=0;
    }else{
	get_nine_cell_id[5]=p1_cell_coordinate_z*ncellx+(p1_cell_coordinate_x+1)+1;
    }
    //up boundary
    if(p1_cell_coordinate_z==ncellz-1){
	get_nine_cell_id[6]=0;
	get_nine_cell_id[7]=0;
	get_nine_cell_id[8]=0;
    }else{
	get_nine_cell_id[7]=(p1_cell_coordinate_z+1)*ncellx+p1_cell_coordinate_x+1;
    }

    //the last is itself
    get_nine_cell_id[4] =p1_cell_coordinate_z*ncellx+p1_cell_coordinate_x+1;*/
    //test 
/*    for(int a=0;a<9;a++){
	printf("get_nine_cell_id[%d]=%d, ",a,get_nine_cell_id[a]);
    }
*/
    //get the adjacent cell
/*
    for(int cell=0;cell<9;cell++){
	int cell_id_current=get_nine_cell_id[cell];//cell id start from 1
	if(cell_id_current!=0){
        unsigned start_p2,end_p2;
	start_p2=end_p2=0;
	for(int k=0;k<cell_id_current-1;k++){//cell id =k+1
		start_p2 =start_p2+num_ghost_every_cell[k];
	}
	end_p2  =start_p2+num_ghost_every_cell[cell_id_current-1];*/
//		if(num_ghost_every_cell[k-1]!=0){
//			temp_start_p2 =temp_satrt_p2+num_ghost_every_cell[k-1];
//		}i
//        }
//	start_p2 = temp_start_p2-1;
//	end_p2 = start_p2+num_ghost_every_cell[cell_id-1];
//------------------------get the adjacent particles--------------------------------------------//
        bool rsym=false; //<vs_syymmetry>
        for(unsigned p2=0;p2<num_ghost;p2++){//for ghost particles p2, rank 0----->num_ghost=0(num_ghost_coming_left)
//	for(unsigned p22=start_p2;p22<end_p2;p22++){
//	  unsigned p2 = ghost_index_cell_store[p22];
          const float drx=float(posp1.x-ghostPosx[p2]);
                float dry=float(posp1.y-ghostPosy[p2]);
          if(rsym)    dry=float(posp1.y+ghostPosy[p2]); //<vs_syymmetry>
          const float drz=float(posp1.z-ghostPosz[p2]);
          const float rr2=drx*drx+dry*dry+drz*drz;

          if(rr2<=Fourh2 && rr2>=ALMOSTZERO){
            //-Cubic Spline, Wendland or Gaussian kernel.
            float frx,fry,frz;
            if(tker==KERNEL_Wendland)GetKernelWendland(rr2,drx,dry,drz,frx,fry,frz);
            else if(tker==KERNEL_Gaussian)GetKernelGaussian(rr2,drx,dry,drz,frx,fry,frz);
            else if(tker==KERNEL_Cubic)GetKernelCubic(rr2,drx,dry,drz,frx,fry,frz);

            //===== Get mass of particle p2 ===== 
//            float massp2=(boundp2? MassBound: MassFluid); //-Contiene masa de particula segun sea bound o fluid.
	    float massp2 = MassFluid;
            bool ftp2=false;    //-Indicate if it is floating | Indica si es floating.
            bool compute=true;  //-Deactivate when using DEM and if it is of type float-float or float-bound | Se desactiva cuando se usa DEM y es float-float o float-bound.
            if(USE_FLOATING){
              ftp2=CODE_IsFloating(0x1800);///******code2 need
              if(ftp2)massp2=FtObjs[CODE_GetTypeValue(0x1800)].massp;
              #ifdef DELTA_HEAVYFLOATING
                if(ftp2 && tdensity==DDT_DDT && massp2<=(MassFluid*1.2f))deltap1=FLT_MAX;
              #else
                if(ftp2 && tdensity==DDT_DDT)deltap1=FLT_MAX;
              #endif
              if(ftp2 && shift && shiftmode==SHIFT_NoBound)shiftposfsp1.x=FLT_MAX; //-With floating objects do not use shifting. | Con floatings anula shifting.
              compute=!(USE_FTEXTERNAL && ftp1 && (boundp2 || ftp2)); //-Deactivate when using DEM and if it is of type float-float or float-bound. 
            }

//            tfloat4 velrhop2=velrhop[p2];//******velrhop2 need
	    tfloat4 velrhop2;
	    velrhop2.x = ghostVelx[p2];
	    velrhop2.y = ghostVely[p2];
	    velrhop2.z = ghostVelz[p2];
	    velrhop2.w = ghostVelw[p2];

            if(rsym)velrhop2.y=-velrhop2.y; //<vs_syymmetry>
            //===== Acceleration ===== 
            if(compute){//************press2
              const float prs=(pressp1+ghostPress[p2])/(rhopp1*velrhop2.w) + (tker==KERNEL_Cubic? GetKernelCubicTensil(rr2,rhopp1,pressp1,velrhop2.w,ghostPress[p2]): 0);
              const float p_vpm=-prs*massp2;
              acep1.x+=p_vpm*frx; acep1.y+=p_vpm*fry; acep1.z+=p_vpm*frz;
            }

            //-Density derivative.
            const float dvx=velp1.x-velrhop2.x, dvy=velp1.y-velrhop2.y, dvz=velp1.z-velrhop2.z;
            if(compute)arp1+=massp2*(dvx*frx+dvy*fry+dvz*frz);

            const float cbar=(float)Cs0;
            //-Density Diffusion Term (Molteni and Colagrossi 2009).
            if(tdensity==DDT_DDT && deltap1!=FLT_MAX){
              const float rhop1over2=rhopp1/velrhop2.w;
              const float visc_densi=DDT2h*cbar*(rhop1over2-1.f)/(rr2+Eta2);
              const float dot3=(drx*frx+dry*fry+drz*frz);
              const float delta=visc_densi*dot3*massp2;
              //deltap1=(boundp2? FLT_MAX: deltap1+delta);
              deltap1=(boundp2 && TBoundary==BC_DBC? FLT_MAX: deltap1+delta);
            }

            //-Shifting correction.
            if(shift && shiftposfsp1.x!=FLT_MAX){
              const float massrhop=massp2/velrhop2.w;
              const bool noshift=(boundp2 && (shiftmode==SHIFT_NoBound || (shiftmode==SHIFT_NoFixed && CODE_IsFixed(0x1800))));
              shiftposfsp1.x=(noshift? FLT_MAX: shiftposfsp1.x+massrhop*frx); //-For boundary do not use shifting. | Con boundary anula shifting.
              shiftposfsp1.y+=massrhop*fry;
              shiftposfsp1.z+=massrhop*frz;
              shiftposfsp1.w-=massrhop*(drx*frx+dry*fry+drz*frz);
            }

            //===== Viscosity ===== 
            if(compute){
              const float dot=drx*dvx + dry*dvy + drz*dvz;
              const float dot_rr2=dot/(rr2+Eta2);
              visc=max(dot_rr2,visc);
              if(!lamsps){//-Artificial viscosity.
                if(dot<0){
                  const float amubar=H*dot_rr2;  //amubar=CTE.h*dot/(rr2+CTE.eta2);
                  const float robar=(rhopp1+velrhop2.w)*0.5f;
                  const float pi_visc=(-visco*cbar*amubar/robar)*massp2;
                  acep1.x-=pi_visc*frx; acep1.y-=pi_visc*fry; acep1.z-=pi_visc*frz;
                }
              }
              else{//-Laminar+SPS viscosity. 
                printf("MPI++++++++++++++SPS----?????????????\n");
		{//-Laminar contribution.
                  const float robar2=(rhopp1+velrhop2.w);
                  const float temp=4.f*visco/((rr2+Eta2)*robar2);  //-Simplification of: temp=2.0f*visco/((rr2+CTE.eta2)*robar); robar=(rhopp1+velrhop2.w)*0.5f;
                  const float vtemp=massp2*temp*(drx*frx+dry*fry+drz*frz);  
                  acep1.x+=vtemp*dvx; acep1.y+=vtemp*dvy; acep1.z+=vtemp*dvz;
                }
                //-SPS turbulence model.
                float tau_xx=taup1.xx,tau_xy=taup1.xy,tau_xz=taup1.xz; //-taup1 is always zero when p1 is not a fluid particle. | taup1 siempre es cero cuando p1 no es fluid.
                float tau_yy=taup1.yy,tau_yz=taup1.yz,tau_zz=taup1.zz;
/*                if(!boundp2 && !ftp2){//-When p2 is a fluid particle.//for DEM 
                  tau_xx+=tau[p2].xx; tau_xy+=tau[p2].xy; tau_xz+=tau[p2].xz;
                  tau_yy+=tau[p2].yy; tau_yz+=tau[p2].yz; tau_zz+=tau[p2].zz;
                }*/
                acep1.x+=massp2*(tau_xx*frx + tau_xy*fry + tau_xz*frz);
                acep1.y+=massp2*(tau_xy*frx + tau_yy*fry + tau_yz*frz);
                acep1.z+=massp2*(tau_xz*frx + tau_yz*fry + tau_zz*frz);
                //-Velocity gradients.
                if(!ftp1){//-When p1 is a fluid particle. 
                  const float volp2=-massp2/velrhop2.w;
                  float dv=dvx*volp2; gradvelp1.xx+=dv*frx; gradvelp1.xy+=dv*fry; gradvelp1.xz+=dv*frz;
                        dv=dvy*volp2; gradvelp1.xy+=dv*frx; gradvelp1.yy+=dv*fry; gradvelp1.yz+=dv*frz;
                        dv=dvz*volp2; gradvelp1.xz+=dv*frx; gradvelp1.yz+=dv*fry; gradvelp1.zz+=dv*frz;
                  //-To compute tau terms we assume that gradvel.xy=gradvel.dudy+gradvel.dvdx, gradvel.xz=gradvel.dudz+gradvel.dwdx, gradvel.yz=gradvel.dvdz+gradvel.dwdy
                  //-so only 6 elements are needed instead of 3x3.
                }
              }//end !lamsps
            }//end compute
            rsym=(rsymp1 && !rsym && float(posp1.y-dry)<=Dosh); //<vs_syymmetry>
            if(rsym)p2--;                                       //<vs_syymmetry>
          }else{
		 rsym=false;         				//<vs_syymmetry>
	  } //end of if adjacent particles                      
        }//end of for ghost p2
  /////////
//      }//end if cell id not equal to 0
//    }//end for adjacent cell
 //free memory
 //    delete[] num_ghost_every_cell;num_ghost_every_cell=NULL;
//--------------------------------------------------END of other side calculate-----------------------------------------------------//
    //-Sum results together. | Almacena resultados.
    if(shift||arp1||acep1.x||acep1.y||acep1.z||visc){
      if(tdensity!=DDT_None){
        if(delta)delta[p1]=(delta[p1]==FLT_MAX || deltap1==FLT_MAX? FLT_MAX: delta[p1]+deltap1);
        else if(deltap1!=FLT_MAX)arp1+=deltap1;
      }
      ar[p1]+=arp1;//density
      ace[p1]=ace[p1]+acep1;//overloaded scalar computation
      const int th=omp_get_thread_num();
      if(visc>viscth[th*OMP_STRIDE])viscth[th*OMP_STRIDE]=visc;
      if(lamsps){
        gradvel[p1].xx+=gradvelp1.xx;
        gradvel[p1].xy+=gradvelp1.xy;
        gradvel[p1].xz+=gradvelp1.xz;
        gradvel[p1].yy+=gradvelp1.yy;
        gradvel[p1].yz+=gradvelp1.yz;
        gradvel[p1].zz+=gradvelp1.zz;
      }
      if(shift)shiftposfs[p1]=shiftposfsp1;
    }
  }//end of p1
 //////////////free memory//////////////////////////////////////
//   delete[] num_ghost_every_cell;num_ghost_every_cell=NULL;
 ///////////////////////////////////////////////////////////////
  //-Keep max value in viscdt. | Guarda en viscdt el valor maximo.
  for(int th=0;th<OmpThreads;th++)if(viscdt<viscth[th*OMP_STRIDE])viscdt=viscth[th*OMP_STRIDE];
}



//MPI----left hole-----interaction fluid-fluid only------------using full pairing
//==============================================================================
/// Perform interaction between particles: Fluid/Float-Fluid/Float or Fluid/Float-Bound
/// Realiza interaccion entre particulas: Fluid/Float-Fluid/Float or Fluid/Float-Bound
//==============================================================================
template<TpKernel tker,TpFtMode ftmode,bool lamsps,TpDensity tdensity,bool shift> 
  void JSphCpu::MPI_Hole_InteractionForcesFluidFluidOnly
  (unsigned n,unsigned pinit,tint4 nc,int hdiv,unsigned cellinitial,float visco
  ,const unsigned *beginendcell,tint3 cellzero,const unsigned *dcell
  ,const tsymatrix3f* tau,tsymatrix3f* gradvel
  ,const tdouble3 *pos,const tfloat4 *velrhop,const typecode *code,const unsigned *idp
  ,const float *press 
  ,float &viscdt,float *ar,tfloat3 *ace,float *delta
  ,TpShifting shiftmode,tfloat4 *shiftposfs,double procMinlimit,double procMaxlimit,const std::vector<unsigned>* partParticles,const unsigned num_ghost
  ,const double* ghostPosx,const double* ghostPosy,const double* ghostPosz,const float* ghostPress
  ,const float* ghostVelx,const float* ghostVely,const float* ghostVelz,const float* ghostVelw )const
{//partparticles include ghost particles(left/right) and not ghost particles
//n  is number of fuild particles idp is particles for fuild
  const bool boundp2=(!cellinitial); //-Interaction with type boundary (Bound). | Interaccion con Bound.
  //-Initialize viscth to calculate viscdt maximo con OpenMP. | Inicializa viscth para calcular visdt maximo con OpenMP.
  float viscth[OMP_MAXTHREADS*OMP_STRIDE];
  for(int th=0;th<OmpThreads;th++)viscth[th*OMP_STRIDE]=0;
  //-Initialise execution with OpenMP. | Inicia ejecucion con OpenMP.
  const int pfin=int(pinit+n);
////////////////////
    int rank_id=mpi_rank_id;
    int proc_size=mpi_rank_size;
//  MPI_Comm_rank(MPI_COMM_WORLD,&rank_id);
//  MPI_Comm_size(MPI_COMM_WORLD,&proc_size);
  printf("------------------rank_id=%d----(inner)interaction fluid-fluid only p1-->pfini=(%d---%d),,,,Np_max=%d\n",rank_id,pinit,pfin-1,Np_max);
//  if(rank_id==0)printf("-------rank_id=0----(inner) Np=%d\n",Np);

// test
/*    unsigned q=0;
    for(q=0;q<num_ghost;q++){
	printf("ghost fluid Pos/pres--vel[%d]=(%lf,%lf,%lf,%lf---,%lf,%lf,%lf,%lf), ",q,ghostPosx[q],ghostPosy[q],ghostPosz[q],ghostPress[q],
	ghostVelx[q],ghostVely[q],ghostVelz[q],ghostVelw[q]);
    }*/
int numProcs = omp_get_num_procs();
printf("left---------right----------interaction omp threads:%d\n", numProcs);
    #ifdef OMP_USE
      #pragma omp parallel for schedule (guided)
    #endif
    for(unsigned i=0;i<partParticles->size();i++){//for 1
    unsigned p1 =(*partParticles)[i];//p1 is current index for pos (not idp)
    float visc=0,arp1=0,deltap1=0;
    tfloat3 acep1=TFloat3(0);
    tsymatrix3f gradvelp1={0,0,0,0,0,0};

    //-Variables for Shifting.
    tfloat4 shiftposfsp1;
    if(shift)shiftposfsp1=shiftposfs[p1];

    //-Obtain data of particle p1 in case of floating objects. | Obtiene datos de particula p1 en caso de existir floatings.
    bool ftp1=false;     //-Indicate if it is floating. | Indica si es floating.
    if(USE_FLOATING){
      ftp1=CODE_IsFloating(code[p1]);
      if(ftp1 && tdensity!=DDT_None)deltap1=FLT_MAX; //-DDT is not applied to floating particles.
      if(ftp1 && shift)shiftposfsp1.x=FLT_MAX;  //-For floating objects do not calculate shifting. | Para floatings no se calcula shifting.
    }

    //-Obtain data of particle p1.
    const tdouble3 posp1=pos[p1];
    const tfloat3 velp1=TFloat3(velrhop[p1].x,velrhop[p1].y,velrhop[p1].z);
    const float rhopp1=velrhop[p1].w;
    const float pressp1=press[p1];
    const tsymatrix3f taup1=(lamsps? tau[p1]: gradvelp1);
    const bool rsymp1=(Symmetry && posp1.y<=Dosh); //<vs_syymmetry>


    //-Obtain interaction limits.
    int cxini,cxfin,yini,yfin,zini,zfin;
    GetInteractionCells(dcell[p1],hdiv,nc,cellzero,cxini,cxfin,yini,yfin,zini,zfin);

    //--------------------------------------calculate ghost part localted in the side of processor-----------------------------------------------//
    //-Search for neighbours in adjacent cells.
    for(int z=zini;z<zfin;z++){//for 2
      const int zmod=(nc.w)*z+cellinitial; //-Sum from start of fluid or boundary cells. | Le suma donde empiezan las celdas de fluido o bound.
      for(int y=yini;y<yfin;y++){//for 3
        int ymod=zmod+nc.x*y;
        const unsigned pini=beginendcell[cxini+ymod];
        const unsigned pfin=beginendcell[cxfin+ymod];

        //-Interaction of Fluid with type Fluid or Bound. | Interaccion de Fluid con varias Fluid o Bound.
        //------------------------------------------------------------------------------------------------
        bool rsym=false; //<vs_syymmetry>
//	if(cellinitial!=0){printf("this is fluid-fluid interaction----->pin=%d----pfin=%d\n",pini,pfin);}
        for(unsigned p2=pini;p2<pfin;p2++){//for 4
//        for(unsigned p2=int(pinit)+1;p2<pfin;p2++){
          const float drx=float(posp1.x-pos[p2].x);
                float dry=float(posp1.y-pos[p2].y);
          if(rsym)    dry=float(posp1.y+pos[p2].y); //<vs_syymmetry>
          const float drz=float(posp1.z-pos[p2].z);
          const float rr2=drx*drx+dry*dry+drz*drz;
//printf("Fourh2=%lf,H=%lf,H*H*4=%lf\n",Fourh2,H,H*H*4);
          if(rr2<=Fourh2 && rr2>=ALMOSTZERO){
            //-Cubic Spline, Wendland or Gaussian kernel.
            float frx,fry,frz;
            if(tker==KERNEL_Wendland)GetKernelWendland(rr2,drx,dry,drz,frx,fry,frz);
            else if(tker==KERNEL_Gaussian)GetKernelGaussian(rr2,drx,dry,drz,frx,fry,frz);
            else if(tker==KERNEL_Cubic)GetKernelCubic(rr2,drx,dry,drz,frx,fry,frz);

            //===== Get mass of particle p2 ===== 
            float massp2=(boundp2? MassBound: MassFluid); //-Contiene masa de particula segun sea bound o fluid.
            bool ftp2=false;    //-Indicate if it is floating | Indica si es floating.
            bool compute=true;  //-Deactivate when using DEM and if it is of type float-float or float-bound | Se desactiva cuando se usa DEM y es float-float o float-bound.
            if(USE_FLOATING){
              ftp2=CODE_IsFloating(code[p2]);///******code2 need
              if(ftp2)massp2=FtObjs[CODE_GetTypeValue(code[p2])].massp;
              #ifdef DELTA_HEAVYFLOATING
                if(ftp2 && tdensity==DDT_DDT && massp2<=(MassFluid*1.2f))deltap1=FLT_MAX;
              #else
                if(ftp2 && tdensity==DDT_DDT)deltap1=FLT_MAX;
              #endif
              if(ftp2 && shift && shiftmode==SHIFT_NoBound)shiftposfsp1.x=FLT_MAX; //-With floating objects do not use shifting. | Con floatings anula shifting.
              compute=!(USE_FTEXTERNAL && ftp1 && (boundp2 || ftp2)); //-Deactivate when using DEM and if it is of type float-float or float-bound. | Se desactiva cuando se usa DEM y es float-float o float-bound.
            }

            tfloat4 velrhop2=velrhop[p2];//******velrhop2 need
            if(rsym)velrhop2.y=-velrhop2.y; //<vs_syymmetry>
            //===== Acceleration ===== 
            if(compute){//************press2
              const float prs=(pressp1+press[p2])/(rhopp1*velrhop2.w) + (tker==KERNEL_Cubic? GetKernelCubicTensil(rr2,rhopp1,pressp1,velrhop2.w,press[p2]): 0);
              const float p_vpm=-prs*massp2;
              acep1.x+=p_vpm*frx; acep1.y+=p_vpm*fry; acep1.z+=p_vpm*frz;
            }

            //-Density derivative.
            const float dvx=velp1.x-velrhop2.x, dvy=velp1.y-velrhop2.y, dvz=velp1.z-velrhop2.z;
            if(compute)arp1+=massp2*(dvx*frx+dvy*fry+dvz*frz);

            const float cbar=(float)Cs0;
            //-Density Diffusion Term (Molteni and Colagrossi 2009).
            if(tdensity==DDT_DDT && deltap1!=FLT_MAX){
              const float rhop1over2=rhopp1/velrhop2.w;
              const float visc_densi=DDT2h*cbar*(rhop1over2-1.f)/(rr2+Eta2);
              const float dot3=(drx*frx+dry*fry+drz*frz);
              const float delta=visc_densi*dot3*massp2;
              //deltap1=(boundp2? FLT_MAX: deltap1+delta);
              deltap1=(boundp2 && TBoundary==BC_DBC? FLT_MAX: deltap1+delta);
            }

            //-Shifting correction.
            if(shift && shiftposfsp1.x!=FLT_MAX){
              const float massrhop=massp2/velrhop2.w;
              const bool noshift=(boundp2 && (shiftmode==SHIFT_NoBound || (shiftmode==SHIFT_NoFixed && CODE_IsFixed(code[p2]))));
              shiftposfsp1.x=(noshift? FLT_MAX: shiftposfsp1.x+massrhop*frx); //-For boundary do not use shifting. | Con boundary anula shifting.
              shiftposfsp1.y+=massrhop*fry;
              shiftposfsp1.z+=massrhop*frz;
              shiftposfsp1.w-=massrhop*(drx*frx+dry*fry+drz*frz);
            }

            //===== Viscosity ===== 
            if(compute){
              const float dot=drx*dvx + dry*dvy + drz*dvz;
              const float dot_rr2=dot/(rr2+Eta2);
              visc=max(dot_rr2,visc);
              if(!lamsps){//-Artificial viscosity.
                if(dot<0){
                  const float amubar=H*dot_rr2;  //amubar=CTE.h*dot/(rr2+CTE.eta2);
                  const float robar=(rhopp1+velrhop2.w)*0.5f;
                  const float pi_visc=(-visco*cbar*amubar/robar)*massp2;
                  acep1.x-=pi_visc*frx; acep1.y-=pi_visc*fry; acep1.z-=pi_visc*frz;
                }
              }
              else{//-Laminar+SPS viscosity. 
                {//-Laminar contribution.
                  const float robar2=(rhopp1+velrhop2.w);
                  const float temp=4.f*visco/((rr2+Eta2)*robar2);  //-Simplification of: temp=2.0f*visco/((rr2+CTE.eta2)*robar); robar=(rhopp1+velrhop2.w)*0.5f;
                  const float vtemp=massp2*temp*(drx*frx+dry*fry+drz*frz);  
                  acep1.x+=vtemp*dvx; acep1.y+=vtemp*dvy; acep1.z+=vtemp*dvz;
                }
                //-SPS turbulence model.
                float tau_xx=taup1.xx,tau_xy=taup1.xy,tau_xz=taup1.xz; //-taup1 is always zero when p1 is not a fluid particle. | taup1 siempre es cero cuando p1 no es fluid.
                float tau_yy=taup1.yy,tau_yz=taup1.yz,tau_zz=taup1.zz;
                if(!boundp2 && !ftp2){//-When p2 is a fluid particle. 
                  tau_xx+=tau[p2].xx; tau_xy+=tau[p2].xy; tau_xz+=tau[p2].xz;
                  tau_yy+=tau[p2].yy; tau_yz+=tau[p2].yz; tau_zz+=tau[p2].zz;
                }
                acep1.x+=massp2*(tau_xx*frx + tau_xy*fry + tau_xz*frz);
                acep1.y+=massp2*(tau_xy*frx + tau_yy*fry + tau_yz*frz);
                acep1.z+=massp2*(tau_xz*frx + tau_yz*fry + tau_zz*frz);
                //-Velocity gradients.
                if(!ftp1){//-When p1 is a fluid particle. 
                  const float volp2=-massp2/velrhop2.w;
                  float dv=dvx*volp2; gradvelp1.xx+=dv*frx; gradvelp1.xy+=dv*fry; gradvelp1.xz+=dv*frz;
                        dv=dvy*volp2; gradvelp1.xy+=dv*frx; gradvelp1.yy+=dv*fry; gradvelp1.yz+=dv*frz;
                        dv=dvz*volp2; gradvelp1.xz+=dv*frx; gradvelp1.yz+=dv*fry; gradvelp1.zz+=dv*frz;
                  //-To compute tau terms we assume that gradvel.xy=gradvel.dudy+gradvel.dvdx, gradvel.xz=gradvel.dudz+gradvel.dwdx, gradvel.yz=gradvel.dvdz+gradvel.dwdy
                  //-so only 6 elements are needed instead of 3x3.
                }
              }
            }
            rsym=(rsymp1 && !rsym && float(posp1.y-dry)<=Dosh); //<vs_syymmetry>
            if(rsym)p2--;                                       //<vs_syymmetry>
          }
          else rsym=false;                                      //<vs_syymmetry>
        }//end of p4
      }//end of p3 for get interaction cell y
    }//end of p2 for get interactoin cell z 
//-----------------------------------MPI---calculate ghost particles coming from left processor-------------------------------------//
        bool rsym=false; //<vs_syymmetry>
        for(unsigned p2=0;p2<num_ghost;p2++){//for ghost particles p2, rank 0----->num_ghost=0(num_ghost_coming_left)
          const float drx=float(posp1.x-ghostPosx[p2]);
                float dry=float(posp1.y-ghostPosy[p2]);
          if(rsym)    dry=float(posp1.y+ghostPosy[p2]); //<vs_syymmetry>
          const float drz=float(posp1.z-ghostPosz[p2]);
          const float rr2=drx*drx+dry*dry+drz*drz;

          if(rr2<=Fourh2 && rr2>=ALMOSTZERO){
            //-Cubic Spline, Wendland or Gaussian kernel.
            float frx,fry,frz;
            if(tker==KERNEL_Wendland)GetKernelWendland(rr2,drx,dry,drz,frx,fry,frz);
            else if(tker==KERNEL_Gaussian)GetKernelGaussian(rr2,drx,dry,drz,frx,fry,frz);
            else if(tker==KERNEL_Cubic)GetKernelCubic(rr2,drx,dry,drz,frx,fry,frz);

            //===== Get mass of particle p2 ===== 
            float massp2=(boundp2? MassBound: MassFluid); //-Contiene masa de particula segun sea bound o fluid.
            bool ftp2=false;    //-Indicate if it is floating | Indica si es floating.
            bool compute=true;  //-Deactivate when using DEM and if it is of type float-float or float-bound | Se desactiva cuando se usa DEM y es float-float o float-bound.
            if(USE_FLOATING){
              ftp2=CODE_IsFloating(0x1800);///******code2 need
              if(ftp2)massp2=FtObjs[CODE_GetTypeValue(0x1800)].massp;
              #ifdef DELTA_HEAVYFLOATING
                if(ftp2 && tdensity==DDT_DDT && massp2<=(MassFluid*1.2f))deltap1=FLT_MAX;
              #else
                if(ftp2 && tdensity==DDT_DDT)deltap1=FLT_MAX;
              #endif
              if(ftp2 && shift && shiftmode==SHIFT_NoBound)shiftposfsp1.x=FLT_MAX; //-With floating objects do not use shifting. | Con floatings anula shifting.
              compute=!(USE_FTEXTERNAL && ftp1 && (boundp2 || ftp2)); //-Deactivate when using DEM and if it is of type float-float or float-bound. 
            }

//            tfloat4 velrhop2=velrhop[p2];//******velrhop2 need
	    tfloat4 velrhop2;
	    velrhop2.x = ghostVelx[p2];
	    velrhop2.y = ghostVely[p2];
	    velrhop2.z = ghostVelz[p2];
	    velrhop2.w = ghostVelw[p2];

            if(rsym)velrhop2.y=-velrhop2.y; //<vs_syymmetry>
            //===== Acceleration ===== 
            if(compute){//************press2
              const float prs=(pressp1+ghostPress[p2])/(rhopp1*velrhop2.w) + (tker==KERNEL_Cubic? GetKernelCubicTensil(rr2,rhopp1,pressp1,velrhop2.w,ghostPress[p2]): 0);
              const float p_vpm=-prs*massp2;
              acep1.x+=p_vpm*frx; acep1.y+=p_vpm*fry; acep1.z+=p_vpm*frz;
            }

            //-Density derivative.
            const float dvx=velp1.x-velrhop2.x, dvy=velp1.y-velrhop2.y, dvz=velp1.z-velrhop2.z;
            if(compute)arp1+=massp2*(dvx*frx+dvy*fry+dvz*frz);

            const float cbar=(float)Cs0;
            //-Density Diffusion Term (Molteni and Colagrossi 2009).
            if(tdensity==DDT_DDT && deltap1!=FLT_MAX){
              const float rhop1over2=rhopp1/velrhop2.w;
              const float visc_densi=DDT2h*cbar*(rhop1over2-1.f)/(rr2+Eta2);
              const float dot3=(drx*frx+dry*fry+drz*frz);
              const float delta=visc_densi*dot3*massp2;
              //deltap1=(boundp2? FLT_MAX: deltap1+delta);
              deltap1=(boundp2 && TBoundary==BC_DBC? FLT_MAX: deltap1+delta);
            }

            //-Shifting correction.
            if(shift && shiftposfsp1.x!=FLT_MAX){
              const float massrhop=massp2/velrhop2.w;
              const bool noshift=(boundp2 && (shiftmode==SHIFT_NoBound || (shiftmode==SHIFT_NoFixed && CODE_IsFixed(0x1800))));
              shiftposfsp1.x=(noshift? FLT_MAX: shiftposfsp1.x+massrhop*frx); //-For boundary do not use shifting. | Con boundary anula shifting.
              shiftposfsp1.y+=massrhop*fry;
              shiftposfsp1.z+=massrhop*frz;
              shiftposfsp1.w-=massrhop*(drx*frx+dry*fry+drz*frz);
            }

            //===== Viscosity ===== 
            if(compute){
              const float dot=drx*dvx + dry*dvy + drz*dvz;
              const float dot_rr2=dot/(rr2+Eta2);
              visc=max(dot_rr2,visc);
              if(!lamsps){//-Artificial viscosity.
                if(dot<0){
                  const float amubar=H*dot_rr2;  //amubar=CTE.h*dot/(rr2+CTE.eta2);
                  const float robar=(rhopp1+velrhop2.w)*0.5f;
                  const float pi_visc=(-visco*cbar*amubar/robar)*massp2;
                  acep1.x-=pi_visc*frx; acep1.y-=pi_visc*fry; acep1.z-=pi_visc*frz;
                }
              }
              else{//-Laminar+SPS viscosity. 
                printf("MPI++++++++++++++SPS----?????????????\n");
		{//-Laminar contribution.
                  const float robar2=(rhopp1+velrhop2.w);
                  const float temp=4.f*visco/((rr2+Eta2)*robar2);  //-Simplification of: temp=2.0f*visco/((rr2+CTE.eta2)*robar); robar=(rhopp1+velrhop2.w)*0.5f;
                  const float vtemp=massp2*temp*(drx*frx+dry*fry+drz*frz);  
                  acep1.x+=vtemp*dvx; acep1.y+=vtemp*dvy; acep1.z+=vtemp*dvz;
                }
                //-SPS turbulence model.
                float tau_xx=taup1.xx,tau_xy=taup1.xy,tau_xz=taup1.xz; //-taup1 is always zero when p1 is not a fluid particle. | taup1 siempre es cero cuando p1 no es fluid.
                float tau_yy=taup1.yy,tau_yz=taup1.yz,tau_zz=taup1.zz;
/*                if(!boundp2 && !ftp2){//-When p2 is a fluid particle.//for DEM 
                  tau_xx+=tau[p2].xx; tau_xy+=tau[p2].xy; tau_xz+=tau[p2].xz;
                  tau_yy+=tau[p2].yy; tau_yz+=tau[p2].yz; tau_zz+=tau[p2].zz;
                }*/
                acep1.x+=massp2*(tau_xx*frx + tau_xy*fry + tau_xz*frz);
                acep1.y+=massp2*(tau_xy*frx + tau_yy*fry + tau_yz*frz);
                acep1.z+=massp2*(tau_xz*frx + tau_yz*fry + tau_zz*frz);
                //-Velocity gradients.
                if(!ftp1){//-When p1 is a fluid particle. 
                  const float volp2=-massp2/velrhop2.w;
                  float dv=dvx*volp2; gradvelp1.xx+=dv*frx; gradvelp1.xy+=dv*fry; gradvelp1.xz+=dv*frz;
                        dv=dvy*volp2; gradvelp1.xy+=dv*frx; gradvelp1.yy+=dv*fry; gradvelp1.yz+=dv*frz;
                        dv=dvz*volp2; gradvelp1.xz+=dv*frx; gradvelp1.yz+=dv*fry; gradvelp1.zz+=dv*frz;
                  //-To compute tau terms we assume that gradvel.xy=gradvel.dudy+gradvel.dvdx, gradvel.xz=gradvel.dudz+gradvel.dwdx, gradvel.yz=gradvel.dvdz+gradvel.dwdy
                  //-so only 6 elements are needed instead of 3x3.
                }
              }//end !lamsps
            }//end compute
            rsym=(rsymp1 && !rsym && float(posp1.y-dry)<=Dosh); //<vs_syymmetry>
            if(rsym)p2--;                                       //<vs_syymmetry>
          }else{
		 rsym=false;         				//<vs_syymmetry>
	  } //end of if adjacent particles                      
        }//end of for ghost p2
 
//--------------------------------------------------END of other side calculate-----------------------------------------------------//
    //-Sum results together. | Almacena resultados.
    if(shift||arp1||acep1.x||acep1.y||acep1.z||visc){
      if(tdensity!=DDT_None){
        if(delta)delta[p1]=(delta[p1]==FLT_MAX || deltap1==FLT_MAX? FLT_MAX: delta[p1]+deltap1);
        else if(deltap1!=FLT_MAX)arp1+=deltap1;
      }
      ar[p1]+=arp1;//density
      ace[p1]=ace[p1]+acep1;//overloaded scalar computation
      const int th=omp_get_thread_num();
      if(visc>viscth[th*OMP_STRIDE])viscth[th*OMP_STRIDE]=visc;
      if(lamsps){
        gradvel[p1].xx+=gradvelp1.xx;
        gradvel[p1].xy+=gradvelp1.xy;
        gradvel[p1].xz+=gradvelp1.xz;
        gradvel[p1].yy+=gradvelp1.yy;
        gradvel[p1].yz+=gradvelp1.yz;
        gradvel[p1].zz+=gradvelp1.zz;
      }
      if(shift)shiftposfs[p1]=shiftposfsp1;
    }
  }//end of p1
  //-Keep max value in viscdt. | Guarda en viscdt el valor maximo.
  for(int th=0;th<OmpThreads;th++)if(viscdt<viscth[th*OMP_STRIDE])viscdt=viscth[th*OMP_STRIDE];
}


//MPI----right hole-----interactoin fluid-fluid only
//==============================================================================
/// Perform interaction between particles: Fluid/Float-Fluid/Float or Fluid/Float-Bound
/// Realiza interaccion entre particulas: Fluid/Float-Fluid/Float or Fluid/Float-Bound
//==============================================================================
template<TpKernel tker,TpFtMode ftmode,bool lamsps,TpDensity tdensity,bool shift> 
  void JSphCpu::MPI_Right_Hole_InteractionForcesFluidFluidOnly
  (unsigned n,unsigned pinit,tint4 nc,int hdiv,unsigned cellinitial,float visco
  ,const unsigned *beginendcell,tint3 cellzero,const unsigned *dcell
  ,const tsymatrix3f* tau,tsymatrix3f* gradvel
  ,const tdouble3 *pos,const tfloat4 *velrhop,const typecode *code,const unsigned *idp
  ,const float *press 
  ,float &viscdt,float *ar,tfloat3 *ace,float *delta
  ,TpShifting shiftmode,tfloat4 *shiftposfs,double procMinlimit,double procMaxlimit,const std::vector<unsigned>* partParticles)const
{//partparticles include ghost particles(left/right) and not ghost particles
//n  is number of fuild particles idp is particles for fuild
  const bool boundp2=(!cellinitial); //-Interaction with type boundary (Bound). | Interaccion con Bound.
  //-Initialize viscth to calculate viscdt maximo con OpenMP. | Inicializa viscth para calcular visdt maximo con OpenMP.
  float viscth[OMP_MAXTHREADS*OMP_STRIDE];
  for(int th=0;th<OmpThreads;th++)viscth[th*OMP_STRIDE]=0;
  //-Initialise execution with OpenMP. | Inicia ejecucion con OpenMP.
  const int pfin=int(pinit+n);
////////////////////
    int rank_id=mpi_rank_id;
    int proc_size=mpi_rank_size;
//  MPI_Comm_rank(MPI_COMM_WORLD,&rank_id);
//  MPI_Comm_size(MPI_COMM_WORLD,&proc_size);
  printf("------------------rank_id=%d----(inner)interaction fluid-fluid only p1-->pfini=(%d---%d),,,,Np_max=%d\n",rank_id,pinit,pfin-1,Np_max);
  if(rank_id==0)printf("-------rank_id=0----(inner) Np=%d\n",Np);
/*
    #ifdef OMP_USE
      #pragma omp parallel for schedule (guided)
    #endif*/
    for(unsigned i=0;i<partParticles->size();i++){
    unsigned p1 =(*partParticles)[i];//p1 is current index for pos (not idp)
    float visc=0,arp1=0,deltap1=0;
    tfloat3 acep1=TFloat3(0);
    tsymatrix3f gradvelp1={0,0,0,0,0,0};

    //-Variables for Shifting.
    tfloat4 shiftposfsp1;
    if(shift)shiftposfsp1=shiftposfs[p1];

    //-Obtain data of particle p1 in case of floating objects. | Obtiene datos de particula p1 en caso de existir floatings.
    bool ftp1=false;     //-Indicate if it is floating. | Indica si es floating.
    if(USE_FLOATING){
      ftp1=CODE_IsFloating(code[p1]);
      if(ftp1 && tdensity!=DDT_None)deltap1=FLT_MAX; //-DDT is not applied to floating particles.
      if(ftp1 && shift)shiftposfsp1.x=FLT_MAX;  //-For floating objects do not calculate shifting. | Para floatings no se calcula shifting.
    }

    //-Obtain data of particle p1.
    const tdouble3 posp1=pos[p1];
    const tfloat3 velp1=TFloat3(velrhop[p1].x,velrhop[p1].y,velrhop[p1].z);
    const float rhopp1=velrhop[p1].w;
    const float pressp1=press[p1];
    const tsymatrix3f taup1=(lamsps? tau[p1]: gradvelp1);
    const bool rsymp1=(Symmetry && posp1.y<=Dosh); //<vs_syymmetry>


    //-Obtain interaction limits.
    int cxini,cxfin,yini,yfin,zini,zfin;
    GetInteractionCells(dcell[p1],hdiv,nc,cellzero,cxini,cxfin,yini,yfin,zini,zfin);

    //-Search for neighbours in adjacent cells.
    for(int z=zini;z<zfin;z++){
      const int zmod=(nc.w)*z+cellinitial; //-Sum from start of fluid or boundary cells. | Le suma donde empiezan las celdas de fluido o bound.
      for(int y=yini;y<yfin;y++){
        int ymod=zmod+nc.x*y;
        const unsigned pini=beginendcell[cxini+ymod];
        const unsigned pfin=beginendcell[cxfin+ymod];

        //-Interaction of Fluid with type Fluid or Bound. | Interaccion de Fluid con varias Fluid o Bound.
        //------------------------------------------------------------------------------------------------
        bool rsym=false; //<vs_syymmetry>
//	if(cellinitial!=0){printf("this is fluid-fluid interaction----->pin=%d----pfin=%d\n",pini,pfin);}
        for(unsigned p2=pini;p2<pfin;p2++){
//        for(unsigned p2=int(pinit)+1;p2<pfin;p2++){
          const float drx=float(posp1.x-pos[p2].x);
                float dry=float(posp1.y-pos[p2].y);
          if(rsym)    dry=float(posp1.y+pos[p2].y); //<vs_syymmetry>
          const float drz=float(posp1.z-pos[p2].z);
          const float rr2=drx*drx+dry*dry+drz*drz;
//printf("Fourh2=%lf,H=%lf,H*H*4=%lf\n",Fourh2,H,H*H*4);
          if(rr2<=Fourh2 && rr2>=ALMOSTZERO){
            //-Cubic Spline, Wendland or Gaussian kernel.
            float frx,fry,frz;
            if(tker==KERNEL_Wendland)GetKernelWendland(rr2,drx,dry,drz,frx,fry,frz);
            else if(tker==KERNEL_Gaussian)GetKernelGaussian(rr2,drx,dry,drz,frx,fry,frz);
            else if(tker==KERNEL_Cubic)GetKernelCubic(rr2,drx,dry,drz,frx,fry,frz);

            //===== Get mass of particle p2 ===== 
            float massp2=(boundp2? MassBound: MassFluid); //-Contiene masa de particula segun sea bound o fluid.
            bool ftp2=false;    //-Indicate if it is floating | Indica si es floating.
            bool compute=true;  //-Deactivate when using DEM and if it is of type float-float or float-bound | Se desactiva cuando se usa DEM y es float-float o float-bound.
            if(USE_FLOATING){
              ftp2=CODE_IsFloating(code[p2]);///******code2 need
              if(ftp2)massp2=FtObjs[CODE_GetTypeValue(code[p2])].massp;
              #ifdef DELTA_HEAVYFLOATING
                if(ftp2 && tdensity==DDT_DDT && massp2<=(MassFluid*1.2f))deltap1=FLT_MAX;
              #else
                if(ftp2 && tdensity==DDT_DDT)deltap1=FLT_MAX;
              #endif
              if(ftp2 && shift && shiftmode==SHIFT_NoBound)shiftposfsp1.x=FLT_MAX; //-With floating objects do not use shifting. | Con floatings anula shifting.
              compute=!(USE_FTEXTERNAL && ftp1 && (boundp2 || ftp2)); //-Deactivate when using DEM and if it is of type float-float or float-bound. | Se desactiva cuando se usa DEM y es float-float o float-bound.
            }

            tfloat4 velrhop2=velrhop[p2];//******velrhop2 need
            if(rsym)velrhop2.y=-velrhop2.y; //<vs_syymmetry>
            //===== Acceleration ===== 
            if(compute){//************press2
              const float prs=(pressp1+press[p2])/(rhopp1*velrhop2.w) + (tker==KERNEL_Cubic? GetKernelCubicTensil(rr2,rhopp1,pressp1,velrhop2.w,press[p2]): 0);
              const float p_vpm=-prs*massp2;
              acep1.x+=p_vpm*frx; acep1.y+=p_vpm*fry; acep1.z+=p_vpm*frz;
            }

            //-Density derivative.
            const float dvx=velp1.x-velrhop2.x, dvy=velp1.y-velrhop2.y, dvz=velp1.z-velrhop2.z;
            if(compute)arp1+=massp2*(dvx*frx+dvy*fry+dvz*frz);

            const float cbar=(float)Cs0;
            //-Density Diffusion Term (Molteni and Colagrossi 2009).
            if(tdensity==DDT_DDT && deltap1!=FLT_MAX){
              const float rhop1over2=rhopp1/velrhop2.w;
              const float visc_densi=DDT2h*cbar*(rhop1over2-1.f)/(rr2+Eta2);
              const float dot3=(drx*frx+dry*fry+drz*frz);
              const float delta=visc_densi*dot3*massp2;
              //deltap1=(boundp2? FLT_MAX: deltap1+delta);
              deltap1=(boundp2 && TBoundary==BC_DBC? FLT_MAX: deltap1+delta);
            }

            //-Shifting correction.
            if(shift && shiftposfsp1.x!=FLT_MAX){
              const float massrhop=massp2/velrhop2.w;
              const bool noshift=(boundp2 && (shiftmode==SHIFT_NoBound || (shiftmode==SHIFT_NoFixed && CODE_IsFixed(code[p2]))));
              shiftposfsp1.x=(noshift? FLT_MAX: shiftposfsp1.x+massrhop*frx); //-For boundary do not use shifting. | Con boundary anula shifting.
              shiftposfsp1.y+=massrhop*fry;
              shiftposfsp1.z+=massrhop*frz;
              shiftposfsp1.w-=massrhop*(drx*frx+dry*fry+drz*frz);
            }

            //===== Viscosity ===== 
            if(compute){
              const float dot=drx*dvx + dry*dvy + drz*dvz;
              const float dot_rr2=dot/(rr2+Eta2);
              visc=max(dot_rr2,visc);
              if(!lamsps){//-Artificial viscosity.
                if(dot<0){
                  const float amubar=H*dot_rr2;  //amubar=CTE.h*dot/(rr2+CTE.eta2);
                  const float robar=(rhopp1+velrhop2.w)*0.5f;
                  const float pi_visc=(-visco*cbar*amubar/robar)*massp2;
                  acep1.x-=pi_visc*frx; acep1.y-=pi_visc*fry; acep1.z-=pi_visc*frz;
                }
              }
              else{//-Laminar+SPS viscosity. 
                {//-Laminar contribution.
                  const float robar2=(rhopp1+velrhop2.w);
                  const float temp=4.f*visco/((rr2+Eta2)*robar2);  //-Simplification of: temp=2.0f*visco/((rr2+CTE.eta2)*robar); robar=(rhopp1+velrhop2.w)*0.5f;
                  const float vtemp=massp2*temp*(drx*frx+dry*fry+drz*frz);  
                  acep1.x+=vtemp*dvx; acep1.y+=vtemp*dvy; acep1.z+=vtemp*dvz;
                }
                //-SPS turbulence model.
                float tau_xx=taup1.xx,tau_xy=taup1.xy,tau_xz=taup1.xz; //-taup1 is always zero when p1 is not a fluid particle. | taup1 siempre es cero cuando p1 no es fluid.
                float tau_yy=taup1.yy,tau_yz=taup1.yz,tau_zz=taup1.zz;
                if(!boundp2 && !ftp2){//-When p2 is a fluid particle. 
                  tau_xx+=tau[p2].xx; tau_xy+=tau[p2].xy; tau_xz+=tau[p2].xz;
                  tau_yy+=tau[p2].yy; tau_yz+=tau[p2].yz; tau_zz+=tau[p2].zz;
                }
                acep1.x+=massp2*(tau_xx*frx + tau_xy*fry + tau_xz*frz);
                acep1.y+=massp2*(tau_xy*frx + tau_yy*fry + tau_yz*frz);
                acep1.z+=massp2*(tau_xz*frx + tau_yz*fry + tau_zz*frz);
                //-Velocity gradients.
                if(!ftp1){//-When p1 is a fluid particle. 
                  const float volp2=-massp2/velrhop2.w;
                  float dv=dvx*volp2; gradvelp1.xx+=dv*frx; gradvelp1.xy+=dv*fry; gradvelp1.xz+=dv*frz;
                        dv=dvy*volp2; gradvelp1.xy+=dv*frx; gradvelp1.yy+=dv*fry; gradvelp1.yz+=dv*frz;
                        dv=dvz*volp2; gradvelp1.xz+=dv*frx; gradvelp1.yz+=dv*fry; gradvelp1.zz+=dv*frz;
                  //-To compute tau terms we assume that gradvel.xy=gradvel.dudy+gradvel.dvdx, gradvel.xz=gradvel.dudz+gradvel.dwdx, gradvel.yz=gradvel.dvdz+gradvel.dwdy
                  //-so only 6 elements are needed instead of 3x3.
                }
              }
            }
            rsym=(rsymp1 && !rsym && float(posp1.y-dry)<=Dosh); //<vs_syymmetry>
            if(rsym)p2--;                                       //<vs_syymmetry>
          }
          else rsym=false;                                      //<vs_syymmetry>
        }//end of p4
      }//end of p3 for get interaction cell y
    }//end of p2 for get interactoin cell z 
    //-Sum results together. | Almacena resultados.
    if(shift||arp1||acep1.x||acep1.y||acep1.z||visc){
      if(tdensity!=DDT_None){
        if(delta)delta[p1]=(delta[p1]==FLT_MAX || deltap1==FLT_MAX? FLT_MAX: delta[p1]+deltap1);
        else if(deltap1!=FLT_MAX)arp1+=deltap1;
      }
      ar[p1]+=arp1;//density
      ace[p1]=ace[p1]+acep1;//overloaded scalar computation
      const int th=omp_get_thread_num();
      if(visc>viscth[th*OMP_STRIDE])viscth[th*OMP_STRIDE]=visc;
      if(lamsps){
        gradvel[p1].xx+=gradvelp1.xx;
        gradvel[p1].xy+=gradvelp1.xy;
        gradvel[p1].xz+=gradvelp1.xz;
        gradvel[p1].yy+=gradvelp1.yy;
        gradvel[p1].yz+=gradvelp1.yz;
        gradvel[p1].zz+=gradvelp1.zz;
      }
      if(shift)shiftposfs[p1]=shiftposfsp1;
    }
  }//end of p1
  //-Keep max value in viscdt. | Guarda en viscdt el valor maximo.
  for(int th=0;th<OmpThreads;th++)if(viscdt<viscth[th*OMP_STRIDE])viscdt=viscth[th*OMP_STRIDE];
}


// fluid-fluid only my function
//==============================================================================
/// Perform interaction between particles: Fluid/Float-Fluid/Float or Fluid/Float-Bound
/// Realiza interaccion entre particulas: Fluid/Float-Fluid/Float or Fluid/Float-Bound
//==============================================================================
template<TpKernel tker,TpFtMode ftmode,bool lamsps,TpDensity tdensity,bool shift> 
  void JSphCpu::InteractionForcesFluidFluidOnly
  (unsigned n,unsigned pinit,tint4 nc,int hdiv,unsigned cellinitial,float visco
  ,const unsigned *beginendcell,tint3 cellzero,const unsigned *dcell
  ,const tsymatrix3f* tau,tsymatrix3f* gradvel
  ,const tdouble3 *pos,const tfloat4 *velrhop,const typecode *code,const unsigned *idp
  ,const float *press 
  ,float &viscdt,float *ar,tfloat3 *ace,float *delta
  ,TpShifting shiftmode,tfloat4 *shiftposfs,double procMinlimit,double procMaxlimit,const std::vector<unsigned>* partParticles)const
{//partparticles include ghost particles(left/right) and not ghost particles
//n  is number of fuild particles idp is particles for fuild
  const bool boundp2=(!cellinitial); //-Interaction with type boundary (Bound). | Interaccion con Bound.
  //-Initialize viscth to calculate viscdt maximo con OpenMP. | Inicializa viscth para calcular visdt maximo con OpenMP.
  float viscth[OMP_MAXTHREADS*OMP_STRIDE];
  for(int th=0;th<OmpThreads;th++)viscth[th*OMP_STRIDE]=0;
  //-Initialise execution with OpenMP. | Inicia ejecucion con OpenMP.
  const int pfin=int(pinit+n);
////////////////////
    int rank_id=mpi_rank_id;
    int proc_size=mpi_rank_size;
//  MPI_Comm_rank(MPI_COMM_WORLD,&rank_id);
//  MPI_Comm_size(MPI_COMM_WORLD,&proc_size);
  printf("------------------rank_id=%d----(inner)interaction fluid-fluid only p1-->pfini=(%d---%d),,,,Np_max=%d\n",rank_id,pinit,pfin-1,Np_max);
  if(rank_id==0)printf("-------rank_id=0----(inner) Np=%d\n",Np);
/*
  //test for extra space for Posxyz
  for(unsigned i=Np;i<Np+5;i++){
       printf("~~~~~++++++++++++rank_id=%d Posc ------ghost=(%lf,%lf,%lf)\n",rank_id,Posc[i].x,Posc[i].y,Posc[i].z);
  }
*/  
              
///////////////////////////////////////////for my get function
/*
  //get ghost particles
  int rank_id,proc_size;
  MPI_Comm_rank(MPI_COMM_WORLD,&rank_id);  
  MPI_Comm_size(MPI_COMM_WORLD,&proc_size);

  printf("-------------------------------rank_id=%d\n",rank_id);
  printf("proceMinlimit=%lf-----to-----proMaxlimit=%lf\n",procMinlimit,procMaxlimit);
  printf("------------------------------------\n");
  MPI_Barrier(MPI_COMM_WORLD);
 
  vector<unsigned> leftGhost,rightGhost,notGhost;
  double leftBoundary,rightBoundary;
  leftBoundary =procMinlimit+2*H;
  rightBoundary=procMaxlimit-2*H;

  for(unsigned g=pinit;g<pfin;g++){
	if(rank_id==0){//for first processor
		//only set rightboundary
		if(pos[g].y>=rightBoundary){
			rightGhost.push_back(g);
		}else{
			notGhost.push_back(g);
		}
	}else if(rank_id==proc_size-1){//for last processor
		if(pos[g].y<=leftBoundary){
			leftGhost.push_back(g);
		}else{
			notGhost.push_back(g);
		}
	}else{//for middle processor
		if(pos[g].y<=leftBoundary){
			leftGhost.push_back(g);
		}else if(pos[g].y>leftBoundary && pos[g].y<rightBoundary){
			notGhost.push_back(g);
		}else{
			rightGhost.push_back(g);
		}
	}
  }    
  printf("***********verification: ghost+not ghost=%d and all fluid particles =%d\n",rightGhost.size()+leftGhost.size()+notGhost.size(),n); 
  printf("===========rank id %d number of leftghost=%d, rightghost=%d\n",rank_id,leftGhost.size(),rightGhost.size()); 
//get neighbor
  tdouble3 posMinlimit;
  tdouble3 posMaxlimit;
  getPosMinMax(pinit,pfin,pos,posMinlimit,posMaxlimit);
  printf("Fourh2=%lf,H=%lf,H*H*4=%lf\n",Fourh2,H,H*H*4);
  printf("==========xmin-xmax(%lf,%lf),ymin-ymax(%lf,%lf),zmin-zmax(%lf,%lf)\n",posMinlimit.x,posMaxlimit.x,posMinlimit.y,posMaxlimit.y,posMinlimit.z,posMaxlimit.z);

  //get the number of cell for x/y/z diretion
  unsigned ncx,ncy,ncz;
  double edge_cell=2*H;
  ncx =(posMaxlimit.x-posMinlimit.x)/edge_cell+1;//need add one,it's hard to divide completely
  ncy =(posMaxlimit.y-posMinlimit.y)/edge_cell+1;//need add one,it's hard to divide completely
  ncz =(posMaxlimit.z-posMinlimit.z)/edge_cell+1;//need add one,it's hard to divide completely

  printf("******grid count is ncx*ncy*cnz=%d\n",ncx*ncy*ncz);
  printf("******ncellx=%d, cell boundary max=%lf, real bounday(particle max for x-dir is %lf\n)",ncx,ncx*edge_cell+posMinlimit.x,posMaxlimit.x);
  printf("******ncelly=%d, cell boundary may=%lf, real bounday(particle max for y-dir is %lf\n)",ncy,ncy*edge_cell+posMinlimit.y,posMaxlimit.y);
  printf("******ncellz=%d, cell boundary maz=%lf, real bounday(particle max for z-dir is %lf\n)",ncz,ncz*edge_cell+posMinlimit.z,posMaxlimit.z);
*/  
 //set grid
//  setGridDivideStore(pos,);  
/////////////////////////////////////////////
/*  
  #ifdef OMP_USE
    #pragma omp parallel for schedule (guided)
  #endif
*/

/*
  unsigned i1=0;
  while(NULL!=idp[i1]){
	i1++;
  }
  printf("-----interaction fluid-fuild n=%d, idp_min[0]=%d, idp_max[%d]=%d\n ",n,idp[0],i1,idp[i1]);
  printf("-----interaction fluid-fuid p1-->pfini=(%d---%d)----and idp[0]=%d, idp[%d]=%d\n",pinit,pfin-1,idp[0],n-1,idp[n-1]);*/
  //get  info for particles need to be calculate
/*
  for(unsigned i=0;i<partParticles->size();i++){
	printf("i%d=%d, ",i,(*partParticles)[i]);	
//	printf("particles need to be calculate\n");
  }*/
//  for(int p1=int(pinit);p1<pfin;p1++){
int numProcs = omp_get_num_procs();
printf("xxx---------central part----------interaction omp threads:%d\n", numProcs);

    #ifdef OMP_USE
      #pragma omp parallel for schedule (guided)
    #endif
    for(unsigned i=0;i<partParticles->size();i++){
    unsigned p1 =(*partParticles)[i];//p1 is current index for pos (not idp)
    float visc=0,arp1=0,deltap1=0;
    tfloat3 acep1=TFloat3(0);
    tsymatrix3f gradvelp1={0,0,0,0,0,0};

    //-Variables for Shifting.
    tfloat4 shiftposfsp1;
    if(shift)shiftposfsp1=shiftposfs[p1];

    //-Obtain data of particle p1 in case of floating objects. | Obtiene datos de particula p1 en caso de existir floatings.
    bool ftp1=false;     //-Indicate if it is floating. | Indica si es floating.
    if(USE_FLOATING){
      ftp1=CODE_IsFloating(code[p1]);
      if(ftp1 && tdensity!=DDT_None)deltap1=FLT_MAX; //-DDT is not applied to floating particles.
      if(ftp1 && shift)shiftposfsp1.x=FLT_MAX;  //-For floating objects do not calculate shifting. | Para floatings no se calcula shifting.
    }

    //-Obtain data of particle p1.
    const tdouble3 posp1=pos[p1];
    const tfloat3 velp1=TFloat3(velrhop[p1].x,velrhop[p1].y,velrhop[p1].z);
    const float rhopp1=velrhop[p1].w;
    const float pressp1=press[p1];
    const tsymatrix3f taup1=(lamsps? tau[p1]: gradvelp1);
    const bool rsymp1=(Symmetry && posp1.y<=Dosh); //<vs_syymmetry>


    //-Obtain interaction limits.
    int cxini,cxfin,yini,yfin,zini,zfin;
    GetInteractionCells(dcell[p1],hdiv,nc,cellzero,cxini,cxfin,yini,yfin,zini,zfin);

    //-Search for neighbours in adjacent cells.
    for(int z=zini;z<zfin;z++){
      const int zmod=(nc.w)*z+cellinitial; //-Sum from start of fluid or boundary cells. | Le suma donde empiezan las celdas de fluido o bound.
      for(int y=yini;y<yfin;y++){
        int ymod=zmod+nc.x*y;
        const unsigned pini=beginendcell[cxini+ymod];
        const unsigned pfin=beginendcell[cxfin+ymod];

        //-Interaction of Fluid with type Fluid or Bound. | Interaccion de Fluid con varias Fluid o Bound.
        //------------------------------------------------------------------------------------------------
        bool rsym=false; //<vs_syymmetry>
//	if(cellinitial!=0){printf("this is fluid-fluid interaction----->pin=%d----pfin=%d\n",pini,pfin);}
        for(unsigned p2=pini;p2<pfin;p2++){
//        for(unsigned p2=pinit;p2<pfin;p2++){
          const float drx=float(posp1.x-pos[p2].x);
                float dry=float(posp1.y-pos[p2].y);
          if(rsym)    dry=float(posp1.y+pos[p2].y); //<vs_syymmetry>
          const float drz=float(posp1.z-pos[p2].z);
          const float rr2=drx*drx+dry*dry+drz*drz;
//printf("Fourh2=%lf,H=%lf,H*H*4=%lf\n",Fourh2,H,H*H*4);
          if(rr2<=Fourh2 && rr2>=ALMOSTZERO){
            //-Cubic Spline, Wendland or Gaussian kernel.
            float frx,fry,frz;
            if(tker==KERNEL_Wendland)GetKernelWendland(rr2,drx,dry,drz,frx,fry,frz);
            else if(tker==KERNEL_Gaussian)GetKernelGaussian(rr2,drx,dry,drz,frx,fry,frz);
            else if(tker==KERNEL_Cubic)GetKernelCubic(rr2,drx,dry,drz,frx,fry,frz);

            //===== Get mass of particle p2 ===== 
            float massp2=(boundp2? MassBound: MassFluid); //-Contiene masa de particula segun sea bound o fluid.
            bool ftp2=false;    //-Indicate if it is floating | Indica si es floating.
            bool compute=true;  //-Deactivate when using DEM and if it is of type float-float or float-bound | Se desactiva cuando se usa DEM y es float-float o float-bound.
            if(USE_FLOATING){
              ftp2=CODE_IsFloating(code[p2]);///******code2 need
              if(ftp2)massp2=FtObjs[CODE_GetTypeValue(code[p2])].massp;
              #ifdef DELTA_HEAVYFLOATING
                if(ftp2 && tdensity==DDT_DDT && massp2<=(MassFluid*1.2f))deltap1=FLT_MAX;
              #else
                if(ftp2 && tdensity==DDT_DDT)deltap1=FLT_MAX;
              #endif
              if(ftp2 && shift && shiftmode==SHIFT_NoBound)shiftposfsp1.x=FLT_MAX; //-With floating objects do not use shifting. | Con floatings anula shifting.
              compute=!(USE_FTEXTERNAL && ftp1 && (boundp2 || ftp2)); //-Deactivate when using DEM and if it is of type float-float or float-bound.
            }

            tfloat4 velrhop2=velrhop[p2];//******velrhop2 need
            if(rsym)velrhop2.y=-velrhop2.y; //<vs_syymmetry>
            //===== Acceleration ===== 
            if(compute){//************press2
              const float prs=(pressp1+press[p2])/(rhopp1*velrhop2.w) + (tker==KERNEL_Cubic? GetKernelCubicTensil(rr2,rhopp1,pressp1,velrhop2.w,press[p2]): 0);
              const float p_vpm=-prs*massp2;
              acep1.x+=p_vpm*frx; acep1.y+=p_vpm*fry; acep1.z+=p_vpm*frz;
            }

            //-Density derivative.
            const float dvx=velp1.x-velrhop2.x, dvy=velp1.y-velrhop2.y, dvz=velp1.z-velrhop2.z;
            if(compute)arp1+=massp2*(dvx*frx+dvy*fry+dvz*frz);

            const float cbar=(float)Cs0;
            //-Density Diffusion Term (Molteni and Colagrossi 2009).
            if(tdensity==DDT_DDT && deltap1!=FLT_MAX){
              const float rhop1over2=rhopp1/velrhop2.w;
              const float visc_densi=DDT2h*cbar*(rhop1over2-1.f)/(rr2+Eta2);
              const float dot3=(drx*frx+dry*fry+drz*frz);
              const float delta=visc_densi*dot3*massp2;
              //deltap1=(boundp2? FLT_MAX: deltap1+delta);
              deltap1=(boundp2 && TBoundary==BC_DBC? FLT_MAX: deltap1+delta);
            }

            //-Shifting correction.
            if(shift && shiftposfsp1.x!=FLT_MAX){
              const float massrhop=massp2/velrhop2.w;
              const bool noshift=(boundp2 && (shiftmode==SHIFT_NoBound || (shiftmode==SHIFT_NoFixed && CODE_IsFixed(code[p2]))));
              shiftposfsp1.x=(noshift? FLT_MAX: shiftposfsp1.x+massrhop*frx); //-For boundary do not use shifting. | Con boundary anula shifting.
              shiftposfsp1.y+=massrhop*fry;
              shiftposfsp1.z+=massrhop*frz;
              shiftposfsp1.w-=massrhop*(drx*frx+dry*fry+drz*frz);
            }

            //===== Viscosity ===== 
            if(compute){
              const float dot=drx*dvx + dry*dvy + drz*dvz;
              const float dot_rr2=dot/(rr2+Eta2);
              visc=max(dot_rr2,visc);
              if(!lamsps){//-Artificial viscosity.
                if(dot<0){
                  const float amubar=H*dot_rr2;  //amubar=CTE.h*dot/(rr2+CTE.eta2);
                  const float robar=(rhopp1+velrhop2.w)*0.5f;
                  const float pi_visc=(-visco*cbar*amubar/robar)*massp2;
                  acep1.x-=pi_visc*frx; acep1.y-=pi_visc*fry; acep1.z-=pi_visc*frz;
                }
              }
              else{//-Laminar+SPS viscosity. 
                {//-Laminar contribution.
                  const float robar2=(rhopp1+velrhop2.w);
                  const float temp=4.f*visco/((rr2+Eta2)*robar2);  //-Simplification of: temp=2.0f*visco/((rr2+CTE.eta2)*robar); robar=(rhopp1+velrhop2.w)*0.5f;
                  const float vtemp=massp2*temp*(drx*frx+dry*fry+drz*frz);  
                  acep1.x+=vtemp*dvx; acep1.y+=vtemp*dvy; acep1.z+=vtemp*dvz;
                }
                //-SPS turbulence model.
                float tau_xx=taup1.xx,tau_xy=taup1.xy,tau_xz=taup1.xz; //-taup1 is always zero when p1 is not a fluid particle. | taup1 siempre es cero cuando p1 no es fluid.
                float tau_yy=taup1.yy,tau_yz=taup1.yz,tau_zz=taup1.zz;
                if(!boundp2 && !ftp2){//-When p2 is a fluid particle. 
                  tau_xx+=tau[p2].xx; tau_xy+=tau[p2].xy; tau_xz+=tau[p2].xz;
                  tau_yy+=tau[p2].yy; tau_yz+=tau[p2].yz; tau_zz+=tau[p2].zz;
                }
                acep1.x+=massp2*(tau_xx*frx + tau_xy*fry + tau_xz*frz);
                acep1.y+=massp2*(tau_xy*frx + tau_yy*fry + tau_yz*frz);
                acep1.z+=massp2*(tau_xz*frx + tau_yz*fry + tau_zz*frz);
                //-Velocity gradients.
                if(!ftp1){//-When p1 is a fluid particle. 
                  const float volp2=-massp2/velrhop2.w;
                  float dv=dvx*volp2; gradvelp1.xx+=dv*frx; gradvelp1.xy+=dv*fry; gradvelp1.xz+=dv*frz;
                        dv=dvy*volp2; gradvelp1.xy+=dv*frx; gradvelp1.yy+=dv*fry; gradvelp1.yz+=dv*frz;
                        dv=dvz*volp2; gradvelp1.xz+=dv*frx; gradvelp1.yz+=dv*fry; gradvelp1.zz+=dv*frz;
                  //-To compute tau terms we assume that gradvel.xy=gradvel.dudy+gradvel.dvdx, gradvel.xz=gradvel.dudz+gradvel.dwdx, gradvel.yz=gradvel.dvdz+gradvel.dwdy
                  //-so only 6 elements are needed instead of 3x3.
                }
              }
            }
            rsym=(rsymp1 && !rsym && float(posp1.y-dry)<=Dosh); //<vs_syymmetry>
            if(rsym)p2--;                                       //<vs_syymmetry>
          }
          else rsym=false;                                      //<vs_syymmetry>
        }//end of p4
      }//end of p3 for get interaction cell y
    }//end of p2 for get interactoin cell z 
    //-Sum results together. | Almacena resultados.
    if(shift||arp1||acep1.x||acep1.y||acep1.z||visc){
      if(tdensity!=DDT_None){
        if(delta)delta[p1]=(delta[p1]==FLT_MAX || deltap1==FLT_MAX? FLT_MAX: delta[p1]+deltap1);
        else if(deltap1!=FLT_MAX)arp1+=deltap1;
      }
      ar[p1]+=arp1;//density
      ace[p1]=ace[p1]+acep1;//overloaded scalar computation
      const int th=omp_get_thread_num();
      if(visc>viscth[th*OMP_STRIDE])viscth[th*OMP_STRIDE]=visc;
      if(lamsps){
        gradvel[p1].xx+=gradvelp1.xx;
        gradvel[p1].xy+=gradvelp1.xy;
        gradvel[p1].xz+=gradvelp1.xz;
        gradvel[p1].yy+=gradvelp1.yy;
        gradvel[p1].yz+=gradvelp1.yz;
        gradvel[p1].zz+=gradvelp1.zz;
      }
      if(shift)shiftposfs[p1]=shiftposfsp1;
    }
  }//end of p1
  //-Keep max value in viscdt. | Guarda en viscdt el valor maximo.
  for(int th=0;th<OmpThreads;th++)if(viscdt<viscth[th*OMP_STRIDE])viscdt=viscth[th*OMP_STRIDE];
}


//my function fluid-bound only
//==============================================================================
/// Perform interaction between particles: Fluid/Float-Bound
/// Realiza interaccion entre particulas: Fluid/Float-Fluid/Float or Fluid/Float-Bound
//==============================================================================
template<TpKernel tker,TpFtMode ftmode,bool lamsps,TpDensity tdensity,bool shift> 
  void JSphCpu::InteractionForcesFluidBoundOnly
  (unsigned n,unsigned pinit,tint4 nc,int hdiv,unsigned cellinitial,float visco
  ,const unsigned *beginendcell,tint3 cellzero,const unsigned *dcell
  ,const tsymatrix3f* tau,tsymatrix3f* gradvel
  ,const tdouble3 *pos,const tfloat4 *velrhop,const typecode *code,const unsigned *idp
  ,const float *press 
  ,float &viscdt,float *ar,tfloat3 *ace,float *delta
  ,TpShifting shiftmode,tfloat4 *shiftposfs)const
{
  const bool boundp2=(!cellinitial); //-Interaction with type boundary (Bound). | Interaccion con Bound.
  //-Initialize viscth to calculate viscdt maximo con OpenMP. | Inicializa viscth para calcular visdt maximo con OpenMP.
  float viscth[OMP_MAXTHREADS*OMP_STRIDE];
  for(int th=0;th<OmpThreads;th++)viscth[th*OMP_STRIDE]=0;
  //-Initialise execution with OpenMP. | Inicia ejecucion con OpenMP.
  const int pfin=int(pinit+n);
/*  
  #ifdef OMP_USE
    #pragma omp parallel for schedule (guided)
  #endif
*/
  
  printf("-*************XXXXXXXXXXXXXXXXXXXXXXXXXXXmpi_rank_id=%dXXXXXXXXXXXXXXXXX---nc=%d----interaction fluid-bound only p1-->pfini=(%d---%d)---np_max=%d\n",mpi_rank_id,n,pinit,pfin-1,Np_max);
//  if(mpi_rank_id==0)printf("-**********xxxxxrank_id=0xxxxxxxxxxxxxxxNp=%d\n",Np);


  #ifdef OMP_USE
    #pragma omp parallel for schedule (guided)
  #endif
  for(int p1=int(pinit);p1<pfin;p1++){
    float visc=0,arp1=0,deltap1=0;
    tfloat3 acep1=TFloat3(0);
    tsymatrix3f gradvelp1={0,0,0,0,0,0};

    //-Variables for Shifting.
    tfloat4 shiftposfsp1;
    if(shift)shiftposfsp1=shiftposfs[p1];

    //-Obtain data of particle p1 in case of floating objects. | Obtiene datos de particula p1 en caso de existir floatings.
    bool ftp1=false;     //-Indicate if it is floating. | Indica si es floating.
    if(USE_FLOATING){
      ftp1=CODE_IsFloating(code[p1]);
      if(ftp1 && tdensity!=DDT_None)deltap1=FLT_MAX; //-DDT is not applied to floating particles.
      if(ftp1 && shift)shiftposfsp1.x=FLT_MAX;  //-For floating objects do not calculate shifting. | Para floatings no se calcula shifting.
    }

    //-Obtain data of particle p1.
    const tdouble3 posp1=pos[p1];
    const tfloat3 velp1=TFloat3(velrhop[p1].x,velrhop[p1].y,velrhop[p1].z);
    const float rhopp1=velrhop[p1].w;
    const float pressp1=press[p1];
    const tsymatrix3f taup1=(lamsps? tau[p1]: gradvelp1);
    const bool rsymp1=(Symmetry && posp1.y<=Dosh); //<vs_syymmetry>


    //-Obtain interaction limits.
    int cxini,cxfin,yini,yfin,zini,zfin;
    GetInteractionCells(dcell[p1],hdiv,nc,cellzero,cxini,cxfin,yini,yfin,zini,zfin);

    //-Search for neighbours in adjacent cells.
    for(int z=zini;z<zfin;z++){
      const int zmod=(nc.w)*z+cellinitial; //-Sum from start of fluid or boundary cells. | Le suma donde empiezan las celdas de fluido o bound.
      for(int y=yini;y<yfin;y++){
        int ymod=zmod+nc.x*y;
        const unsigned pini=beginendcell[cxini+ymod];
        const unsigned pfin=beginendcell[cxfin+ymod];

        //-Interaction of Fluid with type Fluid or Bound. | Interaccion de Fluid con varias Fluid o Bound.
        //------------------------------------------------------------------------------------------------
        bool rsym=false; //<vs_syymmetry>
//	if(cellinitial==0){printf("this is fluid-bound only interaction----->pin=%d----pfin=%d\n",pini,pfin);}
        for(unsigned p2=pini;p2<pfin;p2++){
//	bool rsym =false;//vs_syymmetry
//	for(unsigned p2=0;p2<pinit;p2++){
          const float drx=float(posp1.x-pos[p2].x);
                float dry=float(posp1.y-pos[p2].y);
          if(rsym)    dry=float(posp1.y+pos[p2].y); //<vs_syymmetry>
          const float drz=float(posp1.z-pos[p2].z);
          const float rr2=drx*drx+dry*dry+drz*drz;
          if(rr2<=Fourh2 && rr2>=ALMOSTZERO){
            //-Cubic Spline, Wendland or Gaussian kernel.
            float frx,fry,frz;
            if(tker==KERNEL_Wendland)GetKernelWendland(rr2,drx,dry,drz,frx,fry,frz);
            else if(tker==KERNEL_Gaussian)GetKernelGaussian(rr2,drx,dry,drz,frx,fry,frz);
            else if(tker==KERNEL_Cubic)GetKernelCubic(rr2,drx,dry,drz,frx,fry,frz);

            //===== Get mass of particle p2 ===== 
            float massp2=(boundp2? MassBound: MassFluid); //-Contiene masa de particula segun sea bound o fluid.
            bool ftp2=false;    //-Indicate if it is floating | Indica si es floating.
            bool compute=true;  //-Deactivate when using DEM and if it is of type float-float or float-bound | Se desactiva cuando se usa DEM y es float-float o float-bound.
            if(USE_FLOATING){
              ftp2=CODE_IsFloating(code[p2]);
              if(ftp2)massp2=FtObjs[CODE_GetTypeValue(code[p2])].massp;
              #ifdef DELTA_HEAVYFLOATING
                if(ftp2 && tdensity==DDT_DDT && massp2<=(MassFluid*1.2f))deltap1=FLT_MAX;
              #else
                if(ftp2 && tdensity==DDT_DDT)deltap1=FLT_MAX;
              #endif
              if(ftp2 && shift && shiftmode==SHIFT_NoBound)shiftposfsp1.x=FLT_MAX; //-With floating objects do not use shifting. | Con floatings anula shifting.
              compute=!(USE_FTEXTERNAL && ftp1 && (boundp2 || ftp2)); //-Deactivate when using DEM and if it is of type float-float or float-bound. | Se desactiva cuando se usa DEM y es float-float o float-bound.
            }

            tfloat4 velrhop2=velrhop[p2];
            if(rsym)velrhop2.y=-velrhop2.y; //<vs_syymmetry>
            //===== Acceleration ===== 
            if(compute){
              const float prs=(pressp1+press[p2])/(rhopp1*velrhop2.w) + (tker==KERNEL_Cubic? GetKernelCubicTensil(rr2,rhopp1,pressp1,velrhop2.w,press[p2]): 0);
              const float p_vpm=-prs*massp2;
              acep1.x+=p_vpm*frx; acep1.y+=p_vpm*fry; acep1.z+=p_vpm*frz;
            }

            //-Density derivative.
            const float dvx=velp1.x-velrhop2.x, dvy=velp1.y-velrhop2.y, dvz=velp1.z-velrhop2.z;
            if(compute)arp1+=massp2*(dvx*frx+dvy*fry+dvz*frz);

            const float cbar=(float)Cs0;
            //-Density Diffusion Term (Molteni and Colagrossi 2009).
            if(tdensity==DDT_DDT && deltap1!=FLT_MAX){
              const float rhop1over2=rhopp1/velrhop2.w;
              const float visc_densi=DDT2h*cbar*(rhop1over2-1.f)/(rr2+Eta2);
              const float dot3=(drx*frx+dry*fry+drz*frz);
              const float delta=visc_densi*dot3*massp2;
              //deltap1=(boundp2? FLT_MAX: deltap1+delta);
              deltap1=(boundp2 && TBoundary==BC_DBC? FLT_MAX: deltap1+delta);
            }

            //-Shifting correction.
            if(shift && shiftposfsp1.x!=FLT_MAX){
              const float massrhop=massp2/velrhop2.w;
              const bool noshift=(boundp2 && (shiftmode==SHIFT_NoBound || (shiftmode==SHIFT_NoFixed && CODE_IsFixed(code[p2]))));
              shiftposfsp1.x=(noshift? FLT_MAX: shiftposfsp1.x+massrhop*frx); //-For boundary do not use shifting. | Con boundary anula shifting.
              shiftposfsp1.y+=massrhop*fry;
              shiftposfsp1.z+=massrhop*frz;
              shiftposfsp1.w-=massrhop*(drx*frx+dry*fry+drz*frz);
            }

            //===== Viscosity ===== 
            if(compute){
              const float dot=drx*dvx + dry*dvy + drz*dvz;
              const float dot_rr2=dot/(rr2+Eta2);
              visc=max(dot_rr2,visc);
              if(!lamsps){//-Artificial viscosity.
                if(dot<0){
                  const float amubar=H*dot_rr2;  //amubar=CTE.h*dot/(rr2+CTE.eta2);
                  const float robar=(rhopp1+velrhop2.w)*0.5f;
                  const float pi_visc=(-visco*cbar*amubar/robar)*massp2;
                  acep1.x-=pi_visc*frx; acep1.y-=pi_visc*fry; acep1.z-=pi_visc*frz;
                }
              }
              else{//-Laminar+SPS viscosity. 
                {//-Laminar contribution.
                  const float robar2=(rhopp1+velrhop2.w);
                  const float temp=4.f*visco/((rr2+Eta2)*robar2);  //-Simplification of: temp=2.0f*visco/((rr2+CTE.eta2)*robar); robar=(rhopp1+velrhop2.w)*0.5f;
                  const float vtemp=massp2*temp*(drx*frx+dry*fry+drz*frz);  
                  acep1.x+=vtemp*dvx; acep1.y+=vtemp*dvy; acep1.z+=vtemp*dvz;
                }
                //-SPS turbulence model.
                float tau_xx=taup1.xx,tau_xy=taup1.xy,tau_xz=taup1.xz; //-taup1 is always zero when p1 is not a fluid particle. | taup1 siempre es cero cuando p1 no es fluid.
                float tau_yy=taup1.yy,tau_yz=taup1.yz,tau_zz=taup1.zz;
                if(!boundp2 && !ftp2){//-When p2 is a fluid particle. 
                  tau_xx+=tau[p2].xx; tau_xy+=tau[p2].xy; tau_xz+=tau[p2].xz;
                  tau_yy+=tau[p2].yy; tau_yz+=tau[p2].yz; tau_zz+=tau[p2].zz;
                }
                acep1.x+=massp2*(tau_xx*frx + tau_xy*fry + tau_xz*frz);
                acep1.y+=massp2*(tau_xy*frx + tau_yy*fry + tau_yz*frz);
                acep1.z+=massp2*(tau_xz*frx + tau_yz*fry + tau_zz*frz);
                //-Velocity gradients.
                if(!ftp1){//-When p1 is a fluid particle. 
                  const float volp2=-massp2/velrhop2.w;
                  float dv=dvx*volp2; gradvelp1.xx+=dv*frx; gradvelp1.xy+=dv*fry; gradvelp1.xz+=dv*frz;
                        dv=dvy*volp2; gradvelp1.xy+=dv*frx; gradvelp1.yy+=dv*fry; gradvelp1.yz+=dv*frz;
                        dv=dvz*volp2; gradvelp1.xz+=dv*frx; gradvelp1.yz+=dv*fry; gradvelp1.zz+=dv*frz;
                  //-To compute tau terms we assume that gradvel.xy=gradvel.dudy+gradvel.dvdx, gradvel.xz=gradvel.dudz+gradvel.dwdx, gradvel.yz=gradvel.dvdz+gradvel.dwdy
                  //-so only 6 elements are needed instead of 3x3.
                }
              }
            }
            rsym=(rsymp1 && !rsym && float(posp1.y-dry)<=Dosh); //<vs_syymmetry>
            if(rsym)p2--;                                       //<vs_syymmetry>
          }
          else rsym=false;                                      //<vs_syymmetry>
        }//end of p4
      }//end of p3
    }//end of p2
    //-Sum results together. | Almacena resultados.
    if(shift||arp1||acep1.x||acep1.y||acep1.z||visc){
      if(tdensity!=DDT_None){
        if(delta)delta[p1]=(delta[p1]==FLT_MAX || deltap1==FLT_MAX? FLT_MAX: delta[p1]+deltap1);
        else if(deltap1!=FLT_MAX)arp1+=deltap1;
      }
      ar[p1]+=arp1;
      ace[p1]=ace[p1]+acep1;
      const int th=omp_get_thread_num();
      if(visc>viscth[th*OMP_STRIDE])viscth[th*OMP_STRIDE]=visc;
      if(lamsps){
        gradvel[p1].xx+=gradvelp1.xx;
        gradvel[p1].xy+=gradvelp1.xy;
        gradvel[p1].xz+=gradvelp1.xz;
        gradvel[p1].yy+=gradvelp1.yy;
        gradvel[p1].yz+=gradvelp1.yz;
        gradvel[p1].zz+=gradvelp1.zz;
      }
      if(shift)shiftposfs[p1]=shiftposfsp1;
    }
  }//end of p1
  //-Keep max value in viscdt. | Guarda en viscdt el valor maximo.
  for(int th=0;th<OmpThreads;th++)if(viscdt<viscth[th*OMP_STRIDE])viscdt=viscth[th*OMP_STRIDE];
}

//==============================================================================
/// Perform DEM interaction between particles Floating-Bound & Floating-Floating //(DEM)
/// Realiza interaccion DEM entre particulas Floating-Bound & Floating-Floating //(DEM)
//==============================================================================
void JSphCpu::InteractionForcesDEM
  (unsigned nfloat,tint4 nc,int hdiv,unsigned cellfluid
  ,const unsigned *beginendcell,tint3 cellzero,const unsigned *dcell
  ,const unsigned *ftridp,const StDemData* demdata
  ,const tdouble3 *pos,const tfloat4 *velrhop
  ,const typecode *code,const unsigned *idp
  ,float &viscdt,tfloat3 *ace)const
{
  //-Initialise demdtth to calculate max demdt with OpenMP. | Inicializa demdtth para calcular demdt maximo con OpenMP.
  float demdtth[OMP_MAXTHREADS*OMP_STRIDE];
  for(int th=0;th<OmpThreads;th++)demdtth[th*OMP_STRIDE]=-FLT_MAX;
  //-Initialise execution with OpenMP. | Inicia ejecucion con OpenMP.
  const int nft=int(nfloat);
  #ifdef OMP_USE
    #pragma omp parallel for schedule (guided)
  #endif
  for(int cf=0;cf<nft;cf++){
    const unsigned p1=ftridp[cf];
    if(p1!=UINT_MAX){
      float demdtp1=0;
      tfloat3 acep1=TFloat3(0);

      //-Get data of particle p1.
      const tdouble3 posp1=pos[p1];
      const typecode tavp1=CODE_GetTypeAndValue(code[p1]);
      const float masstotp1=demdata[tavp1].mass;
      const float taup1=demdata[tavp1].tau;
      const float kfricp1=demdata[tavp1].kfric;
      const float restitup1=demdata[tavp1].restitu;
      const float ftmassp1=demdata[tavp1].massp;

      //-Get interaction limits.
      int cxini,cxfin,yini,yfin,zini,zfin;
      GetInteractionCells(dcell[p1],hdiv,nc,cellzero,cxini,cxfin,yini,yfin,zini,zfin);

      //-Search for neighbours in adjacent cells (first bound and then fluid+floating).
      for(unsigned cellinitial=0;cellinitial<=cellfluid;cellinitial+=cellfluid){
        for(int z=zini;z<zfin;z++){
          const int zmod=(nc.w)*z+cellinitial; //-Sum from start of fluid or boundary cells. | Le suma donde empiezan las celdas de fluido o bound.
          for(int y=yini;y<yfin;y++){
            int ymod=zmod+nc.x*y;
            const unsigned pini=beginendcell[cxini+ymod];
            const unsigned pfin=beginendcell[cxfin+ymod];

            //-Interaction of Floating Object particles with type Fluid or Bound. | Interaccion de Floating con varias Fluid o Bound.
            //-----------------------------------------------------------------------------------------------------------------------
            for(unsigned p2=pini;p2<pfin;p2++)if(CODE_IsNotFluid(code[p2]) && tavp1!=CODE_GetTypeAndValue(code[p2])){
              const float drx=float(posp1.x-pos[p2].x);
              const float dry=float(posp1.y-pos[p2].y);
              const float drz=float(posp1.z-pos[p2].z);
              const float rr2=drx*drx+dry*dry+drz*drz;
              const float rad=sqrt(rr2);

              //-Calculate max value of demdt. | Calcula valor maximo de demdt.
              const typecode tavp2=CODE_GetTypeAndValue(code[p2]);
              const float masstotp2=demdata[tavp2].mass;
              const float taup2=demdata[tavp2].tau;
              const float kfricp2=demdata[tavp2].kfric;
              const float restitup2=demdata[tavp2].restitu;
              //const StDemData *demp2=demobjs+CODE_GetTypeAndValue(code[p2]);

              const float nu_mass=(!cellinitial? masstotp1/2: masstotp1*masstotp2/(masstotp1+masstotp2)); //-Con boundary toma la propia masa del floating 1.
              const float kn=4/(3*(taup1+taup2))*sqrt(float(Dp)/4); //-Generalized rigidity - Lemieux 2008.
              const float dvx=velrhop[p1].x-velrhop[p2].x, dvy=velrhop[p1].y-velrhop[p2].y, dvz=velrhop[p1].z-velrhop[p2].z; //vji
              const float nx=drx/rad, ny=dry/rad, nz=drz/rad; //normal_ji               
              const float vn=dvx*nx+dvy*ny+dvz*nz; //vji.nji
              const float demvisc=0.2f/(3.21f*(pow(nu_mass/kn,0.4f)*pow(fabs(vn),-0.2f))/40.f);
              if(demdtp1<demvisc)demdtp1=demvisc;

              const float over_lap=1.0f*float(Dp)-rad; //-(ri+rj)-|dij|
              if(over_lap>0.0f){ //-Contact.
                //-Normal.
                const float eij=(restitup1+restitup2)/2;
                const float gn=-(2.0f*log(eij)*sqrt(nu_mass*kn))/(sqrt(float(PI)+log(eij)*log(eij))); //-Generalized damping - Cummins 2010.
                //const float gn=0.08f*sqrt(nu_mass*sqrt(float(Dp)/2)/((taup1+taup2)/2)); //-Generalized damping - Lemieux 2008.
                const float rep=kn*pow(over_lap,1.5f);
                const float fn=rep-gn*pow(over_lap,0.25f)*vn;
                float acef=fn/ftmassp1; //-Divides by the mass of particle to obtain the acceleration.
                acep1.x+=(acef*nx); acep1.y+=(acef*ny); acep1.z+=(acef*nz); //-Force is applied in the normal between the particles.
                //-Tangential.
                const float dvxt=dvx-vn*nx, dvyt=dvy-vn*ny, dvzt=dvz-vn*nz; //Vji_t
                const float vt=sqrt(dvxt*dvxt + dvyt*dvyt + dvzt*dvzt);
                float tx=0, ty=0, tz=0; //-Tang vel unit vector.
                if(vt!=0){ tx=dvxt/vt; ty=dvyt/vt; tz=dvzt/vt; }
                const float ft_elast=2*(kn*float(DemDtForce)-gn)*vt/7; //-Elastic frictional string -->  ft_elast=2*(kn*fdispl-gn*vt)/7; fdispl=dtforce*vt;
                const float kfric_ij=(kfricp1+kfricp2)/2;
                float ft=kfric_ij*fn*tanh(8*vt);  //-Coulomb.
                ft=(ft<ft_elast? ft: ft_elast);   //-Not above yield criteria, visco-elastic model.
                acef=ft/ftmassp1; //-Divides by the mass of particle to obtain the acceleration.
                acep1.x+=(acef*tx); acep1.y+=(acef*ty); acep1.z+=(acef*tz);
              } 
            }
          }
        }
      }
      //-Sum results together. | Almacena resultados.
      if(acep1.x||acep1.y||acep1.z){
        ace[p1]=ace[p1]+acep1;
        const int th=omp_get_thread_num();
        if(demdtth[th*OMP_STRIDE]<demdtp1)demdtth[th*OMP_STRIDE]=demdtp1;
      }
    }
  }
  //-Update viscdt with max value of viscdt or demdt* | Actualiza viscdt con el valor maximo de viscdt y demdt*.
  float demdt=demdtth[0];
  for(int th=1;th<OmpThreads;th++)if(demdt<demdtth[th*OMP_STRIDE])demdt=demdtth[th*OMP_STRIDE];
  if(viscdt<demdt)viscdt=demdt;
}


//==============================================================================
/// Computes sub-particle stress tensor (Tau) for SPS turbulence model.   
//==============================================================================
void JSphCpu::ComputeSpsTau(unsigned n,unsigned pini,const tfloat4 *velrhop,const tsymatrix3f *gradvel,tsymatrix3f *tau)const{
  const int pfin=int(pini+n);
  #ifdef OMP_USE
    #pragma omp parallel for schedule (static)
  #endif
  for(int p=int(pini);p<pfin;p++){
    const tsymatrix3f gradvel=SpsGradvelc[p];
    const float pow1=gradvel.xx*gradvel.xx + gradvel.yy*gradvel.yy + gradvel.zz*gradvel.zz;
    const float prr=pow1+pow1 + gradvel.xy*gradvel.xy + gradvel.xz*gradvel.xz + gradvel.yz*gradvel.yz;
    const float visc_sps=SpsSmag*sqrt(prr);
    const float div_u=gradvel.xx+gradvel.yy+gradvel.zz;
    const float sps_k=(2.0f/3.0f)*visc_sps*div_u;
    const float sps_blin=SpsBlin*prr;
    const float sumsps=-(sps_k+sps_blin);
    const float twovisc_sps=(visc_sps+visc_sps);
    const float one_rho2=1.0f/velrhop[p].w;   
    tau[p].xx=one_rho2*(twovisc_sps*gradvel.xx +sumsps);
    tau[p].xy=one_rho2*(visc_sps   *gradvel.xy);
    tau[p].xz=one_rho2*(visc_sps   *gradvel.xz);
    tau[p].yy=one_rho2*(twovisc_sps*gradvel.yy +sumsps);
    tau[p].yz=one_rho2*(visc_sps   *gradvel.yz);
    tau[p].zz=one_rho2*(twovisc_sps*gradvel.zz +sumsps);
  }
}

//=====================================mpi strategy============================
// only for comminication by mpi configure
// ============================================================================
template<TpKernel tker,TpFtMode ftmode,bool lamsps,TpDensity tdensity,bool shift>
  void JSphCpu::MPI_Strategy_InteractionForcesFluidFluidOnly
  (const stinterparmsc &t, float &viscdt,tint4 nc, tint3 cellzero,unsigned cellfluid, int hdiv)const
{
   unsigned n =t.npf;
   unsigned pinit = t.npb;
   const int pfin=int(pinit+n);
   double procMinlimit,procMaxlimit;
   procMinlimit = t.processorMinlimit;
   procMaxlimit = t.processorMaxlimit;
///////////////////////////////////////////for my get function
//test the minimum 
//  double minimum_processor_length;
//  minimum_processor_length=2*H+2*H+H;//left hole+central+right hole
//  if(procMaxlimit-procMinlimit<minimum_processor_length){
//	printf("in rank %d, the length of processor less than minimum processor(5*h)\n",rank_id);
	
//  }
//
  //get ghost particles
  int rank_id=mpi_rank_id;
  int proc_size=mpi_rank_size;
//  MPI_Comm_rank(MPI_COMM_WORLD,&rank_id);  
//  MPI_Comm_size(MPI_COMM_WORLD,&proc_size);
//test the minimum 
  double minimum_processor_length;
  minimum_processor_length=2*H+2*H;//left hole+central+right hole
  if(procMaxlimit-procMinlimit<minimum_processor_length){
	printf("in rank %d, the length of processor less than minimum processor(4*h)\n",rank_id);
	MPI_Abort(MPI_COMM_WORLD,33);	
  }

  //test for extra space for Posxyz
 // for(unsigned i=Np;i<Np+5;i++){
 //       printf("~~~~~++++++++++++rank_id=%d Posc ------ghost=(%lf,%lf,%lf)\n",rank_id,Posc[i].x,Posc[i].y,Posc[i].z);
 // }

  printf("-------------------------------rank_id=%d\n",mpi_rank_id);
  printf("proceMinlimit=%lf-----to-----proMaxlimit=%lf\n",procMinlimit,procMaxlimit);
  printf("------------------------------------\n");
//  MPI_Barrier(MPI_COMM_WORLD);
 
  vector<unsigned> leftHole,rightHole,centralParticles;
/*  leftGhost.clear();
  rightGhost.clear();
  notGhost.clear();*/
  double leftBoundary,rightBoundary;
  leftBoundary =procMinlimit+2*H;
  rightBoundary=procMaxlimit-2*H;

  for(unsigned g=pinit;g<pfin;g++){
	if(rank_id==0){//for first processor
		//only set rightboundary
		if(t.pos[g].y>=rightBoundary){
			rightHole.push_back(g);
		}else{
			centralParticles.push_back(g);
		}
	}else if(rank_id==proc_size-1){//for last processor
		if(t.pos[g].y<=leftBoundary){
			leftHole.push_back(g);
		}else{
			centralParticles.push_back(g);
		}
	}else{//for middle processor
		if(t.pos[g].y<=leftBoundary){
			leftHole.push_back(g);
		}else if(t.pos[g].y>=rightBoundary){
			rightHole.push_back(g);
		}else{
                        centralParticles.push_back(g);
		}
	}
  }
  //verification
  if(rank_id==0){//for rank 0
	unsigned num_size_right_ghost=rightHole.size();
	unsigned num_size_central    =centralParticles.size();
	unsigned all_num_particles   =num_size_right_ghost+num_size_central;
	if(all_num_particles==n){
//		printf("rank 0 is normal\n");
	}else{
		printf("rank 0:something wrong in divide ghost part\n");
		MPI_Abort(MPI_COMM_WORLD,180);
	}
  }else if(rank_id==proc_size-1){//for the last rank
	unsigned num_size_left_ghost=leftHole.size();
	unsigned num_size_central    =centralParticles.size();
	unsigned all_num_particles   =num_size_left_ghost+num_size_central;
	if(all_num_particles==n){
//		printf("the last rank is normal\n");
	}else{
		printf("the last rank:something wrong in divide ghost part\n");
		MPI_Abort(MPI_COMM_WORLD,181);
	}

  }else{//for central rank
	unsigned num_size_left_ghost=leftHole.size();
	unsigned num_size_right_ghost=rightHole.size();
	unsigned num_size_central    =centralParticles.size();
	unsigned all_num_particles   =num_size_left_ghost+num_size_right_ghost+num_size_central;
	if(all_num_particles==n){
//		printf("the central rank is normal\n");
	}else{
		printf("the central rank:something wrong in divide ghost part\n");
		MPI_Abort(MPI_COMM_WORLD,182);	
	}


  }    
//  printf("***********verification: hole+not hole=%d and all fluid particles =%d\n",rightHole.size()+leftHole.size()+centralParticles.size(),n); 
//  printf("===========rank id %d number of leftHole=%d, rightHole=%d\n",mpi_rank_id,leftHole.size(),rightHole.size()); 
  //get neighbor
  tdouble3 posMinlimit;
  tdouble3 posMaxlimit;
  getPosMinMax(pinit,pfin,t.pos,posMinlimit,posMaxlimit);
  printf("Fourh2=%lf,H=%lf,H*H*4=%lf\n",Fourh2,H,H*H*4);
  printf("==========xmin-xmax(%lf,%lf),ymin-ymax(%lf,%lf),zmin-zmax(%lf,%lf)\n",posMinlimit.x,posMaxlimit.x,posMinlimit.y,posMaxlimit.y,posMinlimit.z,posMaxlimit.z);

  //get the number of cell for x/y/z diretion
  unsigned ncx,ncy,ncz;
  double edge_cell=2*H;
/*
  ncx =(posMaxlimit.x-posMinlimit.x)/edge_cell+1;//need add one,it's hard to divide completely
  ncy =(posMaxlimit.y-posMinlimit.y)/edge_cell+1;//need add one,it's hard to divide completely
  ncz =(posMaxlimit.z-posMinlimit.z)/edge_cell+1;//need add one,it's hard to divide completely

  printf("******grid count is ncx*ncy*cnz=%d\n",ncx*ncy*ncz);
  printf("******ncellx=%d, cell boundary max=%lf, real bounday(particle max for x-dir is %lf\n)",ncx,ncx*edge_cell+posMinlimit.x,posMaxlimit.x);
  printf("******ncelly=%d, cell boundary may=%lf, real bounday(particle max for y-dir is %lf\n)",ncy,ncy*edge_cell+posMinlimit.y,posMaxlimit.y);
  printf("******ncellz=%d, cell boundary maz=%lf, real bounday(particle max for z-dir is %lf\n)",ncz,ncz*edge_cell+posMinlimit.z,posMaxlimit.z);
*/
  //--------------------------collect the number of particles that need to communicate-----------------------------//
  //send num to adjacent processor using MPI send
  unsigned num_hole_particles_going_left=0;
  unsigned num_hole_particles_going_right=0;
  //to get num for self processor using MPI receive
  unsigned num_hole_particles_coming_left=0;
  unsigned num_hole_particles_coming_right=0;

  //set the values
  num_hole_particles_going_left = leftHole.size();//rank 0 leftHole.size() =0
  num_hole_particles_going_right= rightHole.size();//rank 3 rightHole.size()=0

  MPI_Status status1,status2;
  //for left -> right, and get the number of left coming hole particles 
  MPI_Sendrecv(&num_hole_particles_going_right,1,MPI_UNSIGNED,right,40,&num_hole_particles_coming_left,1,MPI_UNSIGNED,left,40,MPI_COMM_WORLD,&status1);
  printf("***************this is rank_id=%d, there are left coming HOLE particles in PI is %d from left rank_id=%d\n",mpi_rank_id,num_hole_particles_coming_left,left);
  
  //for right -> left, and get the number of right coming hole particles
  MPI_Sendrecv(&num_hole_particles_going_left,1,MPI_UNSIGNED,left,41,&num_hole_particles_coming_right,1,MPI_UNSIGNED,right,41,MPI_COMM_WORLD,&status2);
  printf("---------------this is rank_id=%d, there are right coming HOLE particle in PI is %d from right rank_id=%d\n",mpi_rank_id,num_hole_particles_coming_right,right);
  
/*
  //----------------------------------------get the data left------------------------------------------------------//
  //for all
  MPI_Request request[8];
  MPI_Status status[8];
  //left-----to-----right
  ///////for pos/press
  int tags1; 
  int position1;
  char buff1[1000000];
  int buff_length1=1000000;//buff_length >> all newtype length
  //////for velrhop
  int tags2;
  int position2;
  char buff2[1000000];
  int buff_length2=1000000;
 
  //rihgt-----to-----left
  ///////for pos/press
  int tags3; 
  int position3;
  char buff3[1000000];
  int buff_length3=1000000;//buff_length >> all newtype length
  //////for velrhop
  int tags4;
  int position4;
  char buff4[1000000];
  int buff_length4=1000000;
 */
//printf("before: get the values-----rank_id=%d\n",mpi_rank_id);

  //definition variable -------left------to------right
  //for Posx hole
  double *send_hole_particles_right_xx = new double[num_hole_particles_going_right](); 
  double *recv_hole_particles_left_xx  = new double[num_hole_particles_coming_left](); 
  //for Posy hole
  double *send_hole_particles_right_yy = new double[num_hole_particles_going_right](); 
  double *recv_hole_particles_left_yy  = new double[num_hole_particles_coming_left](); 
  //for Posz hole
  double *send_hole_particles_right_zz = new double[num_hole_particles_going_right](); 
  double *recv_hole_particles_left_zz  = new double[num_hole_particles_coming_left](); 
  //for press
  float *send_hole_particles_right_press=new float[num_hole_particles_going_right]();
  float *recv_hole_particles_left_press= new float[num_hole_particles_coming_left]();
  
  //for velrhopc
  //for velrhopx hole
  float *send_hole_particles_right_vx  = new float[num_hole_particles_going_right](); 
  float *recv_hole_particles_left_vx   = new float[num_hole_particles_coming_left](); 
  //for velrhopy hole
  float *send_hole_particles_right_vy  = new float[num_hole_particles_going_right](); 
  float *recv_hole_particles_left_vy   = new float[num_hole_particles_coming_left](); 
  //for velrhopz hole
  float *send_hole_particles_right_vz  = new float[num_hole_particles_going_right](); 
  float *recv_hole_particles_left_vz   = new float[num_hole_particles_coming_left](); 
  //for velrhopw hole
  float *send_hole_particles_right_vr  = new float[num_hole_particles_going_right]();
  float *recv_hole_particles_left_vr   = new float[num_hole_particles_coming_left]();
 
  //definition variable -------right------to------left
  //for Posx hole
  double *send_hole_particles_left_xx  = new double[num_hole_particles_going_left](); 
  double *recv_hole_particles_right_xx = new double[num_hole_particles_coming_right](); 
  //for Posy hole
  double *send_hole_particles_left_yy  = new double[num_hole_particles_going_left](); 
  double *recv_hole_particles_right_yy = new double[num_hole_particles_coming_right](); 
  //for Posz hole
  double *send_hole_particles_left_zz  = new double[num_hole_particles_going_left](); 
  double *recv_hole_particles_right_zz = new double[num_hole_particles_coming_right](); 
  //for press
  float *send_hole_particles_left_press= new float[num_hole_particles_going_left]();
  float *recv_hole_particles_right_press=new float[num_hole_particles_coming_right]();
  
  //for velrhopc
  //for velrhopx hole
  float *send_hole_particles_left_vx   = new float[num_hole_particles_going_left](); 
  float *recv_hole_particles_right_vx  = new float[num_hole_particles_coming_right](); 
  //for velrhopy hole
  float *send_hole_particles_left_vy   = new float[num_hole_particles_going_left](); 
  float *recv_hole_particles_right_vy  = new float[num_hole_particles_coming_right](); 
  //for velrhopz hole
  float *send_hole_particles_left_vz   = new float[num_hole_particles_going_left](); 
  float *recv_hole_particles_right_vz  = new float[num_hole_particles_coming_right](); 
  //for velrhopw hole
  float *send_hole_particles_left_vr   = new float[num_hole_particles_going_left]();
  float *recv_hole_particles_right_vr  = new float[num_hole_particles_coming_right]();
 
  //set values-----------left----------to---------right
  unsigned p1 = 0;
  #ifdef OMP_USE
      #pragma omp parallel for schedule (static)
  #endif
  for(unsigned i=0;i<num_hole_particles_going_right;i++){
	p1 = rightHole[i];
	//posx hole
	send_hole_particles_right_xx[i] = t.pos[p1].x;
	//posy hole
	send_hole_particles_right_yy[i] = t.pos[p1].y;
	//posz hole
	send_hole_particles_right_zz[i] = t.pos[p1].z;
	//press hole
	send_hole_particles_right_press[i] = t.press[p1];
//	printf("press[%d]=%lf, ",i,t.press[p1]);
	//velrhopx
	send_hole_particles_right_vx[i] = t.velrhop[p1].x;
	//velrhopy
	send_hole_particles_right_vy[i] = t.velrhop[p1].y;
	//velrhopz
	send_hole_particles_right_vz[i] = t.velrhop[p1].z;
	//velrhopw
	send_hole_particles_right_vr[i] = t.velrhop[p1].w;
	
  }
 
  //set values-----------right----------to---------left
  unsigned p2 = 0;
  #ifdef OMP_USE
      #pragma omp parallel for schedule (static)
  #endif
  for(unsigned i=0;i<num_hole_particles_going_left;i++){
	p2 = leftHole[i];
	//posx hole
	send_hole_particles_left_xx[i] = t.pos[p2].x;
	//posy hole
	send_hole_particles_left_yy[i] = t.pos[p2].y;
	//posz hole
	send_hole_particles_left_zz[i] = t.pos[p2].z;
	//press hole
	send_hole_particles_left_press[i] = t.press[p2];
//	printf("press[%d]=%lf, ",i,t.press[p1]);
	//velrhopx
	send_hole_particles_left_vx[i] = t.velrhop[p2].x;
	//velrhopy
	send_hole_particles_left_vy[i] = t.velrhop[p2].y;
	//velrhopz
	send_hole_particles_left_vz[i] = t.velrhop[p2].z;
	//velrhopw
	send_hole_particles_left_vr[i] = t.velrhop[p2].w;
	
  }
/*
  //-------------right------to--------left---------------//
  //for Pos/press
  //set start pack
  int len1[4];
  MPI_Aint disp1[4];
  MPI_Datatype type1[4],new_type1;
  //set the length for new type
  len1[0] = num_hole_particles_going_right;
  len1[1] = num_hole_particles_going_right;
  len1[2] = num_hole_particles_going_right;
  len1[3] = num_hole_particles_going_right;
  //calculate bias for MPI_BOTTOM
  MPI_Address(send_hole_particles_right_xx, disp1);
  MPI_Address(send_hole_particles_right_yy, disp1+1);
  MPI_Address(send_hole_particles_right_zz, disp1+2);
  MPI_Address(send_hole_particles_right_press, disp1+3);
  //set the original data type
  type1[0] = MPI_DOUBLE;
  type1[1] = MPI_DOUBLE;
  type1[2] = MPI_DOUBLE;
  type1[3] = MPI_FLOAT;
  //definition new data type
  MPI_Type_struct(4,len1,disp1,type1,&new_type1);
  //submit new datatype
  MPI_Type_commit(&new_type1);
  //set the start position for pack
  position1 = 0;
  //start packing
  MPI_Pack(MPI_BOTTOM,1,new_type1,buff1,buff_length1,&position1,MPI_COMM_WORLD);

  //for velrhop
  //set start pack
  int len2[4];
  MPI_Aint disp2[4];
  MPI_Datatype type2[4],new_type2;
  //set the length for new type
  len2[0] = num_hole_particles_going_right;
  len2[1] = num_hole_particles_going_right;
  len2[2] = num_hole_particles_going_right;
  len2[3] = num_hole_particles_going_right;
  //calculate bias for MPI_BOTTOM
  MPI_Address(send_hole_particles_right_vx, disp2);
  MPI_Address(send_hole_particles_right_vy, disp2+1);
  MPI_Address(send_hole_particles_right_vz, disp2+2);
  MPI_Address(send_hole_particles_right_vr, disp2+3);
  //set the original data type
  type2[0] = MPI_FLOAT;
  type2[1] = MPI_FLOAT;
  type2[2] = MPI_FLOAT;
  type2[3] = MPI_FLOAT;
  //definition new data type
  MPI_Type_struct(4,len2,disp2,type2,&new_type2);
  //submit new datatype
  MPI_Type_commit(&new_type2);
  //set the start position for pack
  position2 = 0;
  //start packing
  MPI_Pack(MPI_BOTTOM,1,new_type2,buff2,buff_length2,&position2,MPI_COMM_WORLD);

  //-------------left------to--------right---------------//
  //for Pos/press
  //set start pack
  int len3[4];
  MPI_Aint disp3[4];
  MPI_Datatype type3[4],new_type3;
  //set the length for new type
  len3[0] = num_hole_particles_going_left;
  len3[1] = num_hole_particles_going_left;
  len3[2] = num_hole_particles_going_left;
  len3[3] = num_hole_particles_going_left;
  //calculate bias for MPI_BOTTOM
  MPI_Address(send_hole_particles_left_xx, disp3);
  MPI_Address(send_hole_particles_left_yy, disp3+1);
  MPI_Address(send_hole_particles_left_zz, disp3+2);
  MPI_Address(send_hole_particles_left_press, disp3+3);
  //set the original data type
  type3[0] = MPI_DOUBLE;
  type3[1] = MPI_DOUBLE;
  type3[2] = MPI_DOUBLE;
  type3[3] = MPI_FLOAT;
  //definition new data type
  MPI_Type_struct(4,len3,disp3,type3,&new_type3);
  //submit new datatype
  MPI_Type_commit(&new_type3);
  //set the start position for pack
  position3 = 0;
  //start packing
  MPI_Pack(MPI_BOTTOM,1,new_type3,buff3,buff_length3,&position3,MPI_COMM_WORLD);

  //for velrhop
  //set start pack
  int len4[4];
  MPI_Aint disp4[4];
  MPI_Datatype type4[4],new_type4;
  //set the length for new type
  len4[0] = num_hole_particles_going_left;
  len4[1] = num_hole_particles_going_left;
  len4[2] = num_hole_particles_going_left;
  len4[3] = num_hole_particles_going_left;
  //calculate bias for MPI_BOTTOM
  MPI_Address(send_hole_particles_left_vx, disp4);
  MPI_Address(send_hole_particles_left_vy, disp4+1);
  MPI_Address(send_hole_particles_left_vz, disp4+2);
  MPI_Address(send_hole_particles_left_vr, disp4+3);
  //set the original data type
  type4[0] = MPI_FLOAT;
  type4[1] = MPI_FLOAT;
  type4[2] = MPI_FLOAT;
  type4[3] = MPI_FLOAT;
  //definition new data type
  MPI_Type_struct(4,len4,disp4,type4,&new_type4);
  //submit new datatype
  MPI_Type_commit(&new_type4);
  //set the start position for pack
  position4 = 0;
  //start packing
  MPI_Pack(MPI_BOTTOM,1,new_type4,buff4,buff_length4,&position4,MPI_COMM_WORLD);


  //-----x------x-------x------x------Isend/Irecv-----x------x------x--------x--------//
  //send data from left-----to------right
  //send posc/press
  MPI_Isend(buff1,position1,MPI_PACKED,right,tags1,MPI_COMM_WORLD,&request[0]);
  //send velrhop
  MPI_Isend(buff2,position2,MPI_PACKED,right,tags2,MPI_COMM_WORLD,&request[1]);
  //send data from right.....to......left
  //send posc/press
  MPI_Isend(buff3,position3,MPI_PACKED,left, tags3,MPI_COMM_WORLD,&request[2]);
  //send velrhop
  MPI_Isend(buff4,position4,MPI_PACKED,left, tags4,MPI_COMM_WORLD,&request[3]);

  //receive data from right----to----left
  //recv posc/press
  MPI_Irecv(buff1,buff_length1,MPI_PACKED,left,tags1,MPI_COMM_WORLD,&request[4]);
  //recv velrhop
  MPI_Irecv(buff2,buff_length2,MPI_PACKED,left,tags2,MPI_COMM_WORLD,&request[5]);
  //receive data from left......to......right
  //recv posc/press
  MPI_Irecv(buff3,buff_length3,MPI_PACKED,right,tags3,MPI_COMM_WORLD,&request[6]);
  //recv velrhop
  MPI_Irecv(buff4,buff_length4,MPI_PACKED,right,tags4,MPI_COMM_WORLD,&request[7]);
*/
  MPI_Status status[32];
  MPI_Request request[32];
  //Isend--------------right--------------to----------------left
  MPI_Isend(send_hole_particles_right_xx,num_hole_particles_going_right,MPI_DOUBLE,right,210,MPI_COMM_WORLD,&request[0]);
  MPI_Isend(send_hole_particles_right_yy,num_hole_particles_going_right,MPI_DOUBLE,right,211,MPI_COMM_WORLD,&request[1]);
  MPI_Isend(send_hole_particles_right_zz,num_hole_particles_going_right,MPI_DOUBLE,right,212,MPI_COMM_WORLD,&request[2]);
  MPI_Isend(send_hole_particles_right_press,num_hole_particles_going_right,MPI_FLOAT,right,213,MPI_COMM_WORLD,&request[3]);

  MPI_Isend(send_hole_particles_right_vx,num_hole_particles_going_right,MPI_FLOAT,right,214,MPI_COMM_WORLD,&request[4]);
  MPI_Isend(send_hole_particles_right_vy,num_hole_particles_going_right,MPI_FLOAT,right,215,MPI_COMM_WORLD,&request[5]);
  MPI_Isend(send_hole_particles_right_vz,num_hole_particles_going_right,MPI_FLOAT,right,216,MPI_COMM_WORLD,&request[6]);
  MPI_Isend(send_hole_particles_right_vr,num_hole_particles_going_right,MPI_FLOAT,right,217,MPI_COMM_WORLD,&request[7]);
  //Isend---------------left--------------to---------------right
  MPI_Isend(send_hole_particles_left_xx,num_hole_particles_going_left,MPI_DOUBLE,left,218,MPI_COMM_WORLD,&request[8]);
  MPI_Isend(send_hole_particles_left_yy,num_hole_particles_going_left,MPI_DOUBLE,left,219,MPI_COMM_WORLD,&request[9]);
  MPI_Isend(send_hole_particles_left_zz,num_hole_particles_going_left,MPI_DOUBLE,left,220,MPI_COMM_WORLD,&request[10]);
  MPI_Isend(send_hole_particles_left_press,num_hole_particles_going_left,MPI_FLOAT,left,221,MPI_COMM_WORLD,&request[11]);

  MPI_Isend(send_hole_particles_left_vx,num_hole_particles_going_left,MPI_FLOAT,left,222,MPI_COMM_WORLD,&request[12]);
  MPI_Isend(send_hole_particles_left_vy,num_hole_particles_going_left,MPI_FLOAT,left,223,MPI_COMM_WORLD,&request[13]);
  MPI_Isend(send_hole_particles_left_vz,num_hole_particles_going_left,MPI_FLOAT,left,224,MPI_COMM_WORLD,&request[14]);
  MPI_Isend(send_hole_particles_left_vr,num_hole_particles_going_left,MPI_FLOAT,left,225,MPI_COMM_WORLD,&request[15]);

  //Irecv-------------------------------------------------------------
  MPI_Irecv(recv_hole_particles_left_xx,num_hole_particles_coming_left,MPI_DOUBLE,left,210,MPI_COMM_WORLD,&request[16]);
  MPI_Irecv(recv_hole_particles_left_yy,num_hole_particles_coming_left,MPI_DOUBLE,left,211,MPI_COMM_WORLD,&request[17]);
  MPI_Irecv(recv_hole_particles_left_zz,num_hole_particles_coming_left,MPI_DOUBLE,left,212,MPI_COMM_WORLD,&request[18]);
  MPI_Irecv(recv_hole_particles_left_press,num_hole_particles_coming_left,MPI_FLOAT,left,213,MPI_COMM_WORLD,&request[19]);

  MPI_Irecv(recv_hole_particles_left_vx,num_hole_particles_coming_left,MPI_FLOAT,left,214,MPI_COMM_WORLD,&request[20]);
  MPI_Irecv(recv_hole_particles_left_vy,num_hole_particles_coming_left,MPI_FLOAT,left,215,MPI_COMM_WORLD,&request[21]);
  MPI_Irecv(recv_hole_particles_left_vz,num_hole_particles_coming_left,MPI_FLOAT,left,216,MPI_COMM_WORLD,&request[22]);
  MPI_Irecv(recv_hole_particles_left_vr,num_hole_particles_coming_left,MPI_FLOAT,left,217,MPI_COMM_WORLD,&request[23]);
  //Isend---------------left--------------to---------------right
  MPI_Irecv(recv_hole_particles_right_xx,num_hole_particles_coming_right,MPI_DOUBLE,right,218,MPI_COMM_WORLD,&request[24]);
  MPI_Irecv(recv_hole_particles_right_yy,num_hole_particles_coming_right,MPI_DOUBLE,right,219,MPI_COMM_WORLD,&request[25]);
  MPI_Irecv(recv_hole_particles_right_zz,num_hole_particles_coming_right,MPI_DOUBLE,right,220,MPI_COMM_WORLD,&request[26]);
  MPI_Irecv(recv_hole_particles_right_press,num_hole_particles_coming_right,MPI_FLOAT,right,221,MPI_COMM_WORLD,&request[27]);

  MPI_Irecv(recv_hole_particles_right_vx,num_hole_particles_coming_right,MPI_FLOAT,right,222,MPI_COMM_WORLD,&request[28]);
  MPI_Irecv(recv_hole_particles_right_vy,num_hole_particles_coming_right,MPI_FLOAT,right,223,MPI_COMM_WORLD,&request[29]);
  MPI_Irecv(recv_hole_particles_right_vz,num_hole_particles_coming_right,MPI_FLOAT,right,224,MPI_COMM_WORLD,&request[30]);
  MPI_Irecv(recv_hole_particles_right_vr,num_hole_particles_coming_right,MPI_FLOAT,right,225,MPI_COMM_WORLD,&request[31]);

  //------+------+-------+---------do other things------+-----+-------+---------+-----//
  printf("do other things, calculate central part....\n");
  //notghost+(all particles)+central particles
  //  in order to calculate acceleration 
  InteractionForcesFluidFluidOnly<tker,ftmode,lamsps,tdensity,shift> (t.npf,t.npb,nc,hdiv,cellfluid,Visco,t.begincell,cellzero,t.dcell,t.spstau,t.spsgradvel,  t.pos,t.velrhop,t.code,t.idp,t.press,viscdt,t.ar,t.ace,t.delta,t.shiftmode,t.shiftposfs,t.processorMinlimit,t.processorMaxlimit,&centralParticles);

  //wait all
  MPI_Waitall(32,request,status);
 
/*
  //waiting for left------to-------right
  MPI_Wait(&request[0],&status[0]);
  MPI_Wait(&request[1],&status[1]);
  MPI_Wait(&request[2],&status[2]);
  MPI_Wait(&request[3],&status[3]);
  //waiting for right------to-------left
  MPI_Wait(&request[4],&status[4]);
  MPI_Wait(&request[5],&status[5]);
  MPI_Wait(&request[6],&status[6]);
  MPI_Wait(&request[7],&status[7]);
  //waiting for left------to-------right
  MPI_Wait(&request[8],&status[8]);
  MPI_Wait(&request[9],&status[9]);
  MPI_Wait(&request[10],&status[10]);
  MPI_Wait(&request[11],&status[11]);
  //waiting for right------to-------left
  MPI_Wait(&request[12],&status[12]);
  MPI_Wait(&request[13],&status[13]);
  MPI_Wait(&request[14],&status[14]);
  MPI_Wait(&request[15],&status[15]);
  //waiting for left------to-------right
  MPI_Wait(&request[16],&status[16]);
  MPI_Wait(&request[17],&status[17]);
  MPI_Wait(&request[18],&status[18]);
  MPI_Wait(&request[19],&status[19]);
  //waiting for right------to-------left
  MPI_Wait(&request[20],&status[20]);
  MPI_Wait(&request[21],&status[21]);
  MPI_Wait(&request[22],&status[22]);
  MPI_Wait(&request[23],&status[23]);
  //waiting for left------to-------right
  MPI_Wait(&request[24],&status[24]);
  MPI_Wait(&request[25],&status[25]);
  MPI_Wait(&request[26],&status[26]);
  MPI_Wait(&request[27],&status[27]);
  //waiting for right------to-------left
  MPI_Wait(&request[28],&status[28]);
  MPI_Wait(&request[29],&status[29]);
  MPI_Wait(&request[30],&status[30]);
  MPI_Wait(&request[31],&status[31]);
/*
  //---------------------------------UnPacked-----------------------------------------//
  //unPacked left---------to---------right
  //set the position as 0
  position1 = 0;
  //unpacked pos xx from left processor
  MPI_Unpack(buff1,buff_length1,&position1,recv_hole_particles_left_xx,num_hole_particles_coming_left,MPI_DOUBLE,MPI_COMM_WORLD); 
  //unpacked pos yy from left processor
  MPI_Unpack(buff1,buff_length1,&position1,recv_hole_particles_left_yy,num_hole_particles_coming_left,MPI_DOUBLE,MPI_COMM_WORLD); 
  //unpacked pos zz from left processor
  MPI_Unpack(buff1,buff_length1,&position1,recv_hole_particles_left_zz,num_hole_particles_coming_left,MPI_DOUBLE,MPI_COMM_WORLD); 
  //unpacked pos press from left processor
  MPI_Unpack(buff1,buff_length1,&position1,recv_hole_particles_left_press,num_hole_particles_coming_left,MPI_FLOAT,MPI_COMM_WORLD); 
  
  //set the position as 0
  position2 = 0;
  //unpacked velrhopx from left processor
  MPI_Unpack(buff2,buff_length2,&position2,recv_hole_particles_left_vx,num_hole_particles_coming_left,MPI_FLOAT,MPI_COMM_WORLD); 
  //unpacked velrhopy from left processor
  MPI_Unpack(buff2,buff_length2,&position2,recv_hole_particles_left_vy,num_hole_particles_coming_left,MPI_FLOAT,MPI_COMM_WORLD); 
  //unpacked velrhopz from left processor
  MPI_Unpack(buff2,buff_length2,&position2,recv_hole_particles_left_vz,num_hole_particles_coming_left,MPI_FLOAT,MPI_COMM_WORLD); 
  //unpacked velrhopw from left processor
  MPI_Unpack(buff2,buff_length2,&position2,recv_hole_particles_left_vr,num_hole_particles_coming_left,MPI_FLOAT,MPI_COMM_WORLD); 
  
  //unPacked right.........to..........left
  //set the position as 0
  position3 = 0;
  //unpacked pos xx from left processor
  MPI_Unpack(buff3,buff_length3,&position3,recv_hole_particles_right_xx,num_hole_particles_coming_right,MPI_DOUBLE,MPI_COMM_WORLD); 
  //unpacked pos yy from left processor
  MPI_Unpack(buff3,buff_length3,&position3,recv_hole_particles_right_yy,num_hole_particles_coming_right,MPI_DOUBLE,MPI_COMM_WORLD); 
  //unpacked pos zz from left processor
  MPI_Unpack(buff3,buff_length3,&position3,recv_hole_particles_right_zz,num_hole_particles_coming_right,MPI_DOUBLE,MPI_COMM_WORLD); 
  //unpacked pos press from left processor
  MPI_Unpack(buff3,buff_length3,&position3,recv_hole_particles_right_press,num_hole_particles_coming_right,MPI_FLOAT,MPI_COMM_WORLD); 
  
  //set the position as 0
  position4 = 0;
  //unpacked velrhopx from left processor
  MPI_Unpack(buff4,buff_length4,&position4,recv_hole_particles_right_vx,num_hole_particles_coming_right,MPI_FLOAT,MPI_COMM_WORLD); 
  //unpacked velrhopy from left processor
  MPI_Unpack(buff4,buff_length4,&position4,recv_hole_particles_right_vy,num_hole_particles_coming_right,MPI_FLOAT,MPI_COMM_WORLD); 
  //unpacked velrhopz from left processor
  MPI_Unpack(buff4,buff_length4,&position4,recv_hole_particles_right_vz,num_hole_particles_coming_right,MPI_FLOAT,MPI_COMM_WORLD); 
  //unpacked velrhopw from left processor
  MPI_Unpack(buff4,buff_length4,&position4,recv_hole_particles_right_vr,num_hole_particles_coming_right,MPI_FLOAT,MPI_COMM_WORLD); 
*/
/* 
  hole_ghost_coming_left_vx = &recv_hole_particles_left_vx;
  hole_ghost_coming_left_vy = &recv_hole_particles_left_vy;
  hole_ghost_coming_left_vz = &recv_hole_particles_left_vz;
  hole_ghost_coming_left_vr = &recv_hole_particles_left_vr;
*/
  
  //test using send  recv
//  double *send_hole_particles_right_xx_test = new double[num_hole_particles_going_right]();
/*
  MPI_Barrier(MPI_COMM_WORLD);
  // left-------to---------right
  float *recv_hole_particles_left_vx_test  = new float[num_hole_particles_coming_left]();
  float *recv_hole_particles_left_vy_test  = new float[num_hole_particles_coming_left]();
  float *recv_hole_particles_left_vr_test  = new float[num_hole_particles_coming_left]();
  // right-------to---------left
  float *recv_hole_particles_right_vx_test  = new float[num_hole_particles_coming_right]();
  float *recv_hole_particles_right_vy_test  = new float[num_hole_particles_coming_right]();
  float *recv_hole_particles_right_vr_test  = new float[num_hole_particles_coming_right]();

  //right ----------------- to ---------------------left
  MPI_Status  status_test[16];
  MPI_Sendrecv(send_hole_particles_right_xx,num_hole_particles_going_right,MPI_DOUBLE,right,880,
	       recv_hole_particles_left_xx,num_hole_particles_coming_left,MPI_DOUBLE,left,880,MPI_COMM_WORLD,&status_test[0]);
  MPI_Sendrecv(send_hole_particles_right_yy,num_hole_particles_going_right,MPI_DOUBLE,right,881,
	       recv_hole_particles_left_yy,num_hole_particles_coming_left,MPI_DOUBLE,left,881,MPI_COMM_WORLD,&status_test[1]);  
  MPI_Sendrecv(send_hole_particles_right_zz,num_hole_particles_going_right,MPI_DOUBLE,right,735,
               recv_hole_particles_left_zz,num_hole_particles_coming_left,MPI_DOUBLE,left,735,MPI_COMM_WORLD,&status_test[2]);
  MPI_Sendrecv(send_hole_particles_right_press,num_hole_particles_going_right,MPI_FLOAT,right,882,
               recv_hole_particles_left_press,num_hole_particles_coming_left,MPI_FLOAT,left,882,MPI_COMM_WORLD,&status_test[3]);

  MPI_Sendrecv(send_hole_particles_right_vx,num_hole_particles_going_right,MPI_FLOAT,right,883,
	       recv_hole_particles_left_vx,num_hole_particles_coming_left,MPI_FLOAT,left,883,MPI_COMM_WORLD,&status_test[4]);
  MPI_Sendrecv(send_hole_particles_right_vy,num_hole_particles_going_right,MPI_FLOAT,right,884,
               recv_hole_particles_left_vy,num_hole_particles_coming_left,MPI_FLOAT,left,884,MPI_COMM_WORLD,&status_test[5]);
  MPI_Sendrecv(send_hole_particles_right_vz,num_hole_particles_going_right,MPI_FLOAT,right,885,
               recv_hole_particles_left_vz,num_hole_particles_coming_left,MPI_FLOAT,left,885,MPI_COMM_WORLD,&status_test[6]);
  MPI_Sendrecv(send_hole_particles_right_vr,num_hole_particles_going_right,MPI_FLOAT,right,886,
               recv_hole_particles_left_vr,num_hole_particles_coming_left,MPI_FLOAT,left,886,MPI_COMM_WORLD,&status_test[7]);

  //left-------------------to-----------------------right
  MPI_Sendrecv(send_hole_particles_left_xx,num_hole_particles_going_left,MPI_DOUBLE,left,887,
	       recv_hole_particles_right_xx,num_hole_particles_coming_right,MPI_DOUBLE,right,887,MPI_COMM_WORLD,&status_test[8]);
  MPI_Sendrecv(send_hole_particles_left_yy,num_hole_particles_going_left,MPI_DOUBLE,left,888,
	       recv_hole_particles_right_yy,num_hole_particles_coming_right,MPI_DOUBLE,right,888,MPI_COMM_WORLD,&status_test[9]);  
  MPI_Sendrecv(send_hole_particles_left_zz,num_hole_particles_going_left,MPI_DOUBLE,left,889,
               recv_hole_particles_right_zz,num_hole_particles_coming_right,MPI_DOUBLE,right,889,MPI_COMM_WORLD,&status_test[10]);
  MPI_Sendrecv(send_hole_particles_left_press,num_hole_particles_going_left,MPI_FLOAT,left,234,
               recv_hole_particles_right_press,num_hole_particles_coming_right,MPI_FLOAT,right,234,MPI_COMM_WORLD,&status_test[11]);

  MPI_Sendrecv(send_hole_particles_left_vx,num_hole_particles_going_left,MPI_FLOAT,left,235,
	       recv_hole_particles_right_vx,num_hole_particles_coming_right,MPI_FLOAT,right,235,MPI_COMM_WORLD,&status_test[12]);
  MPI_Sendrecv(send_hole_particles_left_vy,num_hole_particles_going_left,MPI_FLOAT,left,236,
               recv_hole_particles_right_vy,num_hole_particles_coming_right,MPI_FLOAT,right,236,MPI_COMM_WORLD,&status_test[13]);
  MPI_Sendrecv(send_hole_particles_left_vz,num_hole_particles_going_left,MPI_FLOAT,left,237,
               recv_hole_particles_right_vz,num_hole_particles_coming_right,MPI_FLOAT,right,237,MPI_COMM_WORLD,&status_test[14]);
  MPI_Sendrecv(send_hole_particles_left_vr,num_hole_particles_going_left,MPI_FLOAT,left,238,
               recv_hole_particles_right_vr,num_hole_particles_coming_right,MPI_FLOAT,right,238,MPI_COMM_WORLD,&status_test[15]);

*/
//test the values 
//  for(unsigned i=0;i<num_hole_particles_coming_right;i++){
//	printf("pos/press[%d]={%lf,%lf,%lf,%lf}, ",i,recv_hole_particles_right_xx[i],recv_hole_particles_right_yy[i],
//	recv_hole_particles_right_zz[i],recv_hole_particles_right_press[i]);
//	printf("velrhop[%d]={%lf,%lf,%lf,%lf}, ",i,recv_hole_particles_right_vx[i],recv_hole_particles_right_vy[i],
//        recv_hole_particles_right_vz[i],recv_hole_particles_right_vr[i]);
//        printf("hole_velrhop[%d]={%lf,%lf,%lf,%lf}, ",i,hole_ghost_coming_right_vx[i],hole_ghost_coming_right_vy[i],
//        hole_ghost_coming_right_vz[i],hole_ghost_coming_right_vr[i]);
//  }

//-------------------------------------set value for member variable---------------------------------------------//
//  hole_ghost_coming_left_xx = &recv_hole_particles_left_xx;
  
printf("after: get the values-----rank_id=%d\n",mpi_rank_id);
//centra part
// InteractionForcesFluidFluidOnly<tker,ftmode,lamsps,tdensity,shift> (t.npf,t.npb,nc,hdiv,cellfluid,Visco, t.begincell,cellzero,t.dcell,t.spstau,t.spsgradvel, t.pos,t.velrhop,t.code,t.idp,t.press,viscdt,t.ar,t.ace,t.delta,t.shiftmode,t.shiftposfs,t.processorMinlimit,t.processorMaxlimit,&centralParticles);

//  in order to calculate acceleration 
//left--hole--ghost+(all particles) rank_id=0--------->leftHole.size=0 
if(rank_id!=0){  
  MPI_Hole_InteractionForcesFluidFluidOnly<tker,ftmode,lamsps,tdensity,shift> (t.npf,t.npb,nc,hdiv,cellfluid,Visco,   t.begincell,cellzero,t.dcell,t.spstau,t.spsgradvel,t.pos,  t.velrhop,
  t.code,t.idp,t.press,viscdt,t.ar,t.ace,t.delta,t.shiftmode,t.shiftposfs,t.processorMinlimit,t.processorMaxlimit,&leftHole,num_hole_particles_coming_left,
  recv_hole_particles_left_xx,recv_hole_particles_left_yy,recv_hole_particles_left_zz,recv_hole_particles_left_press,
  recv_hole_particles_left_vx,recv_hole_particles_left_vy,recv_hole_particles_left_vz,recv_hole_particles_left_vr);
}
//right--hole--ghost+(all particles) rank_id=size-1--->rightHole.size=0
//  MPI_Right_Hole_InteractionForcesFluidFluidOnly<tker,ftmode,lamsps,tdensity,shift> (t.npf,t.npb,nc,hdiv,cellfluid,Visco,    t.begincell,cellzero,t.dcell,t.spstau,t.spsgradvel,
//  t.pos,t.velrhop,t.code,t.idp,t.press,viscdt,t.ar,t.ace,t.delta,t.shiftmode,t.shiftposfs,t.processorMinlimit,t.processorMaxlimit,&rightHole);
if(rank_id!=(proc_size-1)){
  MPI_Hole_InteractionForcesFluidFluidOnly<tker,ftmode,lamsps,tdensity,shift> (t.npf,t.npb,nc,hdiv,cellfluid,Visco,   t.begincell,cellzero,t.dcell,t.spstau,t.spsgradvel,t.pos,  t.velrhop,
  t.code,t.idp,t.press,viscdt,t.ar,t.ace,t.delta,t.shiftmode,t.shiftposfs,t.processorMinlimit,t.processorMaxlimit,&rightHole,num_hole_particles_coming_right,
  recv_hole_particles_right_xx,recv_hole_particles_right_yy,recv_hole_particles_right_zz,recv_hole_particles_right_press,
  recv_hole_particles_right_vx,recv_hole_particles_right_vy,recv_hole_particles_right_vz,recv_hole_particles_right_vr);
}
  //clear record
  leftHole.clear();
  rightHole.clear();
  centralParticles.clear();
  //ensure before delete memory,because of pointer
/*  hole_ghost_coming_left_vx = NULL;
  hole_ghost_coming_left_vy = NULL;
  hole_ghost_coming_left_vz = NULL;
  hole_ghost_coming_left_vr = NULL;
*/  
  //free the memory
  //left----------------------------to---------------------------------right
  //pos
  delete[] send_hole_particles_right_xx;send_hole_particles_right_xx=NULL;
  delete[] recv_hole_particles_left_xx; recv_hole_particles_left_xx=NULL;
  
  delete[] send_hole_particles_right_yy;send_hole_particles_right_yy=NULL;
  delete[] recv_hole_particles_left_yy; recv_hole_particles_left_yy=NULL;

  delete[] send_hole_particles_right_zz;send_hole_particles_right_zz=NULL;
  delete[] recv_hole_particles_left_zz; recv_hole_particles_left_zz=NULL;
  //press
  delete[] send_hole_particles_right_press;send_hole_particles_right_press=NULL;
  delete[] recv_hole_particles_left_press; recv_hole_particles_left_press=NULL;
  //velrhop
  delete[] send_hole_particles_right_vx;send_hole_particles_right_vx=NULL;
  delete[] recv_hole_particles_left_vx; recv_hole_particles_left_vx=NULL;
  
  delete[] send_hole_particles_right_vy;send_hole_particles_right_vy=NULL;
  delete[] recv_hole_particles_left_vy; recv_hole_particles_left_vy=NULL;

  delete[] send_hole_particles_right_vz;send_hole_particles_right_vz=NULL;
  delete[] recv_hole_particles_left_vz; recv_hole_particles_left_vz=NULL;
 
  delete[] send_hole_particles_right_vr;send_hole_particles_right_vr=NULL;
  delete[] recv_hole_particles_left_vr; recv_hole_particles_left_vr=NULL;

  //right----------------------------to---------------------------------left
  //pos
  delete[] send_hole_particles_left_xx;send_hole_particles_left_xx=NULL;
  delete[] recv_hole_particles_right_xx; recv_hole_particles_right_xx=NULL;
  
  delete[] send_hole_particles_left_yy;send_hole_particles_left_yy=NULL;
  delete[] recv_hole_particles_right_yy; recv_hole_particles_right_yy=NULL;

  delete[] send_hole_particles_left_zz;send_hole_particles_left_zz=NULL;
  delete[] recv_hole_particles_right_zz; recv_hole_particles_right_zz=NULL;
  //press
  delete[] send_hole_particles_left_press;send_hole_particles_left_press=NULL;
  delete[] recv_hole_particles_right_press; recv_hole_particles_right_press=NULL;
  //velrhop
  delete[] send_hole_particles_left_vx;send_hole_particles_left_vx=NULL;
  delete[] recv_hole_particles_right_vx; recv_hole_particles_right_vx=NULL;
  
  delete[] send_hole_particles_left_vy;send_hole_particles_left_vy=NULL;
  delete[] recv_hole_particles_right_vy; recv_hole_particles_right_vy=NULL;

  delete[] send_hole_particles_left_vz;send_hole_particles_left_vz=NULL;
  delete[] recv_hole_particles_right_vz; recv_hole_particles_right_vz=NULL;
 
  delete[] send_hole_particles_left_vr;send_hole_particles_left_vr=NULL;
  delete[] recv_hole_particles_right_vr; recv_hole_particles_right_vr=NULL;


}

//==============================================================================
/// Interaction of Fluid-Fluid/Bound & Bound-Fluid (forces and DEM).
/// Interaccion Fluid-Fluid/Bound & Bound-Fluid (forces and DEM).
//==============================================================================
template<TpKernel tker,TpFtMode ftmode,bool lamsps,TpDensity tdensity,bool shift>
  void JSphCpu::Interaction_ForcesCpuT(const stinterparmsc &t,float &viscdt)const
{
  const tint4 nc=TInt4(int(t.ncells.x),int(t.ncells.y),int(t.ncells.z),int(t.ncells.x*t.ncells.y));
  const tint3 cellzero=TInt3(t.cellmin.x,t.cellmin.y,t.cellmin.z);
  const unsigned cellfluid=nc.w*nc.z+1;
  const int hdiv=(CellMode==CELLMODE_H? 2: 1);
  
  if(t.npf){
//    printf("------interaction fluid-fluid\n");
    //-Interaction Fluid-Fluid only.
    MPI_Strategy_InteractionForcesFluidFluidOnly<tker,ftmode,lamsps,tdensity,shift> (t,viscdt,nc,cellzero,cellfluid,hdiv);
//    InteractionForcesFluidFluidOnly<tker,ftmode,lamsps,tdensity,shift> (t.npf,t.npb,nc,hdiv,cellfluid,Visco,    t.begincell,cellzero,t.dcell,t.spstau,t.spsgradvel,t.pos,t.velrhop,t.code,t.idp,t.press,viscdt,t.ar,t.ace,t.delta,t.shiftmode,t.shiftposfs,t.processorMinlimit,t.processorMaxlimit);
//    printf("******interaction fluid-bound\n");
    //-Interaction Fluid-Bound only.
    InteractionForcesFluidBoundOnly<tker,ftmode,lamsps,tdensity,shift> (t.npf,t.npb,nc,hdiv,0   ,Visco*ViscoBoundFactor,t.begincell,cellzero,t.dcell,t.spstau,t.spsgradvel,t.pos,t.velrhop,t.code,t.idp,    t.press,viscdt,t.ar,t.ace,t.delta,t.shiftmode,t.shiftposfs);

    //not work for dambreak
    //-Interaction of DEM Floating-Bound & Floating-Floating. //(DEM)
    if(UseDEM){//not work for dambreak
//	printf("*****useDEM\n");
	InteractionForcesDEM(CaseNfloat,nc,hdiv,cellfluid,t.begincell,cellzero,t.dcell,FtRidp,DemData,t.pos,t.velrhop,t.code,t.idp,viscdt,t.ace);
    }
    //not work for dambreak
    //-Computes tau for Laminar+SPS.
    if(lamsps){//not work for dambreak
//	printf("*****Laminar+SPS\n");
	ComputeSpsTau(t.npf,t.npb,t.velrhop,t.spsgradvel,t.spstau);
    }
  }
  if(t.npbok){//dam break is work
//    printf("interaction Bound-fluid (force and DEM)\n");
    //-Interaction Bound-Fluid.
    InteractionForcesBound<tker,ftmode> (t.npf,t.npb,t.npbok,0,nc,hdiv,cellfluid,t.begincell,cellzero,t.dcell,t.pos,t.velrhop,t.code,t.idp,viscdt,t.ar);
  }
}
//==============================================================================
template<TpKernel tker,TpFtMode ftmode,bool lamsps,TpDensity tdensity> void JSphCpu::Interaction_Forces_ct5(const stinterparmsc &t,float &viscdt)const{
  if(Shifting)Interaction_ForcesCpuT<tker,ftmode,lamsps,tdensity,true >(t,viscdt);
  else        Interaction_ForcesCpuT<tker,ftmode,lamsps,tdensity,false>(t,viscdt);
}
//==============================================================================
template<TpKernel tker,TpFtMode ftmode,bool lamsps> void JSphCpu::Interaction_Forces_ct4(const stinterparmsc &t,float &viscdt)const{
       if(TDensity==DDT_None)    Interaction_Forces_ct5<tker,ftmode,lamsps,DDT_None    >(t,viscdt);
  else if(TDensity==DDT_DDT)     Interaction_Forces_ct5<tker,ftmode,lamsps,DDT_DDT     >(t,viscdt);
}
//==============================================================================
template<TpKernel tker,TpFtMode ftmode> void JSphCpu::Interaction_Forces_ct3(const stinterparmsc &t,float &viscdt)const{
  if(TVisco==VISCO_LaminarSPS)Interaction_Forces_ct4<tker,ftmode,true >(t,viscdt);
  else                        Interaction_Forces_ct4<tker,ftmode,false>(t,viscdt);
}
//==============================================================================
template<TpKernel tker> void JSphCpu::Interaction_Forces_ct2(const stinterparmsc &t,float &viscdt)const{
       if(FtMode==FTMODE_None)Interaction_Forces_ct3<tker,FTMODE_None>(t,viscdt);
  else if(FtMode==FTMODE_Sph )Interaction_Forces_ct3<tker,FTMODE_Sph >(t,viscdt);
  else if(FtMode==FTMODE_Ext )Interaction_Forces_ct3<tker,FTMODE_Ext >(t,viscdt);
}
//==============================================================================
void JSphCpu::Interaction_Forces_ct(const stinterparmsc &t,float &viscdt)const{
       if(TKernel==KERNEL_Wendland)Interaction_Forces_ct2<KERNEL_Wendland>(t,viscdt);
  else if(TKernel==KERNEL_Gaussian)Interaction_Forces_ct2<KERNEL_Gaussian>(t,viscdt);
  else if(TKernel==KERNEL_Cubic)   Interaction_Forces_ct2<KERNEL_Cubic   >(t,viscdt);
}

//==============================================================================
/// Update pos, dcell and code to move with indicated displacement.
/// The value of outrhop indicates is it outside of the density limits.
/// Check the limits in funcion of MapRealPosMin & MapRealSize that this is valid
/// for single-cpu because DomRealPos & MapRealPos are equal. For multi-cpu it will be 
/// necessary to mark the particles that leave the domain without leaving the map.
///
//  with MPI need to be consider the particles leave the domain the map
//
/// Actualiza pos, dcell y code a partir del desplazamiento indicado.
/// El valor de outrhop indica si esta fuera de los limites de densidad.
/// Comprueba los limites en funcion de MapRealPosMin y MapRealSize esto es valido
/// para single-cpu pq DomRealPos y MapRealPos son iguales. Para multi-cpu seria 
/// necesario marcar las particulas q salgan del dominio sin salir del mapa.
//==============================================================================
void JSphCpu::UpdatePos(tdouble3 rpos,double movx,double movy,double movz
  ,bool outrhop,unsigned p,tdouble3 *pos,unsigned *cell,typecode *code)const
{
  //-Check validity of displacement. | Comprueba validez del desplazamiento.
  bool outmove=(fabs(float(movx))>MovLimit || fabs(float(movy))>MovLimit || fabs(float(movz))>MovLimit);
  /////displacement the new of particles//////////////////////////////////
  //-Applies dsiplacement. | Aplica desplazamiento.
  rpos.x+=movx; rpos.y+=movy; rpos.z+=movz;

  ///////////////check limits of new position
  if(Symmetry && rpos.y<0)rpos.y=-rpos.y; //<vs_syymmetry>
  //-Check limits of real domain. | Comprueba limites del dominio reales.
  double dx=rpos.x-MapRealPosMin.x;
  double dy=rpos.y-MapRealPosMin.y;
  double dz=rpos.z-MapRealPosMin.z;
  bool out=(dx!=dx || dy!=dy || dz!=dz || dx<0 || dy<0 || dz<0 || dx>=MapRealSize.x || dy>=MapRealSize.y || dz>=MapRealSize.z);
  //-Adjust position according to periodic conditions and compare domain limits. | Ajusta posicion segun condiciones periodicas y vuelve a comprobar los limites del dominio.
  // periodic onditions implements in 3D
  if(PeriActive && out){
    if(PeriX){
      if(dx<0)             { dx-=PeriXinc.x; dy-=PeriXinc.y; dz-=PeriXinc.z; }
      if(dx>=MapRealSize.x){ dx+=PeriXinc.x; dy+=PeriXinc.y; dz+=PeriXinc.z; }
    }
    if(PeriY){
      if(dy<0)             { dx-=PeriYinc.x; dy-=PeriYinc.y; dz-=PeriYinc.z; }
      if(dy>=MapRealSize.y){ dx+=PeriYinc.x; dy+=PeriYinc.y; dz+=PeriYinc.z; }
    }
    if(PeriZ){
      if(dz<0)             { dx-=PeriZinc.x; dy-=PeriZinc.y; dz-=PeriZinc.z; }
      if(dz>=MapRealSize.z){ dx+=PeriZinc.x; dy+=PeriZinc.y; dz+=PeriZinc.z; }
    }
    bool outx=!PeriX && (dx<0 || dx>=MapRealSize.x);
    bool outy=!PeriY && (dy<0 || dy>=MapRealSize.y);
    bool outz=!PeriZ && (dz<0 || dz>=MapRealSize.z);
    out=(outx||outy||outz);
    rpos=TDouble3(dx,dy,dz)+MapRealPosMin;
  }
  //calculate current position
  //-Keep current position. | Guarda posicion actualizada.
  pos[p]=rpos;//rpos is a particle,but *pos is array of prticles
  //-Keep cell and check. | Guarda celda y check.
  if(outrhop || outmove || out){//-Particle out.//this is check
    typecode rcode=code[p];
    if(out)rcode=CODE_SetOutPos(rcode);
    else if(outrhop)rcode=CODE_SetOutRhop(rcode);
    else rcode=CODE_SetOutMove(rcode);
    code[p]=rcode;
    cell[p]=0xFFFFFFFF;//if out and set cell is -1(0xffffffff)
/////////////////////correct instead of set to exceed particles
     //reset fluid particles
/*     if(p>=Npb && p<Np){
        pos[p] = TDouble3(template_posc.x,template_posc.y,template_posc.z);
        double redx=template_posc.x-MapRealPosMin.x;
        double redy=template_posc.y-MapRealPosMin.y;
        double redz=template_posc.z-MapRealPosMin.z;
        unsigned recx=unsigned(redx/Scell),recy=unsigned(redy/Scell),recz=unsigned(redz/Scell);

        cell[p]=PC__Cell(DomCellCode,recx,recy,recz);
        code[p]=0x1800;
	//because of speed is to big
	Velrhopc[p].x=0;
        Velrhopc[p].y=0;
        Velrhopc[p].z=0;
        Velrhopc[p].w=Velrhopc[Npb+3].w;

        VelrhopM1c[p].x=0;
        VelrhopM1c[p].y=0;
        VelrhopM1c[p].z=0;
        VelrhopM1c[p].w=VelrhopM1c[Npb+3].w;
//	printf("particlesId=%d was exceed boundary--, ",p);
      }*/
   //this is my test
   printf("*****in the pos update, particles %d is out\n",p);
   MPI_Abort(MPI_COMM_WORLD,68);
////////////////////////////
  }else{//-Particle in.
    if(PeriActive){
      dx=rpos.x-DomPosMin.x;
      dy=rpos.y-DomPosMin.y;
      dz=rpos.z-DomPosMin.z;
    }
////////////////////////////particles updating will linked cell updating
    unsigned cx=unsigned(dx/Scell),cy=unsigned(dy/Scell),cz=unsigned(dz/Scell);
    cell[p]=PC__Cell(DomCellCode,cx,cy,cz);// if not out and set cell is Pc__cell;
  }
////////////////////////////////////
//   unsigned cx=unsigned(dx/Scell),cy=unsigned(dy/Scell),cz=unsigned(dz/Scell);
//   cell[p]=PC__Cell(DomCellCode,cx,cy,cz);// if not out and set cell is Pc__cell;

///////////////////////////////////

}

//==============================================================================
/// Calculate new values of position, velocity & density for fluid (using Verlet).
/// Calcula nuevos valores de posicion, velocidad y densidad para el fluido (usando Verlet).
//==============================================================================
template<bool shift> void JSphCpu::ComputeVerletVarsFluid(//system update
  const tfloat4 *velrhop1,const tfloat4 *velrhop2,double dt,double dt2
  ,tdouble3 *pos,unsigned *dcell,typecode *code,tfloat4 *velrhopnew,double procboundary[],unsigned *idpc,std::vector<unsigned> *exceed_right_boundary
  ,std::vector<unsigned> *exceed_left_boundary,std::vector<unsigned>* local_particles)//const  //const not allow modify the member of elements such as Np,Npb
{
//////////////////////////////////////////////////////////////////////////////////////////////////
  printf("***********(rank_id=%d) the modlue is computeverletvarsfluild and processorboundary=[%lf,%lf]\n",mpi_rank_id,procboundary[0],procboundary[1]);
//  vector<unsigned> exceed_left_boundary;//when particles si exceed left/right boundary
//  vector<unsigned> exceed_right_boundary;
///////////////test in this point code and dcell size is 0
//  if(mpi_rank_id==0){
 /*
    int j=0;
    while(!dcell[Npb+j]){
	j++;
    }  
    int k=0;
    while(!code[Npb+k]){
	k++;
    }
    printf("BBBBBBBBBBBBBBBBBBBBBBBBBBBBB-----in rank %d, size of decell is %d, code is %d\n",mpi_rank_id,j,k);*/
// }
  //test ghost variable
  int coin;
//////////////////////////////////////////////////////////////////////////////////////////////////
  const double dt205=0.5*dt*dt;
  const tdouble3 gravity=ToTDouble3(Gravity);
  const int pini=int(Npb),pfin=int(Np),npf=int(Np-Npb);
/*
  #ifdef OMP_USE
    #pragma omp parallel for schedule (static) if(npf>OMP_LIMIT_COMPUTESTEP)
  #endif*/
  for(int p=pini;p<pfin;p++){//fixed boundary particle not moving
    //-Calculate density. | Calcula densidad.
    const float rhopnew=float(double(velrhop2[p].w)+dt2*Arc[p]);
    if(!WithFloating || CODE_IsFluid(code[p])){//-Fluid Particles.
//      printf("this is fluid particles updating\n");
      const tdouble3 acegr=ToTDouble3(Acec[p])+gravity; //-Adds gravity.
      // displacement updating by velrhop1 calculating in particles force_interactoin module  
      //-Calculate displacement and update position. | Calcula desplazamiento y actualiza posicion.
      double dx=double(velrhop1[p].x)*dt + acegr.x*dt205;
      double dy=double(velrhop1[p].y)*dt + acegr.y*dt205;
      double dz=double(velrhop1[p].z)*dt + acegr.z*dt205;
      if(shift){
        dx+=double(ShiftPosfsc[p].x);
        dy+=double(ShiftPosfsc[p].y);
        dz+=double(ShiftPosfsc[p].z);
      }
      bool outrhop=(rhopnew<RhopOutMin||rhopnew>RhopOutMax);
      //////////////////update the new position of particles////////////////////////////////////////
      UpdatePos(pos[p],dx,dy,dz,outrhop,p,pos,dcell,code);
      ////////////////////////////////-Update velocity & density. | eq()
      velrhopnew[p].x=float(double(velrhop2[p].x) + acegr.x*dt2);
      velrhopnew[p].y=float(double(velrhop2[p].y) + acegr.y*dt2);
      velrhopnew[p].z=float(double(velrhop2[p].z) + acegr.z*dt2);
      velrhopnew[p].w=rhopnew;

/////////////////////////////check the particles exceed processor boundary//////////////////////////
//      printf("***********(rank_id=%d) the modlue is computeverletvarsfluild and processorboundary=[%lf,%lf]\n",mpi_rank_id,procboundary[0],procboundary[1]);
      if(pos[p].y<procboundary[0]){//exceed for left boundary
	     
             exceed_left_boundary->push_back(p);
	     if(mpi_rank_id==mpi_start_rank_id){
	     	local_particles->push_back(p);	
	     }
      }else if(pos[p].y>procboundary[1]){//exceed for right boundary

	     exceed_right_boundary->push_back(p);
	     if(mpi_rank_id==mpi_end_rank_id){
	     	local_particles->push_back(p);
	     }
      }else{//local particles for central part

	     local_particles->push_back(p);
      }
	//nothing to do
//      coin=pow(-1,p);
/////////////////////////////tranfer the exceed particles by mpi////////////////////////////////////
    }else{//-Floating Particles.
      printf("this is floating particles updating\n");
      velrhopnew[p]=velrhop1[p];
      velrhopnew[p].w=(rhopnew<RhopZero? RhopZero: rhopnew); //-Avoid fluid particles being absorved by floating ones. | Evita q las floating absorvan a las fluidas.
    }//there are two type of particles needed to moving 1.fluid and 2 floating particles
  }//end of update particles
///////////////////////////clear
/*
  printf("rank %d----in this step: there hava %d particles exceeding left boundary, and %d particles exceeding right boundary\n",
  mpi_rank_id,exceed_left_boundary->size(),exceed_right_boundary->size());
  for(int j=0;j<exceed_left_boundary->size();j++){
//      printf("left id:%d, ",exceed_left_boundary[j]);
  }
  printf("\n");
//  printf("rank %d----in this step: there hava %d particles exceeding rigth boundary\n",mpi_rank_id,exceed_right_boundary.size());
  for(int j=0;j<exceed_left_boundary->size();j++){
//      printf("right id:%d, ",exceed_right_boundary[j]);
  }
*/
  //simulate the ghost coming and out
//  printf("-------------->coin =%d\n",coin*5);
//  srand(time(NULL));
//  int time_seed=rand()%10;
//  coin=pow(-1,time_seed); 
//  printf("-------------->coin =%d\n",coin*5);
/*    int j=0;
    while(!dcell[Npb+j]||dcell[Npb+j]!=NULL){
        j++;
    }
//////////test
    int k=0;
    while(!code[Npb+k]||code[Npb+k]!=NULL){
	k++;
    }
    printf("CCCCCCCCCCCCCCCCCCCCCCCCCCCCCC-----in rank %d, size of decell is %d, code is %d\n",mpi_rank_id,j,k);
*/
//add one elements
/*
  pos[Np].x=pos[pini+30].x; 
  pos[Np].y=pos[pini+30].y;   
  pos[Np].z=pos[pini+30].z;

  velrhopnew[Np].x=velrhopnew[pini+30].x;
  velrhopnew[Np].y=velrhopnew[pini+30].y;
  velrhopnew[Np].z=velrhopnew[pini+30].z;
  velrhopnew[Np].w=velrhopnew[pini+30].w;
  
//  code[pfin]=code[pfin-40];
  idpc[Np]=idpc[pini+30];
//  code[Np]=code[Npb+5];
  Np=Np+1;*/
//  if(mpi_rank_id==0)cout<<"----------------------in add one elements rank_id=0 Np="<<Np<<endl;
//  exceed_left_boundary.clear();
//  exceed_right_boundary.clear();
////////////////////////////////////////////////////////////////////////////////////////////////////
}

//==============================================================================
/// Calculate new values of density and set velocity=zero for cases of  
/// (fixed+moving, no floating).
///
/// Calcula nuevos valores de densidad y pone velocidad a cero para el contorno 
/// (fixed+moving, no floating).
//==============================================================================
void JSphCpu::ComputeVelrhopBound(const tfloat4* velrhopold,double armul,tfloat4* velrhopnew)const{
  const int npb=int(Npb);
  #ifdef OMP_USE
    #pragma omp parallel for schedule (static) if(npb>OMP_LIMIT_COMPUTESTEP)
  #endif
  for(int p=0;p<npb;p++){
    const float rhopnew=float(double(velrhopold[p].w)+armul*Arc[p]);
    velrhopnew[p]=TFloat4(0,0,0,(rhopnew<RhopZero? RhopZero: rhopnew));//-Avoid fluid particles being absorved by boundary ones. | Evita q las boundary absorvan a las fluidas.
  }
}

//==============================================================================
/// Update of particles according to forces and dt using Verlet.
/// Actualizacion de particulas segun fuerzas y dt usando Verlet.
//==============================================================================
void JSphCpu::ComputeVerlet(double dt, double procboundary[]){
  TmcStart(Timers,TMC_SuComputeStep);
  VerletStep++;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  if(mpi_rank_id==0)printf("before--(>_<)--rank 0,add one**********~(^_^)~************Np=%d\n",Np);
//  printf("===============================================================================================================verletsteps=%d\n",VerletSteps);
  //clear the vector
  local_particles_central.clear();
  ghost_coming_from_right.clear();
  ghost_coming_from_left.clear();
  ghost_going_to_right.clear();
  ghost_going_to_left.clear();
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if(VerletStep<VerletSteps){//see the equation (21) to stop divergence of integrated values through time as the equations are no longer coupled( Ns=50  approximately equal to 50 need to reset)
    const double twodt=dt+dt;//2dt
    if(Shifting)ComputeVerletVarsFluid<true>  (Velrhopc,VelrhopM1c,dt,twodt,Posc,Dcellc,Codec,VelrhopM1c,procboundary,Idpc,&ghost_going_to_right,&ghost_going_to_left,&local_particles_central);//fuild
    else        ComputeVerletVarsFluid<false> (Velrhopc,VelrhopM1c,dt,twodt,Posc,Dcellc,Codec,VelrhopM1c,procboundary,Idpc,&ghost_going_to_right,&ghost_going_to_left,&local_particles_central);//fuild
    ComputeVelrhopBound(VelrhopM1c,twodt,VelrhopM1c);  //for boundary
  }
  else{//Posc have been modify
    if(Shifting)ComputeVerletVarsFluid<true>  (Velrhopc,Velrhopc,dt,dt,Posc,Dcellc,Codec,VelrhopM1c,procboundary,Idpc,&ghost_going_to_right,&ghost_going_to_left,&local_particles_central);//for fuild
    else        ComputeVerletVarsFluid<false> (Velrhopc,Velrhopc,dt,dt,Posc,Dcellc,Codec,VelrhopM1c,procboundary,Idpc,&ghost_going_to_right,&ghost_going_to_left,&local_particles_central);//for fuild
    ComputeVelrhopBound(Velrhopc,dt,VelrhopM1c);  //for boundary
    VerletStep=0;
  }
  //VelrhopM1c equal to velrhonew, swap is memory copy function
  //-New values are calculated en VelrhopM1c. | Los nuevos valores se calculan en VelrhopM1c.
  swap(Velrhopc,VelrhopM1c);     //-Swap Velrhopc & VelrhopM1c. | Intercambia Velrhopc y VelrhopM1c.
  TmcStop(Timers,TMC_SuComputeStep);
  //test, we can know don't equal to each oter
/*
  for(unsigned i=Npb;i<Np;i++){
  	printf("Velrhop/M1c[%d]=[(%lf,%lf),(%lf,%lf),(%lf,%lf),(%lf,%lf)]- ",i,Velrhopc[i].x,VelrhopM1c[i].x,Velrhopc[i].y,VelrhopM1c[i].y,Velrhopc[i].z,VelrhopM1c[i].z,Velrhopc[i].w,VelrhopM1c[i].w);
	if(Velrhopc[i].x!=VelrhopM1c[i].x||Velrhopc[i].y!=VelrhopM1c[i].y||Velrhopc[i].z!=VelrhopM1c[i].z||Velrhopc[i].w!=VelrhopM1c[i].w){
      	//	printf("there are have velrhop not equal to M1c-....numer=%d......\n",i);
	//	MPI_Abort(MPI_COMM_WORLD,50);
	}
  }*/
//////////////exchange the boundary particles because of exceeding processor
  printf("*******************rank id=%d, rank left=%d, rank right=%d\n",mpi_rank_id,left,right);
  num_going_left =ghost_going_to_left.size();
  num_going_right=ghost_going_to_right.size(); 
  //consideratoin of start and end of processor
  num_local_particles = local_particles_central.size();
/*  if(mpi_rank_id==mpi_start_rank_id){
	num_local_particles = local_particles_central.size()+num_going_left;
  }else if(mpi_rank_id==mpi_end_rank_id){
	num_local_particles = local_particles_central.size()+num_going_right;
  }else{ 
  	num_local_particles = local_particles_central.size();  
  }
*/
  if(mpi_rank_id==mpi_start_rank_id){
      printf("start processor--left:%d(ignore) right:%d+local(include  left):%d=%d---equal to--- Npf=%d?\n",num_going_left,num_going_right,num_local_particles,
      num_going_right+num_local_particles,Np-Npb);
  }else if(mpi_rank_id==mpi_end_rank_id){
      printf("end processor---right:%d(ignore)  left:%d+local(include right):%d=%d---equal to--- Npf=%d?\n",num_going_right,num_going_left,num_local_particles,
      num_going_left+num_local_particles,Np);
  }else{
      printf("processor id=%d---left:%d+right:%d+local:%d=%d---equal to--- Npf=%d?\n",mpi_rank_id,num_going_left,num_going_right,num_local_particles,
      num_going_left+num_going_right+num_local_particles,Np);
  } //initial coming particles
  num_coming_left=num_coming_right=0; 
  //get the number of coming particles
  //get the number of left dir coming
/*
  if(mpi_rank_id==mpi_start_rank_id){//for left boundary processor  rank_id =0;
		
  }else{

  }*/
  MPI_Status status1,status2;
  //for left -> right, and get the number of left coming particles 
  MPI_Sendrecv(&num_going_right,1,MPI_UNSIGNED,right,99,&num_coming_left,1,MPI_UNSIGNED,left,99,MPI_COMM_WORLD,&status1);
  printf("***************this is rank_id=%d, there are left coming particles is %d from left rank_id=%d\n",mpi_rank_id,num_coming_left,left);  

  //for right -> left, and get the number of right coming particles
  MPI_Sendrecv(&num_going_left,1,MPI_UNSIGNED,left,101,&num_coming_right,1,MPI_UNSIGNED,right,101,MPI_COMM_WORLD,&status2); 
  printf("---------------this is rank_id=%d, there are right coming particle is %d from right rank_id=%d\n",mpi_rank_id,num_coming_right,right);  

  //check the max particles less than Np_max
  unsigned next_num_particles=0;
  if(mpi_rank_id==mpi_start_rank_id){//for start of processor rank 0
      next_num_particles= Np+num_coming_right-num_going_right;
      if(next_num_particles>Np_max){//for rank 0
          printf("ERROR: in rank_id=%d,the particles is exceed the maxmum particle Np_max\n",mpi_rank_id);
	  MPI_Abort(MPI_COMM_WORLD,90);

      }else{
	  printf("the number of ghost+local (%d) particles are kept within a reasonable range(less than Np_max(%d)).\n",next_num_particles,Np_max);
      }
  }else if(mpi_rank_id==mpi_end_rank_id){//for end of processor
      next_num_particles= Np+num_coming_left-num_going_left;
      if(next_num_particles>Np_max){//for rank end
          printf("ERROR: in rank_id=%d,the particles is exceed the maxmum particle Np_max\n",mpi_rank_id);
          MPI_Abort(MPI_COMM_WORLD,91);
	
      }else{
	  printf("the number of ghost+local (%d) particles are kept within a reasonable range(less than Np_max(%d)).\n",next_num_particles,Np_max);
      }
  }else{//for others processor
      next_num_particles= Np+num_coming_left+num_coming_right-num_going_left-num_going_right;
      if(next_num_particles>Np_max){
          printf("ERROR: in rank_id=%d,the particles is exceed the maxmum particle Np_max\n",mpi_rank_id);
          MPI_Abort(MPI_COMM_WORLD,92);	

      }else{
	  printf("the number of ghost+local (%d) particles are kept within a reasonable range(less than Np_max(%d)).\n",next_num_particles,Np_max);
      }
  }
/*
  //all
  MPI_Status status[12];
  MPI_Request request[12];

  //left---to----right----------------------------------
//  MPI_Status status0; 
//  MPI_Request request0;
  int tags0;//posc and idpc
  //pack/unpacke
  int position;
  char buff[1000000];
  int buff_length=1000000;//buff_length >> all newtype length

  //velrhop
  int tags01;
  int position01;
  char buff01[1000000];
  int buff_length01=1000000; 

  //velrhopM1c
  int tags02;
  int position02;
  char buff02[1000000];
  int buff_length02=1000000;

  //-**right----to-----left-----------------------------
//  MPI_Status status11; 
//  MPI_Request request11;
  int tags11;
  //pack/unpacke
  int position11;
  char buff11[1000000];
  int buff_length11=1000000;//buff_length >> all newtype length

  //velrhop
  int tags12;
  int position12;
  char buff12[1000000];
  int buff_length12=1000000;
  
  //velrhopM1c
  int tags13;
  int position13;
  char buff13[1000000];
  int buff_length13=1000000;
*/
  //left---to--->right----------------------------------
  //Posc x
  double *send_right_xx = new double[num_going_right]();  //to right processor
  double *recv_left_xx  = new double[num_coming_left]();  //source data from left processor
  //Posc y
  double *send_right_yy = new double[num_going_right]();  //to right processor
  double *recv_left_yy  = new double[num_coming_left]();  //source data from left processor
  //Posc z
  double *send_right_zz = new double[num_going_right]();  //to right processor
  double *recv_left_zz  = new double[num_coming_left]();  //source data from left processor

  //Velrhopc
  //velrhopc x
  float *send_right_vx = new float[num_going_right](); 
  float *recv_left_vx  = new float[num_coming_left]();
  //Velrhopc y
  float *send_right_vy = new float[num_going_right]();
  float *recv_left_vy  = new float[num_coming_left]();
  //velrhopc z
  float *send_right_vz = new float[num_going_right]();
  float *recv_left_vz  = new float[num_coming_left]();
  //velrhopc w
  float *send_right_vr = new float[num_going_right]();
  float *recv_left_vr  = new float[num_coming_left]();

  //VelrhopM1c
  //velrhopcm1c x
  float *send_right_mx = new float[num_going_right]();
  float *recv_left_mx  = new float[num_coming_left]();
  //velrhopcm1c y
  float *send_right_my = new float[num_going_right]();
  float *recv_left_my  = new float[num_coming_left]();
  //velrhopcm1c z
  float *send_right_mz = new float[num_going_right]();
  float *recv_left_mz  = new float[num_coming_left]();
  //velrhopcm1c w
  float *send_right_mr = new float[num_going_right]();
  float *recv_left_mr  = new float[num_coming_left]();
 
  //Idpc
  unsigned *send_right_id=new unsigned[num_going_right](); 
  unsigned *recv_left_id= new unsigned[num_coming_left]();
  //test decll
  unsigned *send_right_cell=new unsigned[num_going_right]();
  unsigned *send_left_cell =new unsigned[num_going_left]();
  //-**right---to-----left------------------------------
  //Posc x
  double *send_left_xx  = new double[num_going_left]();  //to left processor
  double *recv_right_xx = new double[num_coming_right]();  //source data from right processor
  //Posc y
  double *send_left_yy  = new double[num_going_left]();  //to left processor
  double *recv_right_yy = new double[num_coming_right]();  //source data from right processor
  //Posc z
  double *send_left_zz  = new double[num_going_left]();  //to left processor
  double *recv_right_zz = new double[num_coming_right]();  //source data from right processor

  //Velrhopc
  //velrhopc x
  float *send_left_vx  = new float[num_going_left](); 
  float *recv_right_vx = new float[num_coming_right]();
  //Velrhopc y
  float *send_left_vy  = new float[num_going_left]();
  float *recv_right_vy = new float[num_coming_right]();
  //velrhopc z
  float *send_left_vz  = new float[num_going_left]();
  float *recv_right_vz = new float[num_coming_right]();
  //velrhopc w
  float *send_left_vr  = new float[num_going_left]();
  float *recv_right_vr = new float[num_coming_right]();

  //VelrhopM1c
  //velrhopcm1c x
  float *send_left_mx  = new float[num_going_left]();
  float *recv_right_mx = new float[num_coming_right]();
  //velrhopcm1c y
  float *send_left_my  = new float[num_going_left]();
  float *recv_right_my = new float[num_coming_right]();
  //velrhopcm1c z
  float *send_left_mz  = new float[num_going_left]();
  float *recv_right_mz = new float[num_coming_right]();
  //velrhopcm1c w
  float *send_left_mr  = new float[num_going_left]();
  float *recv_right_mr = new float[num_coming_right]();
 
  //Idpc
  unsigned *send_left_id= new unsigned[num_going_left](); 
  unsigned *recv_right_id=new unsigned[num_coming_right]();


  //get the data needed to send to right
  unsigned p0;
  #ifdef OMP_USE
      #pragma omp parallel for schedule (static)
  #endif
  for(unsigned i=0;i<num_going_right;i++){
        p0 = ghost_going_to_right[i];
	//poscx
        send_right_xx[i] = Posc[p0].x;
        //poscy
        send_right_yy[i] = Posc[p0].y;
        //poscz
        send_right_zz[i] = Posc[p0].z;
	//Idpc
	send_right_id[i] = Idpc[p0];
	
	//velrhopc x
	send_right_vx[i] = Velrhopc[p0].x;
	//velrhopc y
	send_right_vy[i] = Velrhopc[p0].y;
	//velrhopc z
	send_right_vz[i] = Velrhopc[p0].z;
	//velrhopc w
	send_right_vr[i] = Velrhopc[p0].w;

	//velrhopM1c x
	send_right_mx[i] = VelrhopM1c[p0].x;
	//velrhopM1c y
	send_right_my[i] = VelrhopM1c[p0].y;
	//velrhopM1c z
	send_right_mz[i] = VelrhopM1c[p0].z;
	//velrhopM1c w
	send_right_mr[i] = VelrhopM1c[p0].w;
	//cell
	send_right_cell[i] = Dcellc[p0];
  }    
 
  //-**get the data needed to send to left
  unsigned p11;
  #ifdef OMP_USE
      #pragma omp parallel for schedule (static)
  #endif
  for(unsigned i=0;i<num_going_left;i++){
        p11 = ghost_going_to_left[i];
	//poscx
        send_left_xx[i] = Posc[p11].x;
        //poscy
        send_left_yy[i] = Posc[p11].y;
        //poscz
        send_left_zz[i] = Posc[p11].z;
	//Idpc
	send_left_id[i] = Idpc[p11];
 	
	//velrhopc x
        send_left_vx[i] = Velrhopc[p11].x;
        //velrhopc y
        send_left_vy[i] = Velrhopc[p11].y;
        //velrhopc z
        send_left_vz[i] = Velrhopc[p11].z;
	//velrhopc w
	send_left_vr[i] = Velrhopc[p11].w;
	
	//VelrhopM1c x
        send_left_mx[i] = VelrhopM1c[p11].x;
        //VelrhopM1c y
        send_left_my[i] = VelrhopM1c[p11].y;
        //VelrhopM1c z
        send_left_mz[i] = VelrhopM1c[p11].z;
	//VelrhopM1c w
	send_left_mr[i] = VelrhopM1c[p11].w;
	//cell
	send_left_cell[i] = Dcellc[p11];
  }     
 
  //left-----to-----right-------------------------
  //for Posc and Idpc 
  //start pack
/*
  int len[4]; 
  MPI_Aint disp[4];
  MPI_Datatype type[4],new_type;
  //set the length for new type
  len[0] = num_going_right;
  len[1] = num_going_right;
  len[2] = num_going_right;
  len[3] = num_going_right;
  //calculate bias for MPI_BOTTOM
  MPI_Address(send_right_xx, disp);
  MPI_Address(send_right_yy, disp+1);
  MPI_Address(send_right_zz, disp+2);
  MPI_Address(send_right_id, disp+3);
  //set the original data type
  type[0] = MPI_DOUBLE;
  type[1] = MPI_DOUBLE;
  type[2] = MPI_DOUBLE;
  type[3] = MPI_UNSIGNED;
  //definition new data type
  MPI_Type_struct(4,len,disp,type,&new_type);
  //submit new datatype
  MPI_Type_commit(&new_type);
  //set the start position for pack
  position = 0;
  //start packing
  MPI_Pack(MPI_BOTTOM,1,new_type,buff,buff_length,&position,MPI_COMM_WORLD);

  //for Velrhopc
  //start pack
  int len01[4]; 
  MPI_Aint disp01[4];
  MPI_Datatype type01[4],new_type01;
  //set the length for new type
  len01[0] = num_going_right;
  len01[1] = num_going_right;
  len01[2] = num_going_right;
  len01[3] = num_going_right;
  //calculate bias for MPI_BOTTOM
  MPI_Address(send_right_vx, disp01);
  MPI_Address(send_right_vy, disp01+1);
  MPI_Address(send_right_vz, disp01+2);
  MPI_Address(send_right_vr, disp01+3);
  //set the original data type
  type01[0] = MPI_FLOAT;
  type01[1] = MPI_FLOAT;
  type01[2] = MPI_FLOAT;
  type01[3] = MPI_FLOAT;
  //definition new data type
  MPI_Type_struct(4,len01,disp01,type01,&new_type01);
  //submit new datatype
  MPI_Type_commit(&new_type01);
  //set the start position for pack
  position01 = 0;
  //start packing
  MPI_Pack(MPI_BOTTOM,1,new_type01,buff01,buff_length01,&position01,MPI_COMM_WORLD);

  //for VelrhopM1c
  //start pack
  int len02[4]; 
  MPI_Aint disp02[4];
  MPI_Datatype type02[4],new_type02;
  //set the length for new type
  len02[0] = num_going_right;
  len02[1] = num_going_right;
  len02[2] = num_going_right;
  len02[3] = num_going_right;
  //calculate bias for MPI_BOTTOM
  MPI_Address(send_right_mx, disp02);
  MPI_Address(send_right_my, disp02+1);
  MPI_Address(send_right_mz, disp02+2);
  MPI_Address(send_right_mr, disp02+3);
  //set the original data type
  type02[0] = MPI_FLOAT;
  type02[1] = MPI_FLOAT;
  type02[2] = MPI_FLOAT;
  type02[3] = MPI_FLOAT;
  //definition new data type
  MPI_Type_struct(4,len02,disp02,type02,&new_type02);
  //submit new datatype
  MPI_Type_commit(&new_type02);
  //set the start position for pack
  position02 = 0;
  //start packing
  MPI_Pack(MPI_BOTTOM,1,new_type02,buff02,buff_length02,&position02,MPI_COMM_WORLD);


  //-**right-----to-----left
  //start pack
  int len11[4]; 
  MPI_Aint disp11[4];
  MPI_Datatype type11[4],new_type11;
  //set the length for new type
  len11[0] = num_going_left;
  len11[1] = num_going_left;
  len11[2] = num_going_left;
  len11[3] = num_going_left;
  //calculate bias for MPI_BOTTOM
  MPI_Address(send_left_xx, disp11);
  MPI_Address(send_left_yy, disp11+1);
  MPI_Address(send_left_zz, disp11+2);
  MPI_Address(send_left_id, disp11+3);
  //set the original data type
  type11[0] = MPI_DOUBLE;
  type11[1] = MPI_DOUBLE;
  type11[2] = MPI_DOUBLE;
  type11[3] = MPI_UNSIGNED;
  //definition new data type
  MPI_Type_struct(4,len11,disp11,type11,&new_type11);
  //submit new datatype
  MPI_Type_commit(&new_type11);
  //set the start position for pack
  position11 = 0;
  //start packing
  MPI_Pack(MPI_BOTTOM,1,new_type11,buff11,buff_length11,&position11,MPI_COMM_WORLD);
 
  //velrhopc
  //start pack
  int len12[4]; 
  MPI_Aint disp12[4];
  MPI_Datatype type12[4],new_type12;
  //set the length for new type
  len12[0] = num_going_left;
  len12[1] = num_going_left;
  len12[2] = num_going_left;
  len12[3] = num_going_left;
  //calculate bias for MPI_BOTTOM
  MPI_Address(send_left_vx, disp12);
  MPI_Address(send_left_vy, disp12+1);
  MPI_Address(send_left_vz, disp12+2);
  MPI_Address(send_left_vr, disp12+3);
  //set the original data type
  type12[0] = MPI_FLOAT;
  type12[1] = MPI_FLOAT;
  type12[2] = MPI_FLOAT;
  type12[3] = MPI_FLOAT;
  //definition new data type
  MPI_Type_struct(4,len12,disp12,type12,&new_type12);
  //submit new datatype
  MPI_Type_commit(&new_type12);
  //set the start position for pack
  position12 = 0;
  //start packing
  MPI_Pack(MPI_BOTTOM,1,new_type12,buff12,buff_length12,&position12,MPI_COMM_WORLD);

  //velrhopM1c
  //start pack
  int len13[4]; 
  MPI_Aint disp13[4];
  MPI_Datatype type13[4],new_type13;
  //set the length for new type
  len13[0] = num_going_left;
  len13[1] = num_going_left;
  len13[2] = num_going_left;
  len13[3] = num_going_left;
  //calculate bias for MPI_BOTTOM
  MPI_Address(send_left_mx, disp13);
  MPI_Address(send_left_my, disp13+1);
  MPI_Address(send_left_mz, disp13+2);
  MPI_Address(send_left_mr, disp13+3);
  //set the original data type
  type13[0] = MPI_FLOAT;
  type13[1] = MPI_FLOAT;
  type13[2] = MPI_FLOAT;
  type13[3] = MPI_FLOAT;
  //definition new data type
  MPI_Type_struct(4,len13,disp13,type13,&new_type13);
  //submit new datatype
  MPI_Type_commit(&new_type13);
  //set the start position for pack
  position13 = 0;
  //start packing
  MPI_Pack(MPI_BOTTOM,1,new_type13,buff13,buff_length13,&position13,MPI_COMM_WORLD);


  //=================================Isend/Irecv=======================================//
  //send data from  left---to---right
  MPI_Isend(buff,position,MPI_PACKED,right,tags0,MPI_COMM_WORLD,&request[0]);
  MPI_Isend(buff01,position01,MPI_PACKED,right,tags01,MPI_COMM_WORLD,&request[1]);
  MPI_Isend(buff02,position02,MPI_PACKED,right,tags02,MPI_COMM_WORLD,&request[2]);
  //-**send Packed data from right----to----left
  MPI_Isend(buff11,position11,MPI_PACKED,left,tags11,MPI_COMM_WORLD,&request[3]);
  MPI_Isend(buff12,position12,MPI_PACKED,left,tags12,MPI_COMM_WORLD,&request[4]);
  MPI_Isend(buff13,position13,MPI_PACKED,left,tags13,MPI_COMM_WORLD,&request[5]);

  //receive data from right---to----left
  MPI_Irecv(buff,buff_length,MPI_PACKED,left,tags0,MPI_COMM_WORLD,&request[6]);
  MPI_Irecv(buff01,buff_length01,MPI_PACKED,left,tags01,MPI_COMM_WORLD,&request[7]);
  MPI_Irecv(buff02,buff_length02,MPI_PACKED,left,tags02,MPI_COMM_WORLD,&request[8]);
  //-**receive Packed dada from left---to---right
  MPI_Irecv(buff11,buff_length11,MPI_PACKED,right,tags11,MPI_COMM_WORLD,&request[9]);
  MPI_Irecv(buff12,buff_length12,MPI_PACKED,right,tags12,MPI_COMM_WORLD,&request[10]);
  MPI_Irecv(buff13,buff_length13,MPI_PACKED,right,tags13,MPI_COMM_WORLD,&request[11]);
 */
  MPI_Status statu[48];
  MPI_Request request_test[48];
  //send ----------right------to----left
  MPI_Isend(send_right_xx,num_going_right,MPI_DOUBLE,right,560,MPI_COMM_WORLD,&request_test[0]);
  MPI_Isend(send_right_yy,num_going_right,MPI_DOUBLE,right,561,MPI_COMM_WORLD,&request_test[1]);
  MPI_Isend(send_right_zz,num_going_right,MPI_DOUBLE,right,562,MPI_COMM_WORLD,&request_test[2]);
  MPI_Isend(send_right_id,num_going_right,MPI_UNSIGNED,right,563,MPI_COMM_WORLD,&request_test[3]);
 
  MPI_Isend(send_right_vx,num_going_right,MPI_FLOAT,right,564,MPI_COMM_WORLD,&request_test[4]);
  MPI_Isend(send_right_vy,num_going_right,MPI_FLOAT,right,565,MPI_COMM_WORLD,&request_test[5]);
  MPI_Isend(send_right_vz,num_going_right,MPI_FLOAT,right,566,MPI_COMM_WORLD,&request_test[6]);
  MPI_Isend(send_right_vr,num_going_right,MPI_FLOAT,right,567,MPI_COMM_WORLD,&request_test[7]);

  MPI_Isend(send_right_mx,num_going_right,MPI_FLOAT,right,568,MPI_COMM_WORLD,&request_test[8]);
  MPI_Isend(send_right_my,num_going_right,MPI_FLOAT,right,569,MPI_COMM_WORLD,&request_test[9]);
  MPI_Isend(send_right_mz,num_going_right,MPI_FLOAT,right,570,MPI_COMM_WORLD,&request_test[10]);
  MPI_Isend(send_right_mr,num_going_right,MPI_FLOAT,right,571,MPI_COMM_WORLD,&request_test[11]);

  //send --------left--------to------right
  MPI_Isend(send_left_xx,num_going_left,MPI_DOUBLE,left,572,MPI_COMM_WORLD,&request_test[12]);
  MPI_Isend(send_left_yy,num_going_left,MPI_DOUBLE,left,573,MPI_COMM_WORLD,&request_test[13]);
  MPI_Isend(send_left_zz,num_going_left,MPI_DOUBLE,left,574,MPI_COMM_WORLD,&request_test[14]);
  MPI_Isend(send_left_id,num_going_left,MPI_UNSIGNED,left,575,MPI_COMM_WORLD,&request_test[15]);

  MPI_Isend(send_left_vx,num_going_left,MPI_FLOAT,left,576,MPI_COMM_WORLD,&request_test[16]);
  MPI_Isend(send_left_vy,num_going_left,MPI_FLOAT,left,577,MPI_COMM_WORLD,&request_test[17]);
  MPI_Isend(send_left_vz,num_going_left,MPI_FLOAT,left,578,MPI_COMM_WORLD,&request_test[18]);
  MPI_Isend(send_left_vr,num_going_left,MPI_FLOAT,left,579,MPI_COMM_WORLD,&request_test[19]);

  MPI_Isend(send_left_mx,num_going_left,MPI_FLOAT,left,580,MPI_COMM_WORLD,&request_test[20]);
  MPI_Isend(send_left_my,num_going_left,MPI_FLOAT,left,581,MPI_COMM_WORLD,&request_test[21]);
  MPI_Isend(send_left_mz,num_going_left,MPI_FLOAT,left,582,MPI_COMM_WORLD,&request_test[22]);
  MPI_Isend(send_left_mr,num_going_left,MPI_FLOAT,left,583,MPI_COMM_WORLD,&request_test[23]);

  //Irecv---------to-----right
  MPI_Irecv(recv_left_xx,num_coming_left,MPI_DOUBLE,left,560,MPI_COMM_WORLD,&request_test[24]);
  MPI_Irecv(recv_left_yy,num_coming_left,MPI_DOUBLE,left,561,MPI_COMM_WORLD,&request_test[25]);
  MPI_Irecv(recv_left_zz,num_coming_left,MPI_DOUBLE,left,562,MPI_COMM_WORLD,&request_test[26]);
  MPI_Irecv(recv_left_id,num_coming_left,MPI_UNSIGNED,left,563,MPI_COMM_WORLD,&request_test[27]);
 
  MPI_Irecv(recv_left_vx,num_coming_left,MPI_FLOAT,left,564,MPI_COMM_WORLD,&request_test[28]);
  MPI_Irecv(recv_left_vy,num_coming_left,MPI_FLOAT,left,565,MPI_COMM_WORLD,&request_test[29]);
  MPI_Irecv(recv_left_vz,num_coming_left,MPI_FLOAT,left,566,MPI_COMM_WORLD,&request_test[30]);
  MPI_Irecv(recv_left_vr,num_coming_left,MPI_FLOAT,left,567,MPI_COMM_WORLD,&request_test[31]);

  MPI_Irecv(recv_left_mx,num_coming_left,MPI_FLOAT,left,568,MPI_COMM_WORLD,&request_test[32]);
  MPI_Irecv(recv_left_my,num_coming_left,MPI_FLOAT,left,569,MPI_COMM_WORLD,&request_test[33]);
  MPI_Irecv(recv_left_mz,num_coming_left,MPI_FLOAT,left,570,MPI_COMM_WORLD,&request_test[34]);
  MPI_Irecv(recv_left_mr,num_coming_left,MPI_FLOAT,left,571,MPI_COMM_WORLD,&request_test[35]);

  //send --------left--------to------right
  MPI_Irecv(recv_right_xx,num_coming_right,MPI_DOUBLE,right,572,MPI_COMM_WORLD,&request_test[36]);
  MPI_Irecv(recv_right_yy,num_coming_right,MPI_DOUBLE,right,573,MPI_COMM_WORLD,&request_test[37]);
  MPI_Irecv(recv_right_zz,num_coming_right,MPI_DOUBLE,right,574,MPI_COMM_WORLD,&request_test[38]);
  MPI_Irecv(recv_right_id,num_coming_right,MPI_UNSIGNED,right,575,MPI_COMM_WORLD,&request_test[39]);

  MPI_Irecv(recv_right_vx,num_coming_right,MPI_FLOAT,right,576,MPI_COMM_WORLD,&request_test[40]);
  MPI_Irecv(recv_right_vy,num_coming_right,MPI_FLOAT,right,577,MPI_COMM_WORLD,&request_test[41]);
  MPI_Irecv(recv_right_vz,num_coming_right,MPI_FLOAT,right,578,MPI_COMM_WORLD,&request_test[42]);
  MPI_Irecv(send_right_vr,num_coming_right,MPI_FLOAT,right,579,MPI_COMM_WORLD,&request_test[43]);

  MPI_Irecv(recv_right_mx,num_coming_right,MPI_FLOAT,right,580,MPI_COMM_WORLD,&request_test[44]);
  MPI_Irecv(recv_right_my,num_coming_right,MPI_FLOAT,right,581,MPI_COMM_WORLD,&request_test[45]);
  MPI_Irecv(recv_right_mz,num_coming_right,MPI_FLOAT,right,582,MPI_COMM_WORLD,&request_test[46]);
  MPI_Irecv(recv_right_mr,num_coming_right,MPI_FLOAT,right,583,MPI_COMM_WORLD,&request_test[47]);

 
 
  //----x------x-----x-----x-------x-------x-------x------x------x------x------x-------//
  //=================================do ther things====================================//
  printf("rank_id=%d, do other things\n",mpi_rank_id);
  //resort data
  //get the mask for resort
  //index:ghost_going_to_left,ghost_going_to_right,ghost_particles_central
  //---------coming from left:  num_coming_left
  //---------coming from right: num_coming_right
  //.........going  to   left:  num_going_left
  //.........going  to   right: num_going_right
  //resort Posc
  tdouble3 *temp_local_posc;
  temp_local_posc = (tdouble3*)malloc(sizeof(tdouble3)*num_local_particles);
  /*
  double *temp_local_poscX,*temp_local_poscY,*temp_local_poscZ;
  temp_local_poscX = (double*)malloc(sizeof(double)*num_local_particles);
  temp_local_poscY = (double*)malloc(sizeof(double)*num_local_particles);
  temp_local_poscZ = (double*)malloc(sizeof(double)*num_local_particles);*/
  //resort Velrhopc
  tfloat4 *temp_local_velrhopc;
  temp_local_velrhopc = (tfloat4*)malloc(sizeof(tfloat4)*num_local_particles);
  /*
  float *temp_local_velrhopcX,*temp_local_velrhopcY;
  float *temp_local_velrhopcZ,*temp_local_velrhopcW;
  temp_local_velrhopcX = (float*)malloc(sizeof(float)*num_local_particles);
  temp_local_velrhopcY = (float*)malloc(sizeof(float)*num_local_particles);
  temp_local_velrhopcZ = (float*)malloc(sizeof(float)*num_local_particles);
  temp_local_velrhopcW = (float*)malloc(sizeof(float)*num_local_particles);*/
  //resort VelrhopM1c
  tfloat4 *temp_local_velrhopM1c;
  temp_local_velrhopM1c = (tfloat4*)malloc(sizeof(tfloat4)*num_local_particles);
  /*
  float *temp_local_velrhopM1cX,*temp_local_velrhopM1cY;
  float *temp_local_velrhopM1cZ,*temp_local_velrhopM1cW;
  temp_local_velrhopM1cX = (float*)malloc(sizeof(float)*num_local_particles);
  temp_local_velrhopM1cY = (float*)malloc(sizeof(float)*num_local_particles);
  temp_local_velrhopM1cZ = (float*)malloc(sizeof(float)*num_local_particles);
  temp_local_velrhopM1cW = (float*)malloc(sizeof(float)*num_local_particles);*/
  //resort Idpc
  unsigned *temp_local_idpc;
  temp_local_idpc = (unsigned*)malloc(sizeof(unsigned)*num_local_particles);
  //resort Codec
  typecode *temp_local_codec;
  temp_local_codec= (typecode*)malloc(sizeof(typecode)*num_local_particles);
  //resort Dcellc
  unsigned *temp_local_dcellc;
  temp_local_dcellc= (unsigned*)malloc(sizeof(unsigned)*num_local_particles);
  //resort the index
  unsigned p4=0;
//  unsigned current_Np;
//  current_Np =Npb+num_local_particles;

  #ifdef OMP_USE
      #pragma omp parallel for schedule (static)
  #endif
  for(unsigned i=0;i<num_local_particles;i++){
	p4 = local_particles_central[i];
	//idpc
	temp_local_idpc[i] = Idpc[p4];
	//Posc x
	temp_local_posc[i].x = Posc[p4].x;
	//Posc y
	temp_local_posc[i].y = Posc[p4].y;
	//Posc z
	temp_local_posc[i].z = Posc[p4].z;
	//velrhop x
	temp_local_velrhopc[i].x = Velrhopc[p4].x;
	//velrhop y
	temp_local_velrhopc[i].y = Velrhopc[p4].y;
	//velrhop z
	temp_local_velrhopc[i].z = Velrhopc[p4].z;
	//velrhop w
	temp_local_velrhopc[i].w = Velrhopc[p4].w;
	//velrhopM1c x
	temp_local_velrhopM1c[i].x = VelrhopM1c[p4].x;
	//velrhopM1c y
	temp_local_velrhopM1c[i].y = VelrhopM1c[p4].y;
	//velrhopM1c z
	temp_local_velrhopM1c[i].z = VelrhopM1c[p4].z;
	//velrhopM1c w
	temp_local_velrhopM1c[i].w = VelrhopM1c[p4].w;
	//codec
	temp_local_codec[i] = 0x1800;
	//dcellc
	temp_local_dcellc[i] = Dcellc[p4];
	//*******check the legal or not
  }

  //---copy the local data
  //Posc
//  memcpy(&Posc[Npb].x,temp_local_posc,sizeof(tdouble3)*num_local_particles);
/*
  memcpy(&Posc[Npb].x,temp_local_poscX,sizeof(double)*num_local_particles);
  memcpy(&Posc[Npb].y,temp_local_poscY,sizeof(double)*num_local_particles);
  memcpy(&Posc[Npb].z,temp_local_poscZ,sizeof(double)*num_local_particles);*/
  //velrhopc
//  memcpy(&Velrhopc[Npb].x,temp_local_velrhopc,sizeof(tfloat4)*num_local_particles);
/*
  memcpy(&Velrhopc[Npb].x,temp_local_velrhopcX,sizeof(float)*num_local_particles);
  memcpy(&Velrhopc[Npb].y,temp_local_velrhopcY,sizeof(float)*num_local_particles);
  memcpy(&Velrhopc[Npb].z,temp_local_velrhopcZ,sizeof(float)*num_local_particles);
  memcpy(&Velrhopc[Npb].w,temp_local_velrhopcW,sizeof(float)*num_local_particles);*/
  //velrhopM1c
//  memcpy(&VelrhopM1c[Npb].x,temp_local_velrhopM1c,sizeof(tfloat4)*num_local_particles);
/*
  memcpy(&VelrhopM1c[Npb].x,temp_local_velrhopM1cX,sizeof(float)*num_local_particles);
  memcpy(&VelrhopM1c[Npb].y,temp_local_velrhopM1cY,sizeof(float)*num_local_particles);
  memcpy(&VelrhopM1c[Npb].z,temp_local_velrhopM1cZ,sizeof(float)*num_local_particles);
  memcpy(&VelrhopM1c[Npb].w,temp_local_velrhopM1cW,sizeof(float)*num_local_particles);*/
  //others
  unsigned index3=0;
  #ifdef OMP_USE
      #pragma omp parallel for schedule (static)
  #endif
  for(unsigned i=0;i<num_local_particles;i++){
        index3 = Npb+i;//3 including central+right
        Posc[index3].x = temp_local_posc[i].x;
        Posc[index3].y = temp_local_posc[i].y;
        Posc[index3].z = temp_local_posc[i].z;

        Velrhopc[index3].x = temp_local_velrhopc[i].x;
        Velrhopc[index3].y = temp_local_velrhopc[i].y;
        Velrhopc[index3].z = temp_local_velrhopc[i].z;
        Velrhopc[index3].w = temp_local_velrhopc[i].w;

        VelrhopM1c[index3].x = temp_local_velrhopM1c[i].x;
        VelrhopM1c[index3].y = temp_local_velrhopM1c[i].y;
        VelrhopM1c[index3].z = temp_local_velrhopM1c[i].z;
        VelrhopM1c[index3].w = temp_local_velrhopM1c[i].w;
	//test
	if(mpi_rank_id==mpi_start_rank_id){
		if(Posc[index3].y<=procboundary[1]){
        	//printf("in central part rank_id=%d,posc[%d].y=[%lf] is located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,index3,Posc[index3].y,procboundary[0],procboundary[1]);
        	}else{
                	printf("Error: in-###-central rank_id=%d,posc[%d].y=[%lf] don't located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,index3,Posc[index3].y,procboundary[0],procboundary[1]);
     			MPI_Abort(MPI_COMM_WORLD,45);
        	}
 
	}else if(mpi_rank_id==mpi_end_rank_id){
		if(Posc[index3].y>=procboundary[0]){
        	//printf("in central part rank_id=%d,posc[%d].y=[%lf] is located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,index3,Posc[index3].y,procboundary[0],procboundary[1]);
        	}else{
                	printf("Error: in-###-central rank_id=%d,posc[%d].y=[%lf] don't located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,index3,Posc[index3].y,procboundary[0],procboundary[1]);
     			MPI_Abort(MPI_COMM_WORLD,46);
        	} 
        }else{
		if(Posc[index3].y>=procboundary[0]&&Posc[index3].y<=procboundary[1]){
        	//printf("in central part rank_id=%d,posc[%d].y=[%lf] is located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,index3,Posc[index3].y,procboundary[0],procboundary[1]);
        	}else{
                	printf("Error: in-###-central rank_id=%d,posc[%d].y=[%lf] don't located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,index3,Posc[index3].y,procboundary[0],procboundary[1]);
     			MPI_Abort(MPI_COMM_WORLD,47);
        	}
        }
  }

  memcpy(&Idpc[Npb],temp_local_idpc,    sizeof(unsigned)*num_local_particles);
  memcpy(&Codec[Npb],temp_local_codec,  sizeof(typecode)*num_local_particles);
  memcpy(&Dcellc[Npb],temp_local_dcellc,sizeof(unsigned)*num_local_particles);

/*  unsigned p5=0,i5;
  for(unsigned i=0;i<num_local_particles;i++){
	p5 = Npb+i;
	i5 = local_particles_central[i5];
	Posc[p5].x = P;
  }*/
///////////////////test disorder//////////////////////////////////////////////
  //Posc left
//  if(mpi_rank_id!=mpi_start_rank_id){
/*
  memcpy(&Posc[Npb+num_local_particles].x,send_left_xx,sizeof(double)*num_going_left);
  memcpy(&Posc[Npb+num_local_particles].y,send_left_yy,sizeof(double)*num_going_left);
  memcpy(&Posc[Npb+num_local_particles].z,send_left_zz,sizeof(double)*num_going_left);
  //velrhopc
  memcpy(&Velrhopc[Npb+num_local_particles].x,send_left_vx,sizeof(float)*num_going_left);
  memcpy(&Velrhopc[Npb+num_local_particles].y,send_left_vy,sizeof(float)*num_going_left);
  memcpy(&Velrhopc[Npb+num_local_particles].z,send_left_vz,sizeof(float)*num_going_left);
  memcpy(&Velrhopc[Npb+num_local_particles].w,send_left_vr,sizeof(float)*num_going_left);
  //velrhopM1c
  memcpy(&VelrhopM1c[Npb+num_local_particles].x,send_left_mx,sizeof(float)*num_going_left);
  memcpy(&VelrhopM1c[Npb+num_local_particles].y,send_left_my,sizeof(float)*num_going_left);
  memcpy(&VelrhopM1c[Npb+num_local_particles].z,send_left_mz,sizeof(float)*num_going_left);
  memcpy(&VelrhopM1c[Npb+num_local_particles].w,send_left_mr,sizeof(float)*num_going_left);*/
  //others
/*  unsigned index4=0;
  for(unsigned i=0;i<num_going_left;i++){
	index4 = Npb+num_local_particles+i;//3 including central+right
	Posc[index4].x = send_left_xx[i];
	Posc[index4].y = send_left_yy[i];
	Posc[index4].z = send_left_zz[i];

	Velrhopc[index4].x = send_left_vx[i];
	Velrhopc[index4].y = send_left_vy[i];
	Velrhopc[index4].z = send_left_vz[i];
	Velrhopc[index4].w = send_left_vr[i];

	VelrhopM1c[index4].x = send_left_mx[i];
        VelrhopM1c[index4].y = send_left_my[i];
        VelrhopM1c[index4].z = send_left_mz[i];
        VelrhopM1c[index4].w = send_left_mr[i];
  }
  memcpy(&Idpc[Npb+num_local_particles],send_left_id,    sizeof(unsigned)*num_going_left);
  memcpy(&Dcellc[Npb+num_local_particles],send_left_cell,sizeof(unsigned)*num_going_left);
  }
  //Posc right
  if(mpi_rank_id!=mpi_end_rank_id){//!=3
*/
/*  memcpy(&Posc[Npb+num_local_particles+num_going_left].x,send_right_xx,sizeof(double)*num_going_right);
  memcpy(&Posc[Npb+num_local_particles+num_going_left].y,send_right_yy,sizeof(double)*num_going_right);
  memcpy(&Posc[Npb+num_local_particles+num_going_left].z,send_right_zz,sizeof(double)*num_going_right);
  //velrhopc
  memcpy(&Velrhopc[Npb+num_local_particles+num_going_left].x,send_right_vx,sizeof(float)*num_going_right);
  memcpy(&Velrhopc[Npb+num_local_particles+num_going_left].y,send_right_vy,sizeof(float)*num_going_right);
  memcpy(&Velrhopc[Npb+num_local_particles+num_going_left].z,send_right_vz,sizeof(float)*num_going_right);
  memcpy(&Velrhopc[Npb+num_local_particles+num_going_left].w,send_right_vr,sizeof(float)*num_going_right);
  //velrhopM1c
  memcpy(&VelrhopM1c[Npb+num_local_particles+num_going_left].x,send_right_mx,sizeof(float)*num_going_right);
  memcpy(&VelrhopM1c[Npb+num_local_particles+num_going_left].y,send_right_my,sizeof(float)*num_going_right);
  memcpy(&VelrhopM1c[Npb+num_local_particles+num_going_left].z,send_right_mz,sizeof(float)*num_going_right);
  memcpy(&VelrhopM1c[Npb+num_local_particles+num_going_left].w,send_right_mr,sizeof(float)*num_going_right);*/
  //others
/*  unsigned index5=0;
  for(unsigned i=0;i<num_going_right;i++){
	if(mpi_rank_id==mpi_start_rank_id){
        	index5 = Npb+num_local_particles+i;//0 including central+left
        }else{
		index5 = Npb+num_local_particles+num_going_left+i;
	}
	Posc[index5].x = send_right_xx[i];
        Posc[index5].y = send_right_yy[i];
        Posc[index5].z = send_right_zz[i];

        Velrhopc[index5].x = send_right_vx[i];
        Velrhopc[index5].y = send_right_vy[i];
        Velrhopc[index5].z = send_right_vz[i];
        Velrhopc[index5].w = send_right_vr[i];

        VelrhopM1c[index5].x = send_right_mx[i];
        VelrhopM1c[index5].y = send_right_my[i];
        VelrhopM1c[index5].z = send_right_mz[i];
        VelrhopM1c[index5].w = send_right_mr[i];
  }
  if(mpi_rank_id==mpi_start_rank_id){
  	memcpy(&Idpc[Npb+num_local_particles],send_right_id,    sizeof(unsigned)*num_going_right);
  	memcpy(&Dcellc[Npb+num_local_particles],send_right_cell,sizeof(unsigned)*num_going_right);
  }else{
	memcpy(&Idpc[Npb+num_local_particles+num_going_left],send_right_id,    sizeof(unsigned)*num_going_right);
        memcpy(&Dcellc[Npb+num_local_particles+num_going_left],send_right_cell,sizeof(unsigned)*num_going_right);
  }
  }*/
  //correct the code and idpc
/*
  for(unsigned k=Npb;k<Npb+num_local_particles;k++){/*
	double dx1=Posc[k].x-MapRealPosMin.x;
  	double dy1=Posc[k].y-MapRealPosMin.y;
  	double dz1=Posc[k].z-MapRealPosMin.z;
  	unsigned cx1=unsigned(dx1/Scell);
	unsigned cy1=unsigned(dy1/Scell);
	unsigned cz1=unsigned(dz1/Scell);
  	Dcellc[k]=PC__Cell(DomCellCode,cx1,cy1,cz1);*/
//	Codec[k]=0x1800;
//  }
//////////////////////////////////////////////////////////////////////////////
  //---free memory
  free(temp_local_posc);
/*
  free(temp_local_poscX);
  free(temp_local_poscY);
  free(temp_local_poscZ);*/
  //velrhopc
  free(temp_local_velrhopc);
/*
  free(temp_local_velrhopcX);
  free(temp_local_velrhopcY);
  free(temp_local_velrhopcZ);
  free(temp_local_velrhopcW);*/
  //velrhopM1c
  free(temp_local_velrhopM1c);
/*
  free(temp_local_velrhopM1cX);
  free(temp_local_velrhopM1cY);
  free(temp_local_velrhopM1cZ);
  free(temp_local_velrhopM1cW);*/
  //others
  free(temp_local_idpc);
  free(temp_local_codec);
  free(temp_local_dcellc);
  //==========wait===========
  MPI_Waitall(48,request_test,statu);
/*
  MPI_Wait(&request_test[0],&statu[0]);
  MPI_Wait(&request_test[1],&statu[1]);
  MPI_Wait(&request_test[2],&statu[2]);
  MPI_Wait(&request_test[3],&statu[3]);

  MPI_Wait(&request_test[4],&statu[4]);
  MPI_Wait(&request_test[5],&statu[5]);
  MPI_Wait(&request_test[6],&statu[6]);
  MPI_Wait(&request_test[7],&statu[7]);

  MPI_Wait(&request_test[8],&statu[8]);
  MPI_Wait(&request_test[9],&statu[9]);
  MPI_Wait(&request_test[10],&statu[10]);
  MPI_Wait(&request_test[11],&statu[11]);

  MPI_Wait(&request_test[12],&statu[12]);
  MPI_Wait(&request_test[13],&statu[13]);
  MPI_Wait(&request_test[14],&statu[14]);
  MPI_Wait(&request_test[15],&statu[15]);

  MPI_Wait(&request_test[16],&statu[16]);
  MPI_Wait(&request_test[17],&statu[17]);
  MPI_Wait(&request_test[18],&statu[18]);
  MPI_Wait(&request_test[19],&statu[19]);

  MPI_Wait(&request_test[20],&statu[20]);
  MPI_Wait(&request_test[21],&statu[21]);
  MPI_Wait(&request_test[22],&statu[22]);
  MPI_Wait(&request_test[23],&statu[23]);

  MPI_Wait(&request_test[24],&statu[24]);
  MPI_Wait(&request_test[25],&statu[25]);
  MPI_Wait(&request_test[26],&statu[26]);
  MPI_Wait(&request_test[27],&statu[27]);

  MPI_Wait(&request_test[28],&statu[28]);
  MPI_Wait(&request_test[29],&statu[29]);
  MPI_Wait(&request_test[30],&statu[30]);
  MPI_Wait(&request_test[31],&statu[31]);

  MPI_Wait(&request_test[32],&statu[32]);
  MPI_Wait(&request_test[33],&statu[33]);
  MPI_Wait(&request_test[34],&statu[34]);
  MPI_Wait(&request_test[35],&statu[35]);

  MPI_Wait(&request_test[36],&statu[36]);
  MPI_Wait(&request_test[37],&statu[37]);
  MPI_Wait(&request_test[38],&statu[38]);
  MPI_Wait(&request_test[39],&statu[39]);

  MPI_Wait(&request_test[40],&statu[40]);
  MPI_Wait(&request_test[41],&statu[41]);
  MPI_Wait(&request_test[42],&statu[42]);
  MPI_Wait(&request_test[43],&statu[43]);

  MPI_Wait(&request_test[44],&statu[44]);
  MPI_Wait(&request_test[45],&statu[45]);
  MPI_Wait(&request_test[46],&statu[46]);
  MPI_Wait(&request_test[47],&statu[47]);


/*
  //==================================wait=============================================//
  //waiting for left-------to-------right
  MPI_Wait(&request[0],&status[0]);
  MPI_Wait(&request[1],&status[1]);
  MPI_Wait(&request[2],&status[2]);
  MPI_Wait(&request[3],&status[3]);
  MPI_Wait(&request[4],&status[4]);
  MPI_Wait(&request[5],&status[5]);
  //-**waiting for right-----to------left
  MPI_Wait(&request[6],&status[6]);
  MPI_Wait(&request[7],&status[7]);
  MPI_Wait(&request[8],&status[8]);
  MPI_Wait(&request[9],&status[9]);
  MPI_Wait(&request[10],&status[10]);
  MPI_Wait(&request[11],&status[11]);

  //====================================UnPacked=======================================//
  //unPacked left--------to-------right
  //set the position as 0
  position = 0;
  //unpacked posc xx
  MPI_Unpack(buff,buff_length,&position,recv_left_xx,num_coming_left,MPI_DOUBLE,MPI_COMM_WORLD);
  //unpacked posc yy
  MPI_Unpack(buff,buff_length,&position,recv_left_yy,num_coming_left,MPI_DOUBLE,MPI_COMM_WORLD);
  //unpacked posc zz
  MPI_Unpack(buff,buff_length,&position,recv_left_zz,num_coming_left,MPI_DOUBLE,MPI_COMM_WORLD);
  //unpacked Idpc
  MPI_Unpack(buff,buff_length,&position,recv_left_id,num_coming_left,MPI_UNSIGNED,MPI_COMM_WORLD);
 
  // unpacked velrhopc
  //set the position as 0
  position01 = 0;
  //unpacked velrhopc x
  MPI_Unpack(buff01,buff_length01,&position01,recv_left_vx,num_coming_left,MPI_FLOAT,MPI_COMM_WORLD);
  //unpacked velrhopc y
  MPI_Unpack(buff01,buff_length01,&position01,recv_left_vy,num_coming_left,MPI_FLOAT,MPI_COMM_WORLD);
  //unpacked velrhopc z
  MPI_Unpack(buff01,buff_length01,&position01,recv_left_vz,num_coming_left,MPI_FLOAT,MPI_COMM_WORLD);
  //unpacked velrhopc w rho
  MPI_Unpack(buff01,buff_length01,&position01,recv_left_vr,num_coming_left,MPI_FLOAT,MPI_COMM_WORLD);

  // unpacked velrhopM1c
  //set the position as 0
  position02 = 0;
  //unpacked velrhopc x
  MPI_Unpack(buff02,buff_length02,&position02,recv_left_mx,num_coming_left,MPI_FLOAT,MPI_COMM_WORLD);
  //unpacked velrhopc y
  MPI_Unpack(buff02,buff_length02,&position02,recv_left_my,num_coming_left,MPI_FLOAT,MPI_COMM_WORLD);
  //unpacked velrhopc z
  MPI_Unpack(buff02,buff_length02,&position02,recv_left_mz,num_coming_left,MPI_FLOAT,MPI_COMM_WORLD);
  //unpacked velrhopc w rho
  MPI_Unpack(buff02,buff_length02,&position02,recv_left_mr,num_coming_left,MPI_FLOAT,MPI_COMM_WORLD);


  //-****unPacked right--------to-------left
  //set the position as 0
  position11 = 0;
  //unpacked posc xx
  MPI_Unpack(buff11,buff_length11,&position11,recv_right_xx,num_coming_right,MPI_DOUBLE,MPI_COMM_WORLD);
  //unpacked posc yy
  MPI_Unpack(buff11,buff_length11,&position11,recv_right_yy,num_coming_right,MPI_DOUBLE,MPI_COMM_WORLD);
  //unpacked posc zz
  MPI_Unpack(buff11,buff_length11,&position11,recv_right_zz,num_coming_right,MPI_DOUBLE,MPI_COMM_WORLD);
  //unpacked idpc 
  MPI_Unpack(buff11,buff_length11,&position11,recv_right_id,num_coming_right,MPI_UNSIGNED,MPI_COMM_WORLD);
  
  //unpacked velrhopc
  //set the position as 0
  position12 = 0;
  //unpacked velrhopc x
  MPI_Unpack(buff12,buff_length12,&position12,recv_right_vx,num_coming_right,MPI_FLOAT,MPI_COMM_WORLD);
  //unpacked velrhopc y
  MPI_Unpack(buff12,buff_length12,&position12,recv_right_vy,num_coming_right,MPI_FLOAT,MPI_COMM_WORLD);
  //unpacked velrhopc z
  MPI_Unpack(buff12,buff_length12,&position12,recv_right_vz,num_coming_right,MPI_FLOAT,MPI_COMM_WORLD);
  //unpacked velrhopc w rho
  MPI_Unpack(buff12,buff_length12,&position12,recv_right_vr,num_coming_right,MPI_FLOAT,MPI_COMM_WORLD);
  
  //unpacked velrhopM1c
  //set the position as 0
  position13 = 0;
  //unpacked velrhopM1c x
  MPI_Unpack(buff13,buff_length13,&position13,recv_right_mx,num_coming_right,MPI_FLOAT,MPI_COMM_WORLD);
  //unpacked velrhopM1c y
  MPI_Unpack(buff13,buff_length13,&position13,recv_right_my,num_coming_right,MPI_FLOAT,MPI_COMM_WORLD);
  //unpacked velrhopM1c z
  MPI_Unpack(buff13,buff_length13,&position13,recv_right_mz,num_coming_right,MPI_FLOAT,MPI_COMM_WORLD);
  //unpacked velrhopM1c w rho
  MPI_Unpack(buff13,buff_length13,&position13,recv_right_mr,num_coming_right,MPI_FLOAT,MPI_COMM_WORLD);

//========send recv===========================================//////////////////////////////////////////
////////////////====================================================================================////
  MPI_Status status_my[24];
  //left---------------------to---------------------right
  MPI_Sendrecv(send_right_xx,num_going_right,MPI_DOUBLE,right,370,
	       recv_left_xx,num_coming_left,MPI_DOUBLE,left,370,MPI_COMM_WORLD,&status_my[0]);
  MPI_Sendrecv(send_right_yy,num_going_right,MPI_DOUBLE,right,371,
               recv_left_yy,num_coming_left,MPI_DOUBLE,left,371,MPI_COMM_WORLD,&status_my[1]);
  MPI_Sendrecv(send_right_zz,num_going_right,MPI_DOUBLE,right,372,
               recv_left_zz,num_coming_left,MPI_DOUBLE,left,372,MPI_COMM_WORLD,&status_my[2]);
  MPI_Sendrecv(send_right_id,num_going_right,MPI_UNSIGNED,right,373,
               recv_left_id,num_coming_left,MPI_UNSIGNED,left,373,MPI_COMM_WORLD,&status_my[3]);
  //velrhopc
  MPI_Sendrecv(send_right_vx,num_going_right,MPI_FLOAT,right,374,
               recv_left_vx,num_coming_left,MPI_FLOAT,left,374,MPI_COMM_WORLD,&status_my[4]);
  MPI_Sendrecv(send_right_vy,num_going_right,MPI_FLOAT,right,375,
               recv_left_vy,num_coming_left,MPI_FLOAT,left,375,MPI_COMM_WORLD,&status_my[5]);
  MPI_Sendrecv(send_right_vz,num_going_right,MPI_FLOAT,right,376,
               recv_left_vz,num_coming_left,MPI_FLOAT,left,376,MPI_COMM_WORLD,&status_my[6]);
  MPI_Sendrecv(send_right_vr,num_going_right,MPI_FLOAT,right,377,
	       recv_left_vr,num_coming_left,MPI_FLOAT,left,377,MPI_COMM_WORLD,&status_my[7]);

  //velrhopMc
  MPI_Sendrecv(send_right_mx,num_going_right,MPI_FLOAT,right,378,
               recv_left_mx,num_coming_left,MPI_FLOAT,left,378,MPI_COMM_WORLD,&status_my[8]);
  MPI_Sendrecv(send_right_my,num_going_right,MPI_FLOAT,right,379,
               recv_left_my,num_coming_left,MPI_FLOAT,left,379,MPI_COMM_WORLD,&status_my[9]);
  MPI_Sendrecv(send_right_mz,num_going_right,MPI_FLOAT,right,380,
               recv_left_mz,num_coming_left,MPI_FLOAT,left,380,MPI_COMM_WORLD,&status_my[10]);
  MPI_Sendrecv(send_right_mr,num_going_right,MPI_FLOAT,right,381,
               recv_left_mr,num_coming_left,MPI_FLOAT,left,381,MPI_COMM_WORLD,&status_my[11]);
              
  //right-------------------to-----------------------left
  MPI_Sendrecv(send_left_xx,num_going_left,MPI_DOUBLE,left,382,
	       recv_right_xx,num_coming_right,MPI_DOUBLE,right,382,MPI_COMM_WORLD,&status_my[12]);
  MPI_Sendrecv(send_left_yy,num_going_left,MPI_DOUBLE,left,383,
               recv_right_yy,num_coming_right,MPI_DOUBLE,right,383,MPI_COMM_WORLD,&status_my[13]);
  MPI_Sendrecv(send_left_zz,num_going_left,MPI_DOUBLE,left,384,
               recv_right_zz,num_coming_right,MPI_DOUBLE,right,384,MPI_COMM_WORLD,&status_my[14]);
  MPI_Sendrecv(send_left_id,num_going_left,MPI_UNSIGNED,left,385,
               recv_right_id,num_coming_right,MPI_UNSIGNED,right,385,MPI_COMM_WORLD,&status_my[15]);
  //velrhopc
  MPI_Sendrecv(send_left_vx,num_going_left,MPI_FLOAT,left,386,
               recv_right_vx,num_coming_right,MPI_FLOAT,right,386,MPI_COMM_WORLD,&status_my[16]);
  MPI_Sendrecv(send_left_vy,num_going_left,MPI_FLOAT,left,387,
               recv_right_vy,num_coming_right,MPI_FLOAT,right,387,MPI_COMM_WORLD,&status_my[17]);
  MPI_Sendrecv(send_left_vz,num_going_left,MPI_FLOAT,left,388,
               recv_right_vz,num_coming_right,MPI_FLOAT,right,388,MPI_COMM_WORLD,&status_my[18]);
  MPI_Sendrecv(send_left_vr,num_going_left,MPI_FLOAT,left,389,
	       recv_right_vr,num_coming_right,MPI_FLOAT,right,389,MPI_COMM_WORLD,&status_my[19]);
  //velrhopMc
  MPI_Sendrecv(send_left_mx,num_going_left,MPI_FLOAT,left,390,
               recv_right_mx,num_coming_right,MPI_FLOAT,right,390,MPI_COMM_WORLD,&status_my[20]);
  MPI_Sendrecv(send_left_my,num_going_left,MPI_FLOAT,left,391,
               recv_right_my,num_coming_right,MPI_FLOAT,right,391,MPI_COMM_WORLD,&status_my[21]);
  MPI_Sendrecv(send_left_mz,num_going_left,MPI_FLOAT,left,392,
               recv_right_mz,num_coming_right,MPI_FLOAT,right,392,MPI_COMM_WORLD,&status_my[22]);
  MPI_Sendrecv(send_left_mr,num_going_left,MPI_FLOAT,left,393,
               recv_right_mr,num_coming_right,MPI_FLOAT,right,393,MPI_COMM_WORLD,&status_my[23]);
 
/////////======================================================================================////////
  //test results
//  printf("rank id=%d\n",mpi_rank_id);
/*  for(int i=0;i<num_coming_right;i++){
	printf("l2r-ghost PoscM1cXYWId[%d]=(%lf,%lf,%lf,%d),",i,recv_right_mx[i],recv_right_my[i],recv_right_mr[i],recv_right_id[i]);
  }*/

  //=============================reorganize the data by MPI tansfer====================================//
  //-----add the coming ghost particles data in left
  unsigned p8=0;
  #ifdef OMP_USE
      #pragma omp parallel for schedule (static)
  #endif
  for(unsigned i=0;i<num_coming_left;i++){//rank 0 num_coming_left=0
	//get the index after local particles
	p8 = Npb+num_local_particles+i;
	//idpc ghost particles
	Idpc[p8] = recv_left_id[i];
	//Posc ghost particles
	Posc[p8].x = recv_left_xx[i];
	Posc[p8].y = recv_left_yy[i];
	Posc[p8].z = recv_left_zz[i];
	//velrhop ghost particles
	Velrhopc[p8].x = recv_left_vx[i];
	Velrhopc[p8].y = recv_left_vy[i];
	Velrhopc[p8].z = recv_left_vz[i];
	Velrhopc[p8].w = recv_left_vr[i];
	//velrhopc ghost particles
	VelrhopM1c[p8].x = recv_left_mx[i];
	VelrhopM1c[p8].y = recv_left_my[i];
	VelrhopM1c[p8].z = recv_left_mz[i];
	VelrhopM1c[p8].w = recv_left_mr[i];
	//codec ghost particles always set 0x1800(fluid only consideratoin)
	Codec[p8] = 0x1800;
	//redistribution the cell are belong to
	double dx = recv_left_xx[i] - MapRealPosMin.x;
  	double dy = recv_left_yy[i] - MapRealPosMin.y;
  	double dz = recv_left_zz[i] - MapRealPosMin.z;
  	unsigned cx = unsigned(dx/Scell);
	unsigned cy = unsigned(dy/Scell);
	unsigned cz = unsigned(dz/Scell);
	//get the cell value for ghost particles
  	Dcellc[p8]=PC__Cell(DomCellCode,cx,cy,cz);

	//**************************************//
/*	 tdouble3 rpos;
	rpos.x=recv_left_xx[i];
	rpos.y=recv_left_yy[i];
	rpos.z=recv_left_zz[i];
	float rhopnew=Velrhopc[p8].w;
bool outrhop=(rhopnew<RhopOutMin||rhopnew>RhopOutMax);
double dx=rpos.x-MapRealPosMin.x;
  double dy=rpos.y-MapRealPosMin.y;
  double dz=rpos.z-MapRealPosMin.z;
  bool out=(dx!=dx || dy!=dy || dz!=dz || dx<0 || dy<0 || dz<0 || dx>=MapRealSize.x || dy>=MapRealSize.y || dz>=MapRealSize.z);
 
  if(PeriActive && out){
    if(PeriX){
      if(dx<0)             { dx-=PeriXinc.x; dy-=PeriXinc.y; dz-=PeriXinc.z; }
      if(dx>=MapRealSize.x){ dx+=PeriXinc.x; dy+=PeriXinc.y; dz+=PeriXinc.z; }
    }
    if(PeriY){
      if(dy<0)             { dx-=PeriYinc.x; dy-=PeriYinc.y; dz-=PeriYinc.z; }
      if(dy>=MapRealSize.y){ dx+=PeriYinc.x; dy+=PeriYinc.y; dz+=PeriYinc.z; }
    }
    if(PeriZ){
      if(dz<0)             { dx-=PeriZinc.x; dy-=PeriZinc.y; dz-=PeriZinc.z; }
      if(dz>=MapRealSize.z){ dx+=PeriZinc.x; dy+=PeriZinc.y; dz+=PeriZinc.z; }
    }
    bool outx=!PeriX && (dx<0 || dx>=MapRealSize.x);
    bool outy=!PeriY && (dy<0 || dy>=MapRealSize.y);
    bool outz=!PeriZ && (dz<0 || dz>=MapRealSize.z);
    out=(outx||outy||outz);
    rpos=TDouble3(dx,dy,dz)+MapRealPosMin;
  }
  Posc[p8]=rpos;
  if(outrhop || out){
    typecode rcode=Codec[p8];
    if(out)rcode=CODE_SetOutPos(rcode);
    else if(outrhop)rcode=CODE_SetOutRhop(rcode);
    else rcode=CODE_SetOutMove(rcode);
    Codec[p8]=rcode;
    Dcellc[p8]=0xFFFFFFFF;                                                                     
    printf("*****in the pos update, particles %d is out\n",p8);
//    MPI_Abort(MPI_COMM_WORLD,68);
  }else{
    if(PeriActive){
      dx=rpos.x-DomPosMin.x;
      dy=rpos.y-DomPosMin.y;
      dz=rpos.z-DomPosMin.z;
    }
    unsigned cx=unsigned(dx/Scell),cy=unsigned(dy/Scell),cz=unsigned(dz/Scell);
    Dcellc[p8]=PC__Cell(DomCellCode,cx,cy,cz);}*/	
	//*********check legal or not
/*	double *pmin = new double[mpi_rank_size]();
	double *pmax = new double[mpi_rank_size]();
	MPI_Allgather(&procboundary[0],1,MPI_DOUBLE,pmin,1,MPI_DOUBLE,MPI_COMM_WORLD);
	MPI_Allgather(&procboundary[1],1,MPI_DOUBLE,pmax,1,MPI_DOUBLE,MPI_COMM_WORLD);
*/
	if(mpi_rank_id==mpi_start_rank_id){
		if(Posc[p8].y<=procboundary[1]){
		//printf("in left rank_id=%d,posc[%d].y=[%lf] dont located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,p8,Posc[p8].y,procboundary[0],procboundary[1]);
		}else{
//			for(int i=0;i<mpi_rank_size;i++){
//				printf("rank %d Procboundry/min/max=[%lf,%lf] ",i,pmin[i],pmax[i]);
//			}
			printf("in***left rank_id=%d,posc[%d].y=[%lf] don't located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,p8,Posc[p8].y,procboundary[0],procboundary[1]);
		}

	}else if(mpi_rank_id==mpi_end_rank_id){
		if(Posc[p8].y>=procboundary[0]){
		//printf("in left rank_id=%d,posc[%d].y=[%lf] dont located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,p8,Posc[p8].y,procboundary[0],procboundary[1]);
		}else{
//			for(int i=0;i<mpi_rank_size;i++){
//				printf("rank %d Procboundry/min/max=[%lf,%lf] ",i,pmin[i],pmax[i]);
//			}
			printf("in***left rank_id=%d,posc[%d].y=[%lf] don't located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,p8,Posc[p8].y,procboundary[0],procboundary[1]);
		}

	}else{
		if(Posc[p8].y>=procboundary[0]&&Posc[p8].y<=procboundary[1]){
		//printf("in left rank_id=%d,posc[%d].y=[%lf] dont located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,p8,Posc[p8].y,procboundary[0],procboundary[1]);
		}else{
//			for(int i=0;i<mpi_rank_size;i++){
//				printf("rank %d Procboundry/min/max=[%lf,%lf] ",i,pmin[i],pmax[i]);
//			}
			printf("in***left rank_id=%d,posc[%d].y=[%lf] don't located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,p8,Posc[p8].y,procboundary[0],procboundary[1]);
		}
	}
//	delete[] pmin;
//	delete[] pmax;
  }
  //......add the coming ghost particles data in right
  unsigned p9=0;
  #ifdef OMP_USE
      #pragma omp parallel for schedule (static)
  #endif
  for(unsigned i=0;i<num_coming_right;i++){//rank 3 num_coming_right=0
	//get the index after local particles
	p9 = Npb+num_local_particles+num_coming_left+i;//rank 0 num_coming_left=0
	//idpc ghost particles
	Idpc[p9] = recv_right_id[i];
	//Posc ghost particles
	Posc[p9].x = recv_right_xx[i];
	Posc[p9].y = recv_right_yy[i];
	Posc[p9].z = recv_right_zz[i];
	//velrhop ghost particles
	Velrhopc[p9].x = recv_right_vx[i];
	Velrhopc[p9].y = recv_right_vy[i];
	Velrhopc[p9].z = recv_right_vz[i];
	Velrhopc[p9].w = recv_right_vr[i];
	//velrhopc ghost particles
	VelrhopM1c[p9].x = recv_right_mx[i];
	VelrhopM1c[p9].y = recv_right_my[i];
	VelrhopM1c[p9].z = recv_right_mz[i];
	VelrhopM1c[p9].w = recv_right_mr[i];
	//codec ghost particles always set 0x1800(fluid only consideratoin)
	Codec[p9] = 0x1800;
	//redistribution the cell are belong to
	double dx = recv_right_xx[i] - MapRealPosMin.x;
  	double dy = recv_right_yy[i] - MapRealPosMin.y;
  	double dz = recv_right_zz[i] - MapRealPosMin.z;
  	unsigned cx = unsigned(dx/Scell);
	unsigned cy = unsigned(dy/Scell);
	unsigned cz = unsigned(dz/Scell);
	//get the cell value for ghost particles
  	Dcellc[p9]=PC__Cell(DomCellCode,cx,cy,cz);	
//***************************************************/
/*
 tdouble3 rpos;
	rpos.x=recv_right_xx[i];
	rpos.y=recv_right_yy[i];
	rpos.z=recv_right_zz[i];
float rhopnew=Velrhopc[p9].w;
bool outrhop=(rhopnew<RhopOutMin||rhopnew>RhopOutMax);
double dx=rpos.x-MapRealPosMin.x;
  double dy=rpos.y-MapRealPosMin.y;
  double dz=rpos.z-MapRealPosMin.z;
  bool out=(dx!=dx || dy!=dy || dz!=dz || dx<0 || dy<0 || dz<0 || dx>=MapRealSize.x || dy>=MapRealSize.y || dz>=MapRealSize.z);
 
  if(PeriActive && out){
    if(PeriX){
      if(dx<0)             { dx-=PeriXinc.x; dy-=PeriXinc.y; dz-=PeriXinc.z; }
      if(dx>=MapRealSize.x){ dx+=PeriXinc.x; dy+=PeriXinc.y; dz+=PeriXinc.z; }
    }
    if(PeriY){
      if(dy<0)             { dx-=PeriYinc.x; dy-=PeriYinc.y; dz-=PeriYinc.z; }
      if(dy>=MapRealSize.y){ dx+=PeriYinc.x; dy+=PeriYinc.y; dz+=PeriYinc.z; }
    }
    if(PeriZ){
      if(dz<0)             { dx-=PeriZinc.x; dy-=PeriZinc.y; dz-=PeriZinc.z; }
      if(dz>=MapRealSize.z){ dx+=PeriZinc.x; dy+=PeriZinc.y; dz+=PeriZinc.z; }
    }
    bool outx=!PeriX && (dx<0 || dx>=MapRealSize.x);
    bool outy=!PeriY && (dy<0 || dy>=MapRealSize.y);
    bool outz=!PeriZ && (dz<0 || dz>=MapRealSize.z);
    out=(outx||outy||outz);
    rpos=TDouble3(dx,dy,dz)+MapRealPosMin;
  }
  Posc[p9]=rpos;
  if(outrhop || out){
    typecode rcode=Codec[p9];
    if(out)rcode=CODE_SetOutPos(rcode);
    else if(outrhop)rcode=CODE_SetOutRhop(rcode);
    else rcode=CODE_SetOutMove(rcode);
    Codec[p9]=rcode;
    Dcellc[p9]=0xFFFFFFFF;                                                                     
   printf("*****in the pos update, particles %d is out\n",p9);
//   MPI_Abort(MPI_COMM_WORLD,68);
  }else{
    if(PeriActive){
      dx=rpos.x-DomPosMin.x;
      dy=rpos.y-DomPosMin.y;
      dz=rpos.z-DomPosMin.z;
    }
    unsigned cx=unsigned(dx/Scell),cy=unsigned(dy/Scell),cz=unsigned(dz/Scell);
    Dcellc[p9]=PC__Cell(DomCellCode,cx,cy,cz);}	*/
 	//*********check legal or not
/* 	double *pmin = new double[mpi_rank_size]();
	double *pmax = new double[mpi_rank_size]();
	MPI_Allgather(&procboundary[0],1,MPI_DOUBLE,pmin,1,MPI_DOUBLE,MPI_COMM_WORLD);
	MPI_Allgather(&procboundary[1],1,MPI_DOUBLE,pmax,1,MPI_DOUBLE,MPI_COMM_WORLD);
*/	
 	if(mpi_rank_id==mpi_start_rank_id){
		if(Posc[p9].y<=procboundary[1]){
		//printf("in right rank_id=%d,posc[%d].y=[%lf] dont located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,p8,Posc[p8].y,procboundary[0],procboundary[1]);
		}else{
//			for(int i=0;i<mpi_rank_size;i++){
//				printf("rank %d Procboundry/min/max=[%lf,%lf] ",i,pmin[i],pmax[i]);
//			}
			printf("inxxxright rank_id=%d,posc[%d].y=[%lf] don't located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,p9,Posc[p9].y,procboundary[0],procboundary[1]);
		}
	
	}else if(mpi_rank_id==mpi_end_rank_id){
		if(Posc[p9].y>=procboundary[0]){
		//printf("in right rank_id=%d,posc[%d].y=[%lf] dont located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,p8,Posc[p8].y,procboundary[0],procboundary[1]);
		}else{
//			for(int i=0;i<mpi_rank_size;i++){
//				printf("rank %d Procboundry/min/max=[%lf,%lf] ",i,pmin[i],pmax[i]);
//			}
			printf("inxxxright rank_id=%d,posc[%d].y=[%lf] don't located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,p9,Posc[p9].y,procboundary[0],procboundary[1]);
		}
	
	}else{
		if(Posc[p9].y>=procboundary[0]&&Posc[p9].y<=procboundary[1]){
		//printf("in right rank_id=%d,posc[%d].y=[%lf] dont located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,p8,Posc[p8].y,procboundary[0],procboundary[1]);
		}else{
//			for(int i=0;i<mpi_rank_size;i++){
//				printf("rank %d Procboundry/min/max=[%lf,%lf] ",i,pmin[i],pmax[i]);
//			}
			printf("inxxxright rank_id=%d,posc[%d].y=[%lf] don't located in ranges of boundary[%lf,%lf]\n",mpi_rank_id,p9,Posc[p9].y,procboundary[0],procboundary[1]);
		}
	}
//	delete[] pmin;
//	delete[] pmax;
 }
  //update Np
  Np = Npb+num_local_particles+num_coming_left+num_coming_right;
  //correct idpc check all particles
//  for(unsigned i=Npb;i<Np;i++){
	
	//printf("pos=(%lf,%lf,%lf), ",Posc[i].x,Posc[i].y,Posc[i].z);
	//printf("velrhop[%d]=(%lf,%lf,%lf,%lf), ",i,Velrhopc[i].x,Velrhopc[i].y,Velrhopc[i].z,Velrhopc[i].w);
	//printf("velrhopM1c[%d]=(%lf,%lf,%lf,%lf), ",i,VelrhopM1c[i].x,VelrhopM1c[i].y,VelrhopM1c[i].z,VelrhopM1c[i].w);
	//printf("idpc/code/cell[%d]=(%d,%#x,%#x), ",i,Idpc[i],Codec[i],Dcellc[i]);
//  }
  /////////free memory
  //free left--to--right
  delete[] send_right_xx;send_right_xx=NULL;
  delete[] recv_left_xx; recv_left_xx =NULL;

  delete[] send_right_yy;send_right_yy=NULL;
  delete[] recv_left_yy; recv_left_yy =NULL;

  delete[] send_right_zz;send_right_zz=NULL;
  delete[] recv_left_zz; recv_left_zz =NULL;
  //velrhopc
  delete[] send_right_vx;send_right_vx=NULL;
  delete[] recv_left_vx; recv_left_vx =NULL;

  delete[] send_right_vy;send_right_vy=NULL;
  delete[] recv_left_vy; recv_left_vy =NULL;

  delete[] send_right_vz;send_right_vz=NULL;
  delete[] recv_left_vz; recv_left_vz =NULL;

  delete[] send_right_vr;send_right_vr=NULL;
  delete[] recv_left_vr; recv_left_vr =NULL;
  //velrhopm1c
  delete[] send_right_mx;send_right_mx=NULL;
  delete[] recv_left_mx;recv_left_mx  =NULL;

  delete[] send_right_my;send_right_my=NULL;
  delete[] recv_left_my;recv_left_my  =NULL;

  delete[] send_right_mz;send_right_mz=NULL;
  delete[] recv_left_mz;recv_left_mz  =NULL;

  delete[] send_right_mr;send_right_mr=NULL;
  delete[] recv_left_mr;recv_left_mr  =NULL;
  //idpc 
  delete[] send_right_id;send_right_id=NULL;
  delete[] recv_left_id;recv_left_id  =NULL;
 
  //free right--to--left--------------------
  delete[] send_left_xx; send_left_xx =NULL;
  delete[] recv_right_xx;recv_right_xx=NULL;

  delete[] send_left_yy; send_left_yy =NULL;
  delete[] recv_right_yy;recv_right_yy=NULL;

  delete[] send_left_zz; send_left_zz =NULL;
  delete[] recv_right_zz;recv_right_zz=NULL;
  //velrhopc
  delete[] send_left_vx;send_left_vx  =NULL;
  delete[] recv_right_vx;recv_right_vx=NULL;

  delete[] send_left_vy;send_left_vy  =NULL;
  delete[] recv_right_vy;recv_right_vy=NULL;

  delete[] send_left_vz;send_left_vz  =NULL;
  delete[] recv_right_vz;recv_right_vz=NULL;

  delete[] send_left_vr;send_left_vr  =NULL;
  delete[] recv_right_vr;recv_right_vr=NULL;
  //velrhopm1c
  delete[] send_left_mx;send_left_mx  =NULL;
  delete[] recv_right_mx;recv_right_mx=NULL;

  delete[] send_left_my;send_left_my  =NULL;
  delete[] recv_right_my;recv_right_my=NULL;

  delete[] send_left_mz;send_left_mz  =NULL;
  delete[] recv_right_mz;recv_right_mz=NULL;

  delete[] send_left_mr;send_left_mr  =NULL;
  delete[] recv_right_mr;recv_right_mr=NULL;
  //idpc 
  delete[] send_left_id;send_left_id  =NULL;
  delete[] recv_right_id;recv_right_id=NULL;
 //test
  delete[] send_left_cell;send_left_cell=NULL;
  delete[] send_right_cell;send_right_cell=NULL;
 
}
/*
  //get the number of right dir coming
  //data transfer director: left------to------->right
  MPI_Status status_sendx[mpi_rank_size];//mpi_end_rank_size=mpi_rank_size-1
  MPI_Status status_recvx[mpi_rank_size];
  MPI_Request request_sendx[mpi_rank_size];//array start from 0
  MPI_Request request_recvx[mpi_rank_size]; 
  //poscy  
  MPI_Status status_sendy[mpi_rank_size];//mpi_end_rank_size=mpi_rank_size-1
  MPI_Status status_recvy[mpi_rank_size];
  MPI_Request request_sendy[mpi_rank_size];//array start from 0
  MPI_Request request_recvy[mpi_rank_size];
  //poscz
  MPI_Status status_sendz[mpi_rank_size];//mpi_end_rank_size=mpi_rank_size-1
  MPI_Status status_recvz[mpi_rank_size];
  MPI_Request request_sendz[mpi_rank_size];//array start from 0
  MPI_Request request_recvz[mpi_rank_size];


  //data transfer director: right-----to-------->left
  MPI_Status status_sendx_r2l[mpi_rank_size];
  MPI_Status status_recvx_r2l[mpi_rank_size];
  MPI_Request request_sendx_r2l[mpi_rank_size];
  MPI_Request request_recvx_r2l[mpi_rank_size];
  //poscy
  MPI_Status status_sendy_r2l[mpi_rank_size];
  MPI_Status status_recvy_r2l[mpi_rank_size];
  MPI_Request request_sendy_r2l[mpi_rank_size];
  MPI_Request request_recvy_r2l[mpi_rank_size];
  //poscz
  MPI_Status status_sendz_r2l[mpi_rank_size];
  MPI_Status status_recvz_r2l[mpi_rank_size];
  MPI_Request request_sendz_r2l[mpi_rank_size];
  MPI_Request request_recvz_r2l[mpi_rank_size];


  //left---to--->right
  double *send_right_x = new double[num_going_right];  //to right processor
  double *recv_left_x  = new double[num_coming_left];  //source data from left processor
  //poscy
  double *send_right_y = new double[num_going_right];  //to right processor
  double *recv_left_y  = new double[num_coming_left];  //source data from left processor
  //poscz
  double *send_right_z = new double[num_going_right];  //to right processor
  double *recv_left_z  = new double[num_coming_left];  //source data from left processor
  //idpc 
  unsigned *send_right_idp=new unsigned[num_going_right];
  unsigned *recv_left_idp =new unsigned[num_coming_left];

  //right--to--->left
  double *send_left_x  = new double[num_going_left];
  double *recv_right_x = new double[num_coming_right];
  //poscy
  double *send_left_y  = new double[num_going_left];
  double *recv_right_y = new double[num_coming_right];
  //poscz
  double *send_left_z  = new double[num_going_left];
  double *recv_right_z = new double[num_coming_right];
  //idpc
  unsigned *send_left_idp =new unsigned[num_going_left];
  unsigned *recv_right_idp=new unsigned[num_coming_right];


  unsigned p,p1;
  // for left-------to---------right
  for(unsigned i=0;i<num_going_right;i++){
	p = ghost_going_to_right[i];
	send_right_x[i] = Posc[p].x;
	//poscy
	send_right_y[i] = Posc[p].y;
	//poscz
	send_right_z[i] = Posc[p].z;
	//idpc
	send_right_idp[i] = Idpc[p];


  }
  // for righ-------to-----------left
  for(unsigned i=0;i<num_going_left;i++){
	p1 = ghost_going_to_left[i];
	send_left_x[i] = Posc[p1].x;
	//poscy
	send_left_y[i] = Posc[p1].y;
	//poscz
	send_left_z[i] = Posc[p1].z;
	//idpc
	send_left_idp[i] = Idpc[p1];
//	printf("send_left_x[%d]=%lf, ",i,send_left_x[i]);
  }  
//new implements
  MPI_Request request_l2r[16];
  MPI_Status status_l2r[16];

  
  int tags1,tags2,tags3,tags4,tags5,tags6,tags7,tags8;
  tags1 = 1;
  tags2 = 2;
  tags3 = 3;
  tags4 = 4;
  tags5 = 5;
  tags6 = 6;
  tags7 = 7;
  tags8 = 8;
  /////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////------------send the data---------------///////////////////////////
  //for Posc left------->to------->right///////////////////////////////////////////////////////  
  MPI_Isend(send_right_x,num_going_right,MPI_DOUBLE,right,tags1,MPI_COMM_WORLD,&request_l2r[0]);
  MPI_Isend(send_right_y,num_going_right,MPI_DOUBLE,right,tags2,MPI_COMM_WORLD,&request_l2r[1]);
  MPI_Isend(send_right_z,num_going_right,MPI_DOUBLE,right,tags3,MPI_COMM_WORLD,&request_l2r[2]); 
  //for Posc right------>to------->left/////////////////////////////////////////////////////
  MPI_Isend(send_left_x,num_going_left,MPI_DOUBLE,left,tags4,MPI_COMM_WORLD,&request_l2r[3]);
  MPI_Isend(send_left_y,num_going_left,MPI_DOUBLE,left,tags5,MPI_COMM_WORLD,&request_l2r[4]);
  MPI_Isend(send_left_z,num_going_left,MPI_DOUBLE,left,tags6,MPI_COMM_WORLD,&request_l2r[5]); 

  //for Idpc left------->to------->right
  MPI_Isend(send_right_idp,num_going_right,MPI_UNSIGNED,right,tags7,MPI_COMM_WORLD,&request_l2r[6]);
  //for Idpc right------>to-------->left
  MPI_Isend(send_left_idp,num_going_left,MPI_UNSIGNED,left,tags8,MPI_COMM_WORLD,&request_l2r[7]);
  

  /////////////////////////////////////////////////////////////////////////////////////////
  /////////////////////---------receive data---------//////////////////////////////////////          
  //for Posc left------->to-------->right////////////////////////////////////////////////////
  MPI_Irecv(recv_left_x,num_coming_left,MPI_DOUBLE,left,tags1,MPI_COMM_WORLD,&request_l2r[8]);
  MPI_Irecv(recv_left_y,num_coming_left,MPI_DOUBLE,left,tags2,MPI_COMM_WORLD,&request_l2r[9]);
  MPI_Irecv(recv_left_z,num_coming_left,MPI_DOUBLE,left,tags3,MPI_COMM_WORLD,&request_l2r[10]);
  //for Posc right------>to--------->left////////////////////////////////////////////////////
  MPI_Irecv(recv_right_x,num_coming_right,MPI_DOUBLE,right,tags4,MPI_COMM_WORLD,&request_l2r[11]);
  MPI_Irecv(recv_right_y,num_coming_right,MPI_DOUBLE,right,tags5,MPI_COMM_WORLD,&request_l2r[12]);
  MPI_Irecv(recv_right_z,num_coming_right,MPI_DOUBLE,right,tags6,MPI_COMM_WORLD,&request_l2r[13]);
 
  //recv idpc left-------->to--------->right
  MPI_Irecv(recv_left_idp,num_coming_left,MPI_UNSIGNED,left,tags7,MPI_COMM_WORLD,&request_l2r[14]);
  //recv idpc right------->to--------->left
  MPI_Irecv(recv_right_idp,num_coming_right,MPI_UNSIGNED,right,tags8,MPI_COMM_WORLD,&request_l2r[15]);

  ///////////////////////////////do other things//////////////////////////////////////////////
  
  ////////////////////////////////////////wait////////////////////////////////////////////////
  MPI_Wait(&request_l2r[0],&status_l2r[0]);
  MPI_Wait(&request_l2r[1],&status_l2r[1]);
  MPI_Wait(&request_l2r[2],&status_l2r[2]);
  MPI_Wait(&request_l2r[3],&status_l2r[3]);
  MPI_Wait(&request_l2r[4],&status_l2r[4]);
  MPI_Wait(&request_l2r[5],&status_l2r[5]);
  //posc   
  MPI_Wait(&request_l2r[6],&status_l2r[6]);
  MPI_Wait(&request_l2r[7],&status_l2r[7]);
  MPI_Wait(&request_l2r[8],&status_l2r[8]);
  MPI_Wait(&request_l2r[9],&status_l2r[9]);
  MPI_Wait(&request_l2r[10],&status_l2r[10]);
  MPI_Wait(&request_l2r[11],&status_l2r[11]);
  //idpc
  MPI_Wait(&request_l2r[12],&status_l2r[12]);
  MPI_Wait(&request_l2r[13],&status_l2r[13]);
  MPI_Wait(&request_l2r[14],&status_l2r[14]);
  MPI_Wait(&request_l2r[15],&status_l2r[15]);


  // memcpy(send_right,&ghost_going_to_right[0],sizeof(double)*num_going_right);
  // 0------send------>1   tags: 200+0=200  request/status: 0
  // 1------send------>2   tags: 200+1=201  request/status: 1
  // 2------send------>3   tags: 200+2=202  request/status: 2
  // 3------send------>NULL---------------NULL--------------
  //send the messages left----->right---boundary
/*  if(mpi_rank_id!=mpi_end_rank_id){//not equal to rank end, because of the rank end need not to send messages.
  	MPI_Isend(send_right_x,num_going_right,MPI_DOUBLE,right,10000+mpi_rank_id,MPI_COMM_WORLD,&request_sendx[mpi_rank_id]);
  	printf("------>rank id=%d, data have sended(l2r), do other things.\n",mpi_rank_id);
	//////////////////do ther things sort///////////////////////////
	
	///////////////////////////////////////////////////////////////
  	MPI_Wait(&request_sendx[mpi_rank_id],&status_sendx[mpi_rank_id]);
//	MPI_Waitall(mpi_rank_size-1,request_sendx,status_recvx);

  	printf("++++++>rank id=%d, data have send finished(l2r).\n");
//	MPI_Request_free(request_sendx);
	//for posy
	MPI_Isend(send_right_y,num_going_right,MPI_DOUBLE,right,11000+mpi_rank_id,MPI_COMM_WORLD,&request_sendy[mpi_rank_id]);
	//////////////////do ther things sort///////////////////////////
	
	MPI_Wait(&request_sendy[mpi_rank_id],&status_sendy[mpi_rank_id]);
//	MPI_Request_free(request_sendy);

	//fo posz
	MPI_Isend(send_right_z,num_going_right,MPI_DOUBLE,right,12000+mpi_rank_id,MPI_COMM_WORLD,&request_sendz[mpi_rank_id]);
        //////////////////do ther things sort///////////////////////////

//	MPI_Wait(&request_sendx[mpi_rank_id],&status_sendx[mpi_rank_id]);
//	MPI_Wait(&request_sendy[mpi_rank_id],&status_sendy[mpi_rank_id]);
	MPI_Wait(&request_sendz[mpi_rank_id],&status_sendz[mpi_rank_id]);
//	MPI_Request_free(request_sendz);

  }*/
  //recv the messages left----->right-----boundary
  // 3------recv----from---->2 tags:200+2=202  requst/status: 2
  // 2------recv----from---->1 tags:200+1=201  requst/status: 1
  // 1------recv----from---->0 tags:200+0=200  requet/status: 0
  // 0------recv----from--------------NULL---------------------
/*  if(mpi_rank_id!=mpi_start_rank_id){//not equal to rank 0, the tags not match between rank 0 and rank end.
  	MPI_Irecv(recv_left_x,num_coming_left,MPI_DOUBLE,left,10000+mpi_rank_id-1,MPI_COMM_WORLD,&request_recvx[mpi_rank_id]);
	printf("------>rank id=%d, data start received(l2r), do other things.\n",mpi_rank_id);
	MPI_Wait(&request_recvx[mpi_rank_id],&status_recvx[mpi_rank_id]);
//	MPI_Waitall(mpi_rank_size-1,request_recvx, status_recvx);

//	MPI_Request_free(request_recvx);

	printf("++++++>rank id=%d, data have received finished(l2r).\n",mpi_rank_id);
        //posy
        MPI_Irecv(recv_left_y,num_coming_left,MPI_DOUBLE,left,11000+mpi_rank_id-1,MPI_COMM_WORLD,&request_recvy[mpi_rank_id]);
 	///////////////////do ther things sort///////////////////////////

	MPI_Wait(&request_recvy[mpi_rank_id],&status_recvy[mpi_rank_id]);
//	MPI_Request_free(request_recvy);

	//posz
	MPI_Irecv(recv_left_z,num_coming_left,MPI_DOUBLE,left,12000+mpi_rank_id-1,MPI_COMM_WORLD,&request_recvz[mpi_rank_id]);
	///////////////////do ther things sort///////////////////////////

//	MPI_Wait(&request_recvx[mpi_rank_id],&status_recvx[mpi_rank_id]);
//	MPI_Wait(&request_recvy[mpi_rank_id],&status_recvy[mpi_rank_id]);
	
	MPI_Wait(&request_recvz[mpi_rank_id],&status_recvz[mpi_rank_id]);
//	MPI_Request_free(request_recvz);

  }*/
  //test 
/*  printf("mpi_rank_id=%d, left--to--right\n",mpi_rank_id);
  for(int i=0;i<num_coming_left;i++){
	printf("Posx[%d]=%lf, ",i,recv_left_x[i]);
  }

  //send the messages boundary---left<-------right
  // 3------send------>2    tags: 300+3=303
  // 2------send------>1    tags: 300+2=302
  // 1------send------>0    tags: 300+1=301
  // 0------send------>NULL --------------
  if(mpi_rank_id!=mpi_start_rank_id){//not considering rank 0
	MPI_Isend(send_left_x,num_going_left,MPI_DOUBLE,left,300+mpi_rank_id,MPI_COMM_WORLD,&request_sendx_r2l[mpi_rank_id]);
	printf("------>rank id=%d, data have sended(r2l)\n",mpi_rank_id);
	//resort the data 
	MPI_Wait(&request_sendx_r2l[mpi_rank_id], &status_sendx_r2l[mpi_rank_id]);//change the data after this line
//	MPI_Request_free(request_sendx_r2l);
	printf("++++++>rank id=%d, data have send finished(r2l).\n",mpi_rank_id);
  }
  // recv the messages boundary----left<------right
  // 0------recv----from------>1  tags: 300+1 = 301
  // 1------recv----from------>2  tags: 300+2 = 302
  // 2------recv----from------>3  tags: 300+3 = 303
  // 3------recv----from------------NULL-----------
  if(mpi_rank_id!=mpi_end_rank_id){
	MPI_Irecv(recv_right_x,num_coming_right,MPI_DOUBLE,right,300+mpi_rank_id+1,MPI_COMM_WORLD,&request_recvx_r2l[mpi_rank_id]);
	printf("------>rank id=%d, data start received(r2l), do other things.\n",mpi_rank_id);
	MPI_Wait(&request_recvx_r2l[mpi_rank_id], &status_recvx_r2l[mpi_rank_id]);//using the date after this line
//	MPI_Request_free(request_recvx_r2l);
	printf("++++++>rank id=%d, data have send finished(r2l).\n",mpi_rank_id);
  }*/
  //test
/*  printf("mpi_rank_id=%d, right--to--left\n",mpi_rank_id);
  for(int i=0;i<num_coming_left;i++){
        printf("posc_2method[%d]=[x(%lf,%lf),y(%lf,%lf),z(%lf,%lf)]~ ",i,recv_left_x[i],recv_left_xx[i],recv_left_y[i],recv_left_yy[i],recv_left_z[i],recv_left_zz[i]);
  }

  //free the tempory memory
  delete[] send_right_x;send_right_x=NULL;
  delete[] recv_left_x;recv_left_x=NULL;
  
  delete[] send_left_x;send_left_x=NULL;
  delete[] recv_right_x;recv_right_x=NULL;
  //posy
  delete[] send_right_y;send_right_y=NULL;
  delete[] recv_left_y;recv_left_y=NULL;
  
  delete[] send_left_y;send_left_y=NULL;
  delete[] recv_right_y;recv_right_y=NULL;
  //posz
  delete[] send_right_z;send_right_z=NULL;
  delete[] recv_left_z;recv_left_z=NULL;
  
  delete[] send_left_z;send_left_z=NULL;
  delete[] recv_right_z;recv_right_z=NULL;
  //idpc
  delete[] send_right_idp;send_right_idp=NULL;
  delete[] recv_left_idp;recv_left_idp=NULL;

  delete[] send_left_idp;send_left_idp=NULL;
  delete[] recv_right_idp;recv_right_idp=NULL;

//test
  delete[] send_right_xx;
  delete[] recv_left_xx;
 
  delete[] send_right_yy;
  delete[] recv_left_yy;
 
  delete[] send_right_zz;
  delete[] recv_left_zz;
*/
/*  if(mpi_rank_id==mpi_end_rank_id){//for right boundary processor rank_id =size-1;

  }else{

  }*/
////////////////////////////////and one particles
//if(mpi_rank_id==1){
//  unsigned pini=Npb;
/*  Posc[Np].x=Posc[Np-3].x; 
  Posc[Np].y=Posc[Np-3].y;   
  Posc[Np].z=Posc[Np-3].z;
//
  Velrhopc[Np].x=Velrhopc[Np-3].x;
  Velrhopc[Np].y=Velrhopc[Np-3].y;
  Velrhopc[Np].z=Velrhopc[Np-3].z;
  Velrhopc[Np].w=Velrhopc[Np-3].w;
                 
// verlet only have
  VelrhopM1c[Np].x=VelrhopM1c[Np-3].x; 
  VelrhopM1c[Np].y=VelrhopM1c[Np-3].y;
  VelrhopM1c[Np].z=VelrhopM1c[Np-3].z;
  VelrhopM1c[Np].w=VelrhopM1c[Np-3].w;

//add Codec
  Codec[Np]=Codec[Np-3];//error will be introduced
  Dcellc[Np]=Dcellc[Np-3];
  Idpc[Np]=Np;//idpc cannot repeat because sub-index begin from 1 insteady of 0
  Np++;*/
/*  if(mpi_rank_id==0)printf("after--(>_<)--rank 0,add one**********~(^_^)~************Np=%d\n",Np);
//}
 ////////////////////////////////////////
}
*/

//==============================================================================
/// Update of particles according to forces and dt using Symplectic-Predictor.
/// Actualizacion de particulas segun fuerzas y dt usando Symplectic-Predictor.
//==============================================================================
void JSphCpu::ComputeSymplecticPre(double dt){
  if(Shifting)ComputeSymplecticPreT<false>(dt); //-We strongly recommend running the shifting correction only for the corrector. If you want to re-enable shifting in the predictor, change the value here to "true".
  else        ComputeSymplecticPreT<false>(dt);
}

//==============================================================================
/// Update of particles according to forces and dt using Symplectic-Predictor.
/// Actualizacion de particulas segun fuerzas y dt usando Symplectic-Predictor.
//==============================================================================
template<bool shift> void JSphCpu::ComputeSymplecticPreT(double dt){
  TmcStart(Timers,TMC_SuComputeStep);
  //-Assign memory to variables Pre. | Asigna memoria a variables Pre.
  PosPrec=ArraysCpu->ReserveDouble3();
  VelrhopPrec=ArraysCpu->ReserveFloat4();
  //-Change data to variables Pre to calculate new data. | Cambia datos a variables Pre para calcular nuevos datos.
  swap(PosPrec,Posc);         //Put value of Pos[] in PosPre[].         | Es decir... PosPre[] <= Pos[].
  swap(VelrhopPrec,Velrhopc); //Put value of Velrhop[] in VelrhopPre[]. | Es decir... VelrhopPre[] <= Velrhop[].
  //-Calculate new values of particles. | Calcula nuevos datos de particulas.
  const double dt05=dt*.5;
  
  //-Calculate new density for boundary and copy velocity. | Calcula nueva densidad para el contorno y copia velocidad.
  const int npb=int(Npb);
  #ifdef OMP_USE
    #pragma omp parallel for schedule (static) if(npb>OMP_LIMIT_COMPUTESTEP)
  #endif
  for(int p=0;p<npb;p++){
    const tfloat4 vr=VelrhopPrec[p];
    const float rhopnew=float(double(vr.w)+dt05*Arc[p]);
    Velrhopc[p]=TFloat4(vr.x,vr.y,vr.z,(rhopnew<RhopZero? RhopZero: rhopnew));//-Avoid fluid particles being absorbed by boundary ones. | Evita q las boundary absorvan a las fluidas.
  }

  //-Calculate new values of fluid. | Calcula nuevos datos del fluido.
  const int np=int(Np);
  #ifdef OMP_USE
    #pragma omp parallel for schedule (static) if(np>OMP_LIMIT_COMPUTESTEP)
  #endif
  for(int p=npb;p<np;p++){
    //-Calculate density.
    const float rhopnew=float(double(VelrhopPrec[p].w)+dt05*Arc[p]);
    if(!WithFloating || CODE_IsFluid(Codec[p])){//-Fluid Particles.
      //-Calculate displacement & update position. | Calcula desplazamiento y actualiza posicion.
      double dx=double(VelrhopPrec[p].x)*dt05;
      double dy=double(VelrhopPrec[p].y)*dt05;
      double dz=double(VelrhopPrec[p].z)*dt05;
      if(shift){
        dx+=double(ShiftPosfsc[p].x);
        dy+=double(ShiftPosfsc[p].y);
        dz+=double(ShiftPosfsc[p].z);
      }
      bool outrhop=(rhopnew<RhopOutMin||rhopnew>RhopOutMax);
      UpdatePos(PosPrec[p],dx,dy,dz,outrhop,p,Posc,Dcellc,Codec);
      //-Update velocity & density. | Actualiza velocidad y densidad.
      Velrhopc[p].x=float(double(VelrhopPrec[p].x) + (double(Acec[p].x)+Gravity.x) * dt05);
      Velrhopc[p].y=float(double(VelrhopPrec[p].y) + (double(Acec[p].y)+Gravity.y) * dt05);
      Velrhopc[p].z=float(double(VelrhopPrec[p].z) + (double(Acec[p].z)+Gravity.z) * dt05);
      Velrhopc[p].w=rhopnew;
    }
    else{//-Floating Particles.
      Velrhopc[p]=VelrhopPrec[p];
      Velrhopc[p].w=(rhopnew<RhopZero? RhopZero: rhopnew); //-Avoid fluid particles being absorbed by floating ones. | Evita q las floating absorvan a las fluidas.
      //-Copy position. | Copia posicion.
      Posc[p]=PosPrec[p];
    }
  }

  //-Copy previous position of boundary. | Copia posicion anterior del contorno.
  memcpy(Posc,PosPrec,sizeof(tdouble3)*Npb);

  TmcStop(Timers,TMC_SuComputeStep);
}

//==============================================================================
/// Update particles according to forces and dt using Symplectic-Corrector.
/// Actualizacion de particulas segun fuerzas y dt usando Symplectic-Corrector.
//==============================================================================
void JSphCpu::ComputeSymplecticCorr(double dt){
  if(Shifting)ComputeSymplecticCorrT<true> (dt);
  else        ComputeSymplecticCorrT<false>(dt);
}

//==============================================================================
/// Update particles according to forces and dt using Symplectic-Corrector.
/// Actualizacion de particulas segun fuerzas y dt usando Symplectic-Corrector.
//==============================================================================
template<bool shift> void JSphCpu::ComputeSymplecticCorrT(double dt){
  TmcStart(Timers,TMC_SuComputeStep);
  
  //-Calculate rhop of boudary and set velocity=0. | Calcula rhop de contorno y vel igual a cero.
  const int npb=int(Npb);
  #ifdef OMP_USE
    #pragma omp parallel for schedule (static) if(npb>OMP_LIMIT_COMPUTESTEP)
  #endif
  for(int p=0;p<npb;p++){
    const double epsilon_rdot=(-double(Arc[p])/double(Velrhopc[p].w))*dt;
    const float rhopnew=float(double(VelrhopPrec[p].w) * (2.-epsilon_rdot)/(2.+epsilon_rdot));
    Velrhopc[p]=TFloat4(0,0,0,(rhopnew<RhopZero? RhopZero: rhopnew));//-Avoid fluid particles being absorbed by boundary ones. | Evita q las boundary absorvan a las fluidas.
  }

  //-Calculate fluid values. | Calcula datos de fluido.
  const double dt05=dt*.5;
  const int np=int(Np);
  #ifdef OMP_USE
    #pragma omp parallel for schedule (static) if(np>OMP_LIMIT_COMPUTESTEP)
  #endif
  for(int p=npb;p<np;p++){
    const double epsilon_rdot=(-double(Arc[p])/double(Velrhopc[p].w))*dt;
    const float rhopnew=float(double(VelrhopPrec[p].w) * (2.-epsilon_rdot)/(2.+epsilon_rdot));
    if(!WithFloating || CODE_IsFluid(Codec[p])){//-Fluid Particles.
      //-Update velocity & density. | Actualiza velocidad y densidad.
      Velrhopc[p].x=float(double(VelrhopPrec[p].x) + (double(Acec[p].x)+Gravity.x) * dt); 
      Velrhopc[p].y=float(double(VelrhopPrec[p].y) + (double(Acec[p].y)+Gravity.y) * dt); 
      Velrhopc[p].z=float(double(VelrhopPrec[p].z) + (double(Acec[p].z)+Gravity.z) * dt); 
      Velrhopc[p].w=rhopnew;
      //-Calculate displacement and update position. | Calcula desplazamiento y actualiza posicion.
      double dx=(double(VelrhopPrec[p].x)+double(Velrhopc[p].x)) * dt05; 
      double dy=(double(VelrhopPrec[p].y)+double(Velrhopc[p].y)) * dt05; 
      double dz=(double(VelrhopPrec[p].z)+double(Velrhopc[p].z)) * dt05;
      if(shift){
        dx+=double(ShiftPosfsc[p].x);
        dy+=double(ShiftPosfsc[p].y);
        dz+=double(ShiftPosfsc[p].z);
      }
      bool outrhop=(rhopnew<RhopOutMin||rhopnew>RhopOutMax);
      UpdatePos(PosPrec[p],dx,dy,dz,outrhop,p,Posc,Dcellc,Codec);
    }
    else{//-Floating Particles.
      Velrhopc[p]=VelrhopPrec[p];
      Velrhopc[p].w=(rhopnew<RhopZero? RhopZero: rhopnew); //-Avoid fluid particles being absorbed by floating ones. | Evita q las floating absorvan a las fluidas.
      //-Copy position. | Copia posicion.
      Posc[p]=PosPrec[p];
    }
  }

  //-Free memory assigned to variables Pre and ComputeSymplecticPre(). | Libera memoria asignada a variables Pre en ComputeSymplecticPre().
  ArraysCpu->Free(PosPrec);      PosPrec=NULL;
  ArraysCpu->Free(VelrhopPrec);  VelrhopPrec=NULL;
  TmcStop(Timers,TMC_SuComputeStep);
}

//==============================================================================
/// Calculate variable Dt.
/// Calcula un Dt variable.
//==============================================================================
double JSphCpu::DtVariable(bool final){
  //-dt1 depends on force per unit mass.
  const double dt1=(AceMax? (sqrt(double(H)/AceMax)): DBL_MAX); 
  //-dt2 combines the Courant and the viscous time-step controls.
  const double dt2=double(H)/(max(Cs0,VelMax*10.)+double(H)*ViscDtMax);
  //-dt new value of time step.
  double dt=double(CFLnumber)*min(dt1,dt2);
  if(DtFixed)dt=DtFixed->GetDt(TimeStep,dt);
  if(dt<double(DtMin)){ 
    dt=double(DtMin); DtModif++;
    if(DtModif>=DtModifWrn){
      Log->PrintfWarning("%d DTs adjusted to DtMin (t:%g, nstep:%u)",DtModif,TimeStep,Nstep);
      DtModifWrn*=10;
    }
  }
  //-Saves information about dt.
  if(final){
    if(PartDtMin>dt)PartDtMin=dt;
    if(PartDtMax<dt)PartDtMax=dt;
    //-Saves detailed information about dt in SaveDt object.
    if(SaveDt)SaveDt->AddValues(TimeStep,dt,dt1*CFLnumber,dt2*CFLnumber,AceMax,ViscDtMax,VelMax);
  }
  return(dt);
}

//==============================================================================
/// Calculate final Shifting for particles' position.
/// Calcula Shifting final para posicion de particulas.
//==============================================================================
void JSphCpu::RunShifting(double dt){
  TmcStart(Timers,TMC_SuShifting);
  Shifting->RunCpu(Np-Npb,Npb,dt,Velrhopc,ShiftPosfsc);
  TmcStop(Timers,TMC_SuShifting);
}

//==============================================================================
/// Calculate position of particles according to idp[]. When it is not met set as UINT_MAX.
/// When periactive is False assume that there are no duplicate particles (periodic ones)
/// and all are set as CODE_NORMAL.
///
/// Calcula posicion de particulas segun idp[]. Cuando no la encuentra es UINT_MAX.
/// Cuando periactive es False supone que no hay particulas duplicadas (periodicas)
/// y todas son CODE_NORMAL.
//==============================================================================
void JSphCpu::CalcRidp(bool periactive,unsigned np,unsigned pini,unsigned idini,unsigned idfin,const typecode *code,const unsigned *idp,unsigned *ridp)const{
  //-Assign values UINT_MAX. | Asigna valores UINT_MAX.
  const unsigned nsel=idfin-idini;
  memset(ridp,255,sizeof(unsigned)*nsel); 
  //-Calculate position according to id. | Calcula posicion segun id.
  const int pfin=int(pini+np);
  if(periactive){//-Calculate position according to id checking that the particles are normal (i.e. not periodic). | Calcula posicion segun id comprobando que las particulas son normales (no periodicas).
    #ifdef OMP_USE
      #pragma omp parallel for schedule (static) if(pfin>OMP_LIMIT_COMPUTELIGHT)
    #endif
    for(int p=int(pini);p<pfin;p++){
      const unsigned id=idp[p];
      if(idini<=id && id<idfin){
        if(CODE_IsNormal(code[p]))ridp[id-idini]=p;
      }
    }
  }
  else{//-Calculate position according to id assuming that all the particles are normal (i.e. not periodic). | Calcula posicion segun id suponiendo que todas las particulas son normales (no periodicas).
    #ifdef OMP_USE
      #pragma omp parallel for schedule (static) if(pfin>OMP_LIMIT_COMPUTELIGHT)
    #endif
    for(int p=int(pini);p<pfin;p++){
      const unsigned id=idp[p];
      if(idini<=id && id<idfin)ridp[id-idini]=p;
    }
  }
}

//==============================================================================
/// Applies a linear movement to a group of particles.
/// Aplica un movimiento lineal a un conjunto de particulas.
//==============================================================================
void JSphCpu::MoveLinBound(unsigned np,unsigned ini,const tdouble3 &mvpos,const tfloat3 &mvvel
  ,const unsigned *ridp,tdouble3 *pos,unsigned *dcell,tfloat4 *velrhop,typecode *code)const
{
  const unsigned fin=ini+np;
  for(unsigned id=ini;id<fin;id++){
    const unsigned pid=RidpMove[id];
    if(pid!=UINT_MAX){
      UpdatePos(pos[pid],mvpos.x,mvpos.y,mvpos.z,false,pid,pos,dcell,code);
      velrhop[pid].x=mvvel.x;  velrhop[pid].y=mvvel.y;  velrhop[pid].z=mvvel.z;
    }
  }
}

//==============================================================================
/// Applies a matrix movement to a group of particles.
/// Aplica un movimiento matricial a un conjunto de particulas.
//==============================================================================
void JSphCpu::MoveMatBound(unsigned np,unsigned ini,tmatrix4d m,double dt,const unsigned *ridpmv
  ,tdouble3 *pos,unsigned *dcell,tfloat4 *velrhop,typecode *code,tfloat3 *boundnormal)const
{
  const unsigned fin=ini+np;
  for(unsigned id=ini;id<fin;id++){
    const unsigned pid=RidpMove[id];
    if(pid!=UINT_MAX){
      const tdouble3 ps=pos[pid];
      tdouble3 ps2=MatrixMulPoint(m,ps);
      if(Simulate2D)ps2.y=ps.y;
      const double dx=ps2.x-ps.x, dy=ps2.y-ps.y, dz=ps2.z-ps.z;
      UpdatePos(ps,dx,dy,dz,false,pid,pos,dcell,code);
      velrhop[pid].x=float(dx/dt);  velrhop[pid].y=float(dy/dt);  velrhop[pid].z=float(dz/dt);
    }
  }
}

//==============================================================================
/// Calculates predefined movement of boundary particles.
/// Calcula movimiento predefinido de boundary particles.
//==============================================================================
void JSphCpu::CalcMotion(double stepdt){
  TmcStart(Timers,TMC_SuMotion);
  JSph::CalcMotion(stepdt);
  TmcStop(Timers,TMC_SuMotion);
}

//==============================================================================
/// Process movement of boundary particles.
/// Procesa movimiento de boundary particles.
//==============================================================================
void JSphCpu::RunMotion(double stepdt){
  TmcStart(Timers,TMC_SuMotion);
  tfloat3 *boundnormal=NULL;
  const bool motsim=true;
  BoundChanged=false;
  //-Add motion from automatic wave generation.
  if(WaveGen)CalcMotionWaveGen(stepdt);
  //-Process particles motion.
  if(SphMotion->GetActiveMotion()){
    CalcRidp(PeriActive!=0,Npb,0,CaseNfixed,CaseNfixed+CaseNmoving,Codec,Idpc,RidpMove);
    BoundChanged=true;
    const unsigned nref=SphMotion->GetNumObjects();
    for(unsigned ref=0;ref<nref;ref++){
      const StMotionData& m=SphMotion->GetMotionData(ref);
      if(m.type==MOTT_Linear){//-Linear movement.
        if(motsim)MoveLinBound   (m.count,m.idbegin-CaseNfixed,m.linmov,ToTFloat3(m.linvel),RidpMove,Posc,Dcellc,Velrhopc,Codec);
        //else    MoveLinBoundAce(m.count,m.idbegin-CaseNfixed,m.linmov,ToTFloat3(m.linvel),ToTFloat3(m.linace),RidpMove,Posc,Dcellc,Velrhopc,Acec,Codec);
      }
      if(m.type==MOTT_Matrix){//-Matrix movement (for rotations).
        if(motsim)MoveMatBound   (m.count,m.idbegin-CaseNfixed,m.matmov,stepdt,RidpMove,Posc,Dcellc,Velrhopc,Codec,boundnormal); 
        //else    MoveMatBoundAce(m.count,m.idbegin-CaseNfixed,m.matmov,m.matmov2,stepdt,RidpMove,Posc,Dcellc,Velrhopc,Acec,Codec);
      }      
      //-Applies predefined motion to BoundCorr configuration.           //<vs_innlet> 
      if(BoundCorr && BoundCorr->GetUseMotion())BoundCorr->RunMotion(m); //<vs_innlet> 
    }
  }
  //-Management of Multi-Layer Pistons.  //<vs_mlapiston_ini>
  if(MLPistons){
    if(!BoundChanged)CalcRidp(PeriActive!=0,Npb,0,CaseNfixed,CaseNfixed+CaseNmoving,Codec,Idpc,RidpMove);
    BoundChanged=true;
    if(MLPistons->GetPiston1dCount()){//-Process motion for pistons 1D.
      MLPistons->CalculateMotion1d(TimeStep+MLPistons->GetTimeMod()+stepdt);
      MovePiston1d(CaseNmoving,0,MLPistons->GetPoszMin(),MLPistons->GetPoszCount()
        ,MLPistons->GetPistonId(),MLPistons->GetMovx(),MLPistons->GetVelx()
        ,RidpMove,Posc,Dcellc,Velrhopc,Codec);
    }
    for(unsigned cp=0;cp<MLPistons->GetPiston2dCount();cp++){//-Process motion for pistons 2D.
      JMLPistons::StMotionInfoPiston2D mot=MLPistons->CalculateMotion2d(cp,TimeStep+MLPistons->GetTimeMod()+stepdt);
      MovePiston2d(mot.np,mot.idbegin-CaseNfixed,mot.posymin,mot.poszmin,mot.poszcount,mot.movyz,mot.velyz
        ,RidpMove,Posc,Dcellc,Velrhopc,Codec);
    }
  }  //<vs_mlapiston_end>
  TmcStop(Timers,TMC_SuMotion);
}

//<vs_mlapiston_ini>
//==============================================================================
/// Applies movement and velocity of piston 1D to a group of particles.
/// Aplica movimiento y velocidad de piston 1D a conjunto de particulas.
//==============================================================================
void JSphCpu::MovePiston1d(unsigned np,unsigned ini
  ,double poszmin,unsigned poszcount,const byte *pistonid,const double* movx,const double* velx
  ,const unsigned *ridpmv,tdouble3 *pos,unsigned *dcell,tfloat4 *velrhop,typecode *code)const
{
  const int fin=int(ini+np);
  #ifdef OMP_USE
    #pragma omp parallel for schedule (static) if(fin>OMP_LIMIT_LIGHT)
  #endif
  for(int id=int(ini);id<fin;id++){
    const unsigned pid=ridpmv[id];
    if(pid!=UINT_MAX){
      const unsigned pisid=pistonid[CODE_GetTypeValue(code[pid])];
      if(pisid<255){
        const unsigned cz=unsigned((pos[pid].z-poszmin)/Dp);
        const double rmovx=(cz<poszcount? movx[pisid*poszcount+cz]: 0);
        const float rvelx=float(cz<poszcount? velx[pisid*poszcount+cz]: 0);
        //-Updates position.
        UpdatePos(pos[pid],rmovx,0,0,false,pid,pos,dcell,code);
        //-Updates velocity.
        velrhop[pid].x=rvelx;
      }
    }
  }
}
//==============================================================================
/// Applies movement and velocity of piston 2D to a group of particles.
/// Aplica movimiento y velocidad de piston 2D a conjunto de particulas.
//==============================================================================
void JSphCpu::MovePiston2d(unsigned np,unsigned ini
  ,double posymin,double poszmin,unsigned poszcount,const double* movx,const double* velx
  ,const unsigned *ridpmv,tdouble3 *pos,unsigned *dcell,tfloat4 *velrhop,typecode *code)const
{
  const int fin=int(ini+np);
  #ifdef OMP_USE
    #pragma omp parallel for schedule (static) if(fin>OMP_LIMIT_LIGHT)
  #endif
  for(int id=int(ini);id<fin;id++){
    const unsigned pid=ridpmv[id];
    if(pid!=UINT_MAX){
      const tdouble3 ps=pos[pid];
      const unsigned cy=unsigned((ps.y-posymin)/Dp);
      const unsigned cz=unsigned((ps.z-poszmin)/Dp);
      const double rmovx=(cz<poszcount? movx[cy*poszcount+cz]: 0);
      const float rvelx=float(cz<poszcount? velx[cy*poszcount+cz]: 0);
      //-Updates position.
      UpdatePos(ps,rmovx,0,0,false,pid,pos,dcell,code);
      //-Updates velocity.
      velrhop[pid].x=rvelx;
    }
  }
}
//<vs_mlapiston_end>

//<vs_rzone_ini>
//==============================================================================
/// Applies RelaxZone to selected particles.
/// Aplica RelaxZone a las particulas indicadas.
//==============================================================================
void JSphCpu::RunRelaxZone(double dt){
  TmcStart(Timers,TMC_SuMotion);
  RelaxZones->SetFluidVel(TimeStep,dt,Np-Npb,Npb,Posc,Idpc,Velrhopc);
  TmcStop(Timers,TMC_SuMotion);
}
//<vs_rzone_end>

//==============================================================================
/// Applies Damping to selected particles.
/// Aplica Damping a las particulas indicadas.
//==============================================================================
void JSphCpu::RunDamping(double dt,unsigned np,unsigned npb,const tdouble3 *pos,const typecode *code,tfloat4 *velrhop)const{
  if(CaseNfloat || PeriActive)Damping->ComputeDamping(TimeStep,dt,np-npb,npb,pos,code,velrhop);
  else Damping->ComputeDamping(TimeStep,dt,np-npb,npb,pos,NULL,velrhop);
}

//==============================================================================
/// Adjust variables of floating body particles.
/// Ajusta variables de particulas floating body.
//==============================================================================
void JSphCpu::InitFloating(){
  if(PartBegin){
    JPartFloatBi4Load ftdata;
    ftdata.LoadFile(PartBeginDir);
    //-Check cases of constant values. | Comprueba coincidencia de datos constantes.
    for(unsigned cf=0;cf<FtCount;cf++)ftdata.CheckHeadData(cf,FtObjs[cf].mkbound,FtObjs[cf].begin,FtObjs[cf].count,FtObjs[cf].mass);
    //-Load PART data. | Carga datos de PART.
    ftdata.LoadPart(PartBegin);
    for(unsigned cf=0;cf<FtCount;cf++){
      FtObjs[cf].center=ftdata.GetPartCenter(cf);
      FtObjs[cf].fvel=ftdata.GetPartFvel(cf);
      FtObjs[cf].fomega=ftdata.GetPartFomega(cf);
      FtObjs[cf].radius=ftdata.GetHeadRadius(cf);
    }
    DemDtForce=ftdata.GetPartDemDtForce();
  }
}

//==============================================================================
/// Show active timers.
/// Muestra los temporizadores activos.
//==============================================================================
void JSphCpu::ShowTimers(bool onlyfile){
  JLog2::TpMode_Out mode=(onlyfile? JLog2::Out_File: JLog2::Out_ScrFile);
  Log->Print("[CPU Timers]",mode);
  if(!SvTimers)Log->Print("none",mode);
  else for(unsigned c=0;c<TimerGetCount();c++)if(TimerIsActive(c))Log->Print(TimerToText(c),mode);
}

//==============================================================================
/// Return string with names and values of active timers.
/// Devuelve string con nombres y valores de los timers activos.
//==============================================================================
void JSphCpu::GetTimersInfo(std::string &hinfo,std::string &dinfo)const{
  for(unsigned c=0;c<TimerGetCount();c++)if(TimerIsActive(c)){
    hinfo=hinfo+";"+TimerGetName(c);
    dinfo=dinfo+";"+fun::FloatStr(TimerGetValue(c)/1000.f);
  }
}


